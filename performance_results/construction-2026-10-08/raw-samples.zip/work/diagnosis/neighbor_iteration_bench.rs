//! Diagnostic standalone neighbor walk; setup/drop untimed, 128 walks/sample.
use ironweaver_core::{Direction, Graph, NodeIx};
use std::{hint::black_box, time::Instant};
#[inline(never)]
fn walk(g: &Graph<(), ()>, nodes: &[NodeIx]) -> usize {
    nodes.iter().map(|&ix| g.neighbors(ix, Direction::Both).count()).sum()
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args[1], "neighbors");
    let n: usize = args[2].parse().unwrap();
    let samples: usize = args[3].parse().unwrap();
    let m = n * 5;
    println!("case,n,seconds");
    for sample in 0..samples + 2 {
        let mut g = Graph::with_capacity(n, m);
        let nodes: Vec<_> = (0..n).map(|i| g.add_node(format!("n{i}"), ()).unwrap()).collect();
        let mut rng = 42u64;
        for _ in 0..m {
            rng = rng.wrapping_mul(6364136223846793005).wrapping_add(1);
            let u = (rng >> 32) as usize % n;
            rng = rng.wrapping_mul(6364136223846793005).wrapping_add(1);
            let v = (rng >> 32) as usize % n;
            black_box(g.add_edge(nodes[u], nodes[v], ()).unwrap());
        }
        assert_eq!(walk(&g, &nodes), 2 * m);
        let start = Instant::now();
        for _ in 0..128 {
            assert_eq!(black_box(walk(black_box(&g), black_box(&nodes))), 2 * m);
        }
        let seconds = start.elapsed().as_secs_f64() / 128.0;
        if sample >= 2 { println!("neighbors,{n},{seconds}"); }
    }
}
