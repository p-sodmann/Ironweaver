from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path.cwd();out=root/'performance_results/construction-2026-10-08';out.mkdir(parents=True,exist_ok=True)
report=root/'work/corrected-report'
for name in ('README.md','summary.json','summary.csv','focused-comparison.png','suite-regression-overview.png'):shutil.copy2(report/name,out/name)
shutil.copy2(root/'work/diagnosis/summary.json',out/'diagnosis-summary.json')
shutil.copy2(root/'work/diagnosis/provenance.json',out/'provenance.json')
paths=list((root/'work/corrected-raw').glob('*.json'))
for pattern in ('*.json','*.log','*.sh','*.py','*.rs'):
 paths.extend((root/'work/diagnosis').glob(pattern))
for folder in ('baseline-new','candidate','remove-old','get-old','both-old'):
 paths.extend(p for p in (root/'work/diagnosis'/folder).glob('*') if p.is_file())
paths += [root/'benchmarks/analyze_construction_performance.py',root/'benchmarks/build_revision_pair.sh',root/'work/env.sh',root/'performance_results/construction-2026-10-07/raw-samples.zip']
paths=sorted(set(paths));manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
manifest['README.md']=hashlib.sha256((out/'README.md').read_bytes()).hexdigest()
(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'raw-samples.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(root))
 z.write(out/'README.md','README.md')
 z.write(out/'archive-manifest.json','archive-manifest.json')
with zipfile.ZipFile(out/'raw-samples.zip') as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
print('Archive verified:',len(paths),'files,',round((out/'raw-samples.zip').stat().st_size/2**20,2),'MiB')
old=root/'performance_results/construction-2026-10-07/README.md'
s=old.read_text();warning='> **SUPERSEDED CORRECTION (8 October):** The original baseline deletion and core traversal executables were stale/misidentified. All results for those two suites, including the claimed large deletion regressions, are invalid. Construction, Python and thread artifacts reproduce. See the [corrected report and root-cause investigation](../construction-2026-10-08/README.md). Original samples are retained for transparency.\n\n'
if not s.startswith('> **SUPERSEDED'):old.write_text(warning+s)
