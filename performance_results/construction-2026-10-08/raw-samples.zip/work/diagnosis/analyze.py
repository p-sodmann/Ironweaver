import sys,json,statistics
from pathlib import Path
sys.path.insert(0,'benchmarks')
from analyze_construction_performance import stats
rows=[]
for path in sorted(Path('work/diagnosis').glob('*deletion.json')):
 for r in json.loads(path.read_text())['results']:
  p=r['raw_pairs'];s=stats([statistics.median(v['baseline']) for v in p],[statistics.median(v['candidate']) for v in p])
  rows.append(dict(experiment=path.stem,case=r['shape']+'/'+str(r['edges']),unit='nanoseconds',**s))
for path in sorted(Path('work/diagnosis').glob('*neighbors.json')):
 for name,r in json.loads(path.read_text())['results'].items():
  p=r['raw'];s=stats([statistics.median(v['baseline']) for v in p],[statistics.median(v['candidate']) for v in p])
  rows.append(dict(experiment=path.stem,case=name,unit='seconds',**s))
Path('work/diagnosis/summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['experiment'],r['case'],f"{r['change']:+.2f}% [{r['ci_low']:+.2f},{r['ci_high']:+.2f}]")
