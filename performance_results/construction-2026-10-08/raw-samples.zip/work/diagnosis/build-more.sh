#!/usr/bin/env bash
set -euo pipefail
source work/env.sh
for variant in both-old baseline-new; do
 cp "work/diagnosis/$variant.rs" work/diagnosis/source/crates/ironweaver-core/src/graph.rs
 find work/diagnosis/source/crates/ironweaver-core/src -name '*.rs' -exec touch {} +
 CARGO_TARGET_DIR=/workspace/Ironweaver/target cargo build --manifest-path work/diagnosis/source/Cargo.toml --release --locked -p ironweaver-core --example bench_remove_node --example construction_bench
 mkdir -p "work/diagnosis/$variant"
 cp target/release/examples/bench_remove_node target/release/examples/construction_bench "work/diagnosis/$variant/"
 sha256sum "work/diagnosis/$variant/"* > "work/diagnosis/$variant/hashes.txt"
done
