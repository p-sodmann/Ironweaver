#!/usr/bin/env bash
set -euo pipefail
source work/env.sh
export CARGO_TARGET_DIR=/workspace/Ironweaver/target
cp work/diagnosis/neighbor_iteration_bench.rs work/diagnosis/source/crates/ironweaver-core/examples/
for variant in baseline-new candidate; do
 cp "work/diagnosis/$variant.rs" work/diagnosis/source/crates/ironweaver-core/src/graph.rs
 find work/diagnosis/source/crates/ironweaver-core/src -name '*.rs' -exec touch {} +
 if [[ "$variant" == baseline-new ]]; then
  (cd work/diagnosis/source; maturin build --release --locked --interpreter /workspace/.ironweaver-venv/bin/python --out ../verified-wheels)
 fi
 cargo build --manifest-path work/diagnosis/source/Cargo.toml --release --locked -p ironweaver-core --example neighbor_iteration_bench
 cp target/release/examples/neighbor_iteration_bench "work/diagnosis/$variant/"
done
python - <<'PY'
import zipfile,hashlib,json
from pathlib import Path
wheel=next(Path('work/diagnosis/verified-wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
 p=next(n for n in z.namelist() if n.endswith('.so'))
 sha=hashlib.sha256(z.read(p)).hexdigest()
old=hashlib.sha256(next(Path('work/artifacts/baseline/ironweaver').glob('*.so')).read_bytes()).hexdigest()
print('Baseline extension reproducibility:',sha,old)
Path('work/diagnosis/extension-verification.json').write_text(json.dumps(dict(rebuilt_sha256=sha,frozen_sha256=old,matches=sha==old),indent=2)+'\n')
assert sha==old, 'Do not reuse the broad Python suite until this mismatch is investigated.'
PY
