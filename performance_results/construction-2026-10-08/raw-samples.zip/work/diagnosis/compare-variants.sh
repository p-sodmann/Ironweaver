#!/usr/bin/env bash
set -euo pipefail
source work/env.sh
for variant in candidate remove-old get-old; do
 python benchmarks/compare_remove_node.py work/artifacts/baseline/bench_remove_node "work/diagnosis/$variant/bench_remove_node" --pairs 16 --samples 3 --cases parallel-out:4000,mixed:16000 --output "work/diagnosis/baseline-$variant-deletion.json"
 python benchmarks/compare_construction.py work/artifacts/baseline/construction_bench "work/diagnosis/$variant/construction_bench" --pairs 24 --samples 7 --sizes 1000 --cases neighbors --output "work/diagnosis/baseline-$variant-neighbors.json"
done
for variant in remove-old get-old; do
 python benchmarks/compare_remove_node.py work/diagnosis/candidate/bench_remove_node "work/diagnosis/$variant/bench_remove_node" --pairs 16 --samples 3 --cases parallel-out:4000,mixed:16000 --output "work/diagnosis/candidate-$variant-deletion.json"
done
