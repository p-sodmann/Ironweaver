#!/usr/bin/env bash
set -euo pipefail
cd /workspace/Ironweaver
export MPLCONFIGDIR=/workspace/Ironweaver/work/matplotlib
python benchmarks/analyze_construction_performance.py --raw work/corrected-raw --out work/corrected-report
python work/diagnosis/analyze.py
python work/diagnosis/write-corrected-report.py
python work/diagnosis/package-correction.py
