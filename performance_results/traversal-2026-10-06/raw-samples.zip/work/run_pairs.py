import argparse, csv, json, os, pathlib, random, subprocess, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--pairs',type=int,default=6)
p.add_argument('--start',type=int,default=0)
p.add_argument('--suites',default='focused,networkx,libraries,memory')
a=p.parse_args()
for pair in range(a.start,a.start+a.pairs):
    for suite in a.suites.split(','):
        variants=['before','after'] if pair%2==0 else ['after','before']
        for variant in variants:
            env=os.environ.copy()
            env['PYTHONPATH']=str(ROOT/'work/artifacts'/variant)
            path=ROOT/'work/raw'/f'final-{suite}-{pair:02d}-{variant}.jsonl'
            done = path.with_suffix(".done")
            if done.exists(): continue
            assert not path.exists(), path
            command=['taskset','-c','0-1']
            if suite=='focused':
                command+= [str(ROOT/'work/artifacts'/variant/'traversal_bench')]
            else:
                command+= [str(pathlib.Path('/workspace/.ironweaver-venv/bin/python')),str(ROOT/'benchmarks/paired_performance.py'),suite]
            start=time.time()
            with path.open('w') as out, path.with_suffix('.log').open('w') as err:
                subprocess.run(command,env=env,cwd=ROOT,stdout=out,stderr=err,check=True)
            done.write_text("completed\n")
            print(json.dumps(dict(pair=pair,suite=suite,variant=variant,seconds=time.time()-start)),flush=True)
