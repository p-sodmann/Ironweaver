set -euo pipefail
source work/env.sh
export RAYON_NUM_THREADS=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2
python work/run_pairs.py --start 6 --pairs 6 --suites focused >> work/progress.jsonl 2>&1
IW_BENCH_SIZES=1000:5000 python work/run_pairs.py --start 6 --pairs 3 --suites networkx >> work/progress.jsonl 2>&1
IW_BENCH_DATASETS=kron python work/run_pairs.py --start 6 --pairs 3 --suites libraries >> work/progress.jsonl 2>&1
