export CARGO_HOME=/workspace/.ironweaver-tools/cargo
export RUSTUP_HOME=/workspace/.ironweaver-tools/rustup
export PATH="$CARGO_HOME/bin:/workspace/.ironweaver-venv/bin:$PATH"
export CARGO_BUILD_JOBS=3
export RAYON_NUM_THREADS=3
export OMP_NUM_THREADS=3
export OPENBLAS_NUM_THREADS=3
export MKL_NUM_THREADS=3
export PYTHONHASHSEED=42
export PYO3_PYTHON=/workspace/.ironweaver-venv/bin/python

export UV_CACHE_DIR=/workspace/.ironweaver-tools/uv-cache
