set -euo pipefail
source work/env.sh
export RAYON_NUM_THREADS=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2
cargo fmt --all
cargo build --release --locked --offline -p ironweaver-core --example traversal_bench > work/build-after-core.log 2>&1
cp target/release/examples/traversal_bench work/artifacts/after/traversal_bench
maturin build --release --locked --offline -o work/wheels-after > work/build-after-python.log 2>&1
python - <<'PY'
import pathlib, zipfile
with zipfile.ZipFile(next(pathlib.Path('work/wheels-after').glob('*.whl'))) as z:
    for p in z.namelist():
        if p.startswith('ironweaver/') and not p.endswith('/'):
            z.extract(p,'work/artifacts/after')
PY
export PYTHONPATH=$PWD/work/artifacts/before
python -c 'import ironweaver; print(ironweaver.__file__)'
python benchmarks/paired_performance.py prepare > work/prepare.log 2>&1
uv pip install --python /workspace/.ironweaver-venv/bin/python --only-binary=:all: matplotlib > work/plot-dependencies.log 2>&1
uv pip freeze --python /workspace/.ironweaver-venv/bin/python > work/python-dependencies.txt
python work/manifest.py
export PYTHONPATH=$PWD/work/artifacts/after
cargo test -p ironweaver-core --locked --offline > work/core-test.log 2>&1
pytest -q > work/pytest.log 2>&1
cargo fmt --all --check > work/fmt.log 2>&1
cargo clippy --workspace --all-targets --locked --offline -- -D warnings > work/clippy.log 2>&1
cargo tree -p ironweaver-core --locked --offline > work/core-dependencies.txt
if rg pyo3 work/core-dependencies.txt; then exit 1; fi
python work/run_pairs.py --pairs 6 > work/progress.jsonl 2>&1
