push   %rbp
push   %r15
push   %r14
push   %r13
push   %r12
push   %rbx
push   %rax
test   %rdx,%rdx
je     <matrix_standalone::walk+0x10e>
mov    0x8(%rdi),%rcx
mov    0x10(%rdi),%r8
mov    0x48(%rdi),%r9
mov    0x40(%rdi),%rdi
xor    %eax,%eax
xor    %r10d,%r10d
nopl   0x0(%rax)
mov    (%rsi,%r10,8),%r11d
cmp    %r11,%r8
jbe    <matrix_standalone::walk+0xb0>
mov    0x4(%rsi,%r10,8),%ebx
imul   $0x68,%r11,%r15
cmp    %ebx,0x60(%rcx,%r15,1)
jne    <matrix_standalone::walk+0xb0>
add    %rcx,%r15
cmpq   $0xffffffffffffffff,(%r15)
je     <matrix_standalone::walk+0xb0>
mov    0x40(%r15),%r11
mov    0x50(%r15),%r14
mov    0x58(%r15),%rbx
test   %r11,%r11
je     <matrix_standalone::walk+0xc9>
mov    0x38(%r15),%r15
xor    %r12d,%r12d
nopw   0x0(%rax,%rax,1)
mov    (%r15,%r12,8),%r13d
cmp    %r13,%r9
jbe    <matrix_standalone::walk+0x11f>
lea    0x0(%r13,%r13,4),%r13
mov    0x20(%rdi,%r13,8),%ebp
cmp    0x4(%r15,%r12,8),%ebp
jne    <matrix_standalone::walk+0x11f>
lea    (%rdi,%r13,8),%r13
cmpl   $0x2,0x0(%r13)
je     <matrix_standalone::walk+0x11f>
inc    %r12
cmp    %r12,%r11
jne    <matrix_standalone::walk+0x70>
test   %rbx,%rbx
jne    <matrix_standalone::walk+0xd1>
jmp    <matrix_standalone::walk+0xb3>
xor    %r11d,%r11d
xor    %ebx,%ebx
add    %r11,%rax
add    %rbx,%rax
inc    %r10
cmp    %rdx,%r10
jne    <matrix_standalone::walk+0x30>
jmp    <matrix_standalone::walk+0x110>
xor    %r11d,%r11d
test   %rbx,%rbx
je     <matrix_standalone::walk+0xb3>
xor    %r15d,%r15d
data16 data16 cs nopw 0x0(%rax,%rax,1)
mov    (%r14,%r15,8),%r12d
cmp    %r12,%r9
jbe    <matrix_standalone::walk+0x11f>
lea    (%r12,%r12,4),%r12
mov    0x20(%rdi,%r12,8),%ebp
cmp    0x4(%r14,%r15,8),%ebp
jne    <matrix_standalone::walk+0x11f>
lea    (%rdi,%r12,8),%r12
cmpl   $0x2,(%r12)
je     <matrix_standalone::walk+0x11f>
inc    %r15
cmp    %r15,%rbx
jne    <matrix_standalone::walk+0xe0>
jmp    <matrix_standalone::walk+0xb5>
xor    %eax,%eax
add    $0x8,%rsp
pop    %rbx
pop    %r12
pop    %r13
pop    %r14
pop    %r15
pop    %rbp
ret
lea    RIP_RELOC,%rdi
lea    RIP_RELOC,%rdx
mov    $0x24,%esi
call   *RIP_RELOC
int3
int3
int3
int3
int3
int3
int3
int3
