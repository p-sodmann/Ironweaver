import argparse,csv,hashlib,io,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,'benchmarks')
from compare_construction import summarize
p=argparse.ArgumentParser();p.add_argument('--pairs',type=int,default=24);p.add_argument('--root',type=Path,default=Path('work/codegen'));p.add_argument('--output',type=Path,required=True);a=p.parse_args()
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
cells=[(s,1) for s in ('frozen','align64','cgu1')]
data=dict(pairs=a.pairs,samples=7,warmups=2,n=1000,affinity=list(os.sched_getaffinity(0)),hashes={},results={f'{s}/batch={b}':dict(raw=[]) for s,b in cells})
for rev in ('baseline','candidate'):
 data['hashes'][rev]={s:hashlib.sha256((a.root/rev/s).read_bytes()).hexdigest() for s in ('frozen','align64','cgu1')}
for i in range(a.pairs):
 order=cells[i%len(cells):]+cells[:i%len(cells)]
 for j,(s,batch) in enumerate(order):
  pair=dict(order=['baseline','candidate'] if (i+j)%2==0 else ['candidate','baseline'])
  for rev in pair['order']:
   env=os.environ|dict(IW_NEIGHBOR_BATCH=str(batch),RAYON_NUM_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONHASHSEED='42')
   result=subprocess.run([str((a.root/rev/s).resolve()),'neighbors','1000','7'],env=env,capture_output=True,text=True,check=True)
   pair[rev]=[float(r['seconds']) for r in csv.DictReader(io.StringIO(result.stdout))];assert len(pair[rev])==7
  entry=data['results'][f'{s}/batch={batch}'];entry['raw'].append(pair)
  if len(entry['raw'])>=2:entry['summary']=summarize(entry['raw'])
 a.output.write_text(json.dumps(data,indent=2)+'\n')
 print('completed matrix block',i+1,flush=True)
for name,r in data['results'].items():print(name,r['summary'],flush=True)
