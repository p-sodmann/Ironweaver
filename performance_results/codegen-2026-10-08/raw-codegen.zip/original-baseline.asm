   47710:	push   %rbp
   47711:	push   %r15
   47713:	push   %r14
   47715:	push   %r13
   47717:	push   %r12
   47719:	push   %rbx
   4771a:	sub    $0x6e8,%rsp
   47721:	lea    0x110(%rsp),%r12
   47729:	mov    %r12,%rdi
   4772c:	call   *0x5d2be(%rip)        # a49f0 <_DYNAMIC+0x530>
   47732:	lea    0xc8(%rsp),%rdi
   4773a:	mov    %r12,%rsi
   4773d:	call   40c40 <<alloc::vec::Vec<alloc::string::String> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<alloc::string::String, std::env::Args>>::from_iter>
   47742:	mov    0xd8(%rsp),%rcx
   4774a:	cmp    $0x2,%rcx
   4774e:	mov    %rcx,0xa8(%rsp)
   47756:	jb     48ccb <construction_bench::main+0x15bb>
   4775c:	mov    0xd0(%rsp),%rax
   47764:	mov    %rax,0x28(%rsp)
   47769:	add    $0x18,%rax
   4776d:	mov    %rax,0xf0(%rsp)
   47775:	cmp    $0x2,%rcx
   47779:	je     48cd9 <construction_bench::main+0x15c9>
   4777f:	mov    0x28(%rsp),%rax
   47784:	mov    0x38(%rax),%rcx
   47788:	mov    0x40(%rax),%rsi
   4778c:	cmp    $0x1,%rsi
   47790:	je     477a0 <construction_bench::main+0x90>
   47792:	test   %rsi,%rsi
   47795:	je     48cf5 <construction_bench::main+0x15e5>
   4779b:	movzbl (%rcx),%edx
   4779e:	jmp    477b7 <construction_bench::main+0xa7>
   477a0:	movzbl (%rcx),%edx
   477a3:	mov    $0x1,%al
   477a5:	cmp    $0x2b,%edx
   477a8:	je     48aab <construction_bench::main+0x139b>
   477ae:	cmp    $0x2d,%edx
   477b1:	je     48aab <construction_bench::main+0x139b>
   477b7:	xor    %eax,%eax
   477b9:	cmp    $0x2b,%dl
   477bc:	sete   %al
   477bf:	mov    %rsi,%rdx
   477c2:	sub    %rax,%rdx
   477c5:	add    %rax,%rcx
   477c8:	neg    %rax
   477cb:	cmp    $0x11,%rdx
   477cf:	jae    47807 <construction_bench::main+0xf7>
   477d1:	test   %rdx,%rdx
   477d4:	je     47852 <construction_bench::main+0x142>
   477d6:	add    %rax,%rsi
   477d9:	neg    %rsi
   477dc:	xor    %eax,%eax
   477de:	xor    %edx,%edx
   477e0:	movzbl (%rcx,%rdx,1),%edi
   477e4:	add    $0xffffffd0,%edi
   477e7:	cmp    $0x9,%edi
   477ea:	ja     48caa <construction_bench::main+0x159a>
   477f0:	lea    (%rax,%rax,4),%rax
   477f4:	mov    %edi,%edi
   477f6:	lea    (%rdi,%rax,2),%rax
   477fa:	inc    %rdx
   477fd:	mov    %rsi,%rdi
   47800:	add    %rdx,%rdi
   47803:	jne    477e0 <construction_bench::main+0xd0>
   47805:	jmp    47854 <construction_bench::main+0x144>
   47807:	add    %rax,%rsi
   4780a:	neg    %rsi
   4780d:	xor    %eax,%eax
   4780f:	mov    $0xa,%edi
   47814:	xor    %r8d,%r8d
   47817:	nopw   0x0(%rax,%rax,1)
   47820:	mul    %rdi
   47823:	movzbl (%rcx,%r8,1),%edx
   47828:	jo     48a9d <construction_bench::main+0x138d>
   4782e:	add    $0xffffffd0,%edx
   47831:	cmp    $0xa,%edx
   47834:	jae    48caa <construction_bench::main+0x159a>
   4783a:	mov    %edx,%edx
   4783c:	add    %rdx,%rax
   4783f:	jb     48aa9 <construction_bench::main+0x1399>
   47845:	inc    %r8
   47848:	mov    %rsi,%rdx
   4784b:	add    %r8,%rdx
   4784e:	jne    47820 <construction_bench::main+0x110>
   47850:	jmp    47854 <construction_bench::main+0x144>
   47852:	xor    %eax,%eax
   47854:	mov    %rax,0x58(%rsp)
   47859:	lea    (%rax,%rax,4),%rax
   4785d:	mov    %rax,0x50(%rsp)
   47862:	mov    $0x7,%ebx
   47867:	cmpq   $0x4,0xa8(%rsp)
   47870:	jb     4795a <construction_bench::main+0x24a>
   47876:	mov    0x28(%rsp),%rax
   4787b:	mov    0x50(%rax),%rcx
   4787f:	mov    0x58(%rax),%rsi
   47883:	cmp    $0x1,%rsi
   47887:	je     47897 <construction_bench::main+0x187>
   47889:	test   %rsi,%rsi
   4788c:	je     48cfc <construction_bench::main+0x15ec>
   47892:	movzbl (%rcx),%edx
   47895:	jmp    478ae <construction_bench::main+0x19e>
   47897:	movzbl (%rcx),%edx
   4789a:	mov    $0x1,%al
   4789c:	cmp    $0x2b,%edx
   4789f:	je     48b30 <construction_bench::main+0x1420>
   478a5:	cmp    $0x2d,%edx
   478a8:	je     48b30 <construction_bench::main+0x1420>
   478ae:	xor    %eax,%eax
   478b0:	cmp    $0x2b,%dl
   478b3:	sete   %al
   478b6:	mov    %rsi,%rdx
   478b9:	sub    %rax,%rdx
   478bc:	add    %rax,%rcx
   478bf:	neg    %rax
   478c2:	cmp    $0x11,%rdx
   478c6:	jae    47907 <construction_bench::main+0x1f7>
   478c8:	test   %rdx,%rdx
   478cb:	je     47958 <construction_bench::main+0x248>
   478d1:	add    %rax,%rsi
   478d4:	neg    %rsi
   478d7:	xor    %ebx,%ebx
   478d9:	xor    %eax,%eax
   478db:	nopl   0x0(%rax,%rax,1)
   478e0:	movzbl (%rcx,%rax,1),%edx
   478e4:	add    $0xffffffd0,%edx
   478e7:	cmp    $0x9,%edx
   478ea:	ja     48cb1 <construction_bench::main+0x15a1>
   478f0:	lea    (%rbx,%rbx,4),%rdi
   478f4:	mov    %edx,%edx
   478f6:	lea    (%rdx,%rdi,2),%rbx
   478fa:	inc    %rax
   478fd:	mov    %rsi,%rdx
   47900:	add    %rax,%rdx
   47903:	jne    478e0 <construction_bench::main+0x1d0>
   47905:	jmp    4795a <construction_bench::main+0x24a>
   47907:	add    %rax,%rsi
   4790a:	neg    %rsi
   4790d:	xor    %ebx,%ebx
   4790f:	mov    $0xa,%edi
   47914:	xor    %r8d,%r8d
   47917:	nopw   0x0(%rax,%rax,1)
   47920:	mov    %rbx,%rax
   47923:	mul    %rdi
   47926:	movzbl (%rcx,%r8,1),%edx
   4792b:	jo     48b22 <construction_bench::main+0x1412>
   47931:	add    $0xffffffd0,%edx
   47934:	cmp    $0xa,%edx
   47937:	jae    48cb1 <construction_bench::main+0x15a1>
   4793d:	mov    %rax,%rbx
   47940:	mov    %edx,%eax
   47942:	add    %rax,%rbx
   47945:	jb     48b2e <construction_bench::main+0x141e>
   4794b:	inc    %r8
   4794e:	mov    %rsi,%rax
   47951:	add    %r8,%rax
   47954:	jne    47920 <construction_bench::main+0x210>
   47956:	jmp    4795a <construction_bench::main+0x24a>
   47958:	xor    %ebx,%ebx
   4795a:	lea    -0x3d07b(%rip),%rdi        # a8e6 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x6>
   47961:	mov    $0x1f,%esi
   47966:	call   *0x5d08c(%rip)        # a49f8 <_DYNAMIC+0x538>
   4796c:	add    $0x2,%rbx
   47970:	je     48997 <construction_bench::main+0x1287>
   47976:	lea    0x118(%rsp),%rax
   4797e:	mov    %rax,0xe8(%rsp)
   47986:	lea    0x11c(%rsp),%rax
   4798e:	mov    %rax,0xe0(%rsp)
   47996:	movq   $0x0,0xb0(%rsp)
   479a2:	lea    0x110(%rsp),%r12
   479aa:	mov    0x5ce0f(%rip),%r14        # a47c0 <_DYNAMIC+0x300>
   479b1:	lea    0x60(%rsp),%rax
   479b6:	mov    %rax,0xc0(%rsp)
   479be:	mov    %rbx,0x98(%rsp)
   479c6:	jmp    479ec <construction_bench::main+0x2dc>
   479c8:	nopl   0x0(%rax,%rax,1)
   479d0:	mov    0xb0(%rsp),%rcx
   479d8:	inc    %rcx
   479db:	mov    %rcx,0xb0(%rsp)
   479e3:	cmp    %rbx,%rcx
   479e6:	je     48997 <construction_bench::main+0x1287>
   479ec:	mov    0x28(%rsp),%rax
   479f1:	cmpq   $0xa,0x28(%rax)
   479f6:	jne    47a24 <construction_bench::main+0x314>
   479f8:	mov    0x28(%rsp),%rax
   479fd:	mov    0x20(%rax),%rax
   47a01:	mov    (%rax),%rcx
   47a04:	movabs $0x65727275636e6f63,%rdx
   47a0e:	xor    %rdx,%rcx
   47a11:	movzwl 0x8(%rax),%eax
   47a15:	xor    $0x746e,%rax
   47a1b:	or     %rcx,%rax
   47a1e:	je     47f65 <construction_bench::main+0x855>
   47a24:	mov    0x58(%rsp),%rbp
   47a29:	mov    0x50(%rsp),%rdx
   47a2e:	lea    0x300(%rsp),%r15
   47a36:	mov    %r15,%rdi
   47a39:	mov    %rbp,%rsi
   47a3c:	call   3b510 <<ironweaver_core::graph::Graph<(), ()>>::with_capacity>
   47a41:	mov    0x28(%rsp),%r13
   47a46:	movq   $0x0,0x4f8(%rsp)
   47a52:	mov    %rbp,0x500(%rsp)
   47a5a:	mov    %r15,0x4f0(%rsp)
   47a62:	lea    0x30(%rsp),%rdi
   47a67:	lea    0x4f0(%rsp),%rbp
   47a6f:	mov    %rbp,%rsi
   47a72:	call   40fa0 <<alloc::vec::Vec<ironweaver_core::graph::NodeIx> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<ironweaver_core::graph::NodeIx, core::iter::adapters::map::Map<core::ops::range::Range<usize>, construction_bench::fixture::{closure#0}>>>::from_iter>
   47a77:	mov    $0x1d8,%edx
   47a7c:	mov    %r12,%rdi
   47a7f:	mov    %r15,%rsi
   47a82:	mov    0x5ccbf(%rip),%r15        # a4748 <memcpy@GLIBC_2.14>
   47a89:	call   *%r15
   47a8c:	mov    %r15,%rcx
   47a8f:	movups 0x30(%rsp),%xmm0
   47a94:	lea    0x118(%rsp),%r15
   47a9c:	movups %xmm0,0x1d0(%r15)
   47aa4:	mov    0x40(%rsp),%rax
   47aa9:	mov    %rax,0x1e0(%r15)
   47ab0:	mov    $0x1d8,%edx
   47ab5:	mov    %rbp,%rdi
   47ab8:	mov    %r12,%rbp
   47abb:	mov    %r12,%rsi
   47abe:	call   *%rcx
   47ac0:	mov    0x1e0(%r15),%rax
   47ac7:	mov    %rax,0x40(%rsp)
   47acc:	movupd 0x1d0(%r15),%xmm0
   47ad5:	movapd %xmm0,0x30(%rsp)
   47adb:	mov    0x20(%r13),%rcx
   47adf:	mov    0x28(%r13),%rax
   47ae3:	cmp    $0x9,%rax
   47ae7:	jne    47b20 <construction_bench::main+0x410>
   47ae9:	mov    (%rcx),%rdx
   47aec:	movabs $0x726f62686769656e,%rsi
   47af6:	xor    %rsi,%rdx
   47af9:	movzbl 0x8(%rcx),%esi
   47afd:	xor    $0x73,%rsi
   47b01:	or     %rdx,%rsi
   47b04:	mov    %rbp,%r12
   47b07:	lea    0x4d8(%rsp),%r13
   47b0f:	lea    0x4f0(%rsp),%rbp
   47b17:	jne    47b3d <construction_bench::main+0x42d>
   47b19:	jmp    47d90 <construction_bench::main+0x680>
   47b1e:	xchg   %ax,%ax
   47b20:	cmp    $0x8,%rax
   47b24:	mov    %rbp,%r12
   47b27:	lea    0x4d8(%rsp),%r13
   47b2f:	lea    0x4f0(%rsp),%rbp
   47b37:	jb     47dd2 <construction_bench::main+0x6c2>
   47b3d:	movabs $0x6870617267627573,%rdx
   47b47:	cmp    (%rcx),%rdx
   47b4a:	je     47d90 <construction_bench::main+0x680>
   47b50:	cmp    $0xe,%rax
   47b54:	jne    47dd2 <construction_bench::main+0x6c2>
   47b5a:	mov    0x28(%rsp),%rax
   47b5f:	mov    0x20(%rax),%rax
   47b63:	mov    (%rax),%rcx
   47b66:	movabs $0x6870617267627573,%rdx
   47b70:	xor    %rdx,%rcx
   47b73:	mov    0x6(%rax),%rax
   47b77:	movabs $0x6c6c616d732d6870,%rdx
   47b81:	xor    %rdx,%rax
   47b84:	or     %rcx,%rax
   47b87:	jne    47df9 <construction_bench::main+0x6e9>
   47b8d:	movl   $0x0,0x88(%rsp)
   47b98:	lea    0x88(%rsp),%rax
   47ba0:	mov    %rax,0x110(%rsp)
   47ba8:	mov    0x5ce51(%rip),%rax        # a4a00 <_DYNAMIC+0x540>
   47baf:	mov    %rax,0x118(%rsp)
   47bb7:	lea    0xf8(%rsp),%rdi
   47bbf:	lea    -0x3e751(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47bc6:	mov    %r12,%rdx
   47bc9:	call   *%r14
   47bcc:	lea    0x300(%rsp),%rdi
   47bd4:	mov    %rbp,%rsi
   47bd7:	lea    0xf8(%rsp),%rdx
   47bdf:	call   393f0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47be4:	cmpl   $0xffffffff,0x300(%rsp)
   47bec:	jne    48b5f <construction_bench::main+0x144f>
   47bf2:	movsd  0x308(%rsp),%xmm0
   47bfb:	movapd %xmm0,0x70(%rsp)
   47c01:	mov    0x40(%rsp),%r15
   47c06:	cmp    0x30(%rsp),%r15
   47c0b:	jne    47c18 <construction_bench::main+0x508>
   47c0d:	lea    0x30(%rsp),%rdi
   47c12:	call   *0x5cdf0(%rip)        # a4a08 <_DYNAMIC+0x548>
   47c18:	mov    0x38(%rsp),%rax
   47c1d:	movapd 0x70(%rsp),%xmm0
   47c23:	movlpd %xmm0,(%rax,%r15,8)
   47c29:	inc    %r15
   47c2c:	mov    %r15,0x40(%rsp)
   47c31:	movl   $0x1,0x88(%rsp)
   47c3c:	lea    0x88(%rsp),%rax
   47c44:	mov    %rax,0x110(%rsp)
   47c4c:	mov    0x5cdad(%rip),%rax        # a4a00 <_DYNAMIC+0x540>
   47c53:	mov    %rax,0x118(%rsp)
   47c5b:	lea    0xf8(%rsp),%rdi
   47c63:	lea    -0x3e7f5(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47c6a:	mov    %r12,%rdx
   47c6d:	call   *%r14
   47c70:	lea    0x300(%rsp),%rdi
   47c78:	mov    %rbp,%rsi
   47c7b:	lea    0xf8(%rsp),%rdx
   47c83:	call   393f0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47c88:	cmpl   $0xffffffff,0x300(%rsp)
   47c90:	jne    48b5f <construction_bench::main+0x144f>
   47c96:	movsd  0x308(%rsp),%xmm0
   47c9f:	movapd %xmm0,0x70(%rsp)
   47ca5:	mov    0x40(%rsp),%r15
   47caa:	cmp    0x30(%rsp),%r15
   47caf:	jne    47cbc <construction_bench::main+0x5ac>
   47cb1:	lea    0x30(%rsp),%rdi
   47cb6:	call   *0x5cd4c(%rip)        # a4a08 <_DYNAMIC+0x548>
   47cbc:	mov    0x38(%rsp),%rax
   47cc1:	movapd 0x70(%rsp),%xmm0
   47cc7:	movlpd %xmm0,(%rax,%r15,8)
   47ccd:	inc    %r15
   47cd0:	mov    %r15,0x40(%rsp)
   47cd5:	movl   $0x2,0x88(%rsp)
   47ce0:	lea    0x88(%rsp),%rax
   47ce8:	mov    %rax,0x110(%rsp)
   47cf0:	mov    0x5cd09(%rip),%rax        # a4a00 <_DYNAMIC+0x540>
   47cf7:	mov    %rax,0x118(%rsp)
   47cff:	lea    0xf8(%rsp),%rdi
   47d07:	lea    -0x3e899(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47d0e:	mov    %r12,%rdx
   47d11:	call   *%r14
   47d14:	lea    0x300(%rsp),%rdi
   47d1c:	mov    %rbp,%rsi
   47d1f:	lea    0xf8(%rsp),%rdx
   47d27:	call   393f0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47d2c:	cmpl   $0xffffffff,0x300(%rsp)
   47d34:	jne    48b5f <construction_bench::main+0x144f>
   47d3a:	movsd  0x308(%rsp),%xmm0
   47d43:	movapd %xmm0,0x70(%rsp)
   47d49:	mov    0x40(%rsp),%r15
   47d4e:	cmp    0x30(%rsp),%r15
   47d53:	jne    47d60 <construction_bench::main+0x650>
   47d55:	lea    0x30(%rsp),%rdi
   47d5a:	call   *0x5cca8(%rip)        # a4a08 <_DYNAMIC+0x548>
   47d60:	mov    0x38(%rsp),%rax
   47d65:	movapd 0x70(%rsp),%xmm0
   47d6b:	movlpd %xmm0,(%rax,%r15,8)
   47d71:	inc    %r15
   47d74:	mov    %r15,0x40(%rsp)
   47d79:	mov    0x28(%rsp),%rax
   47d7e:	mov    0x28(%rax),%rax
   47d82:	cmp    $0x5,%rax
   47d86:	je     47dd8 <construction_bench::main+0x6c8>
   47d88:	jmp    47df9 <construction_bench::main+0x6e9>
   47d8a:	nopw   0x0(%rax,%rax,1)
   47d90:	mov    0x38(%rsp),%rsi
   47d95:	mov    0x40(%rsp),%rdx
   47d9a:	mov    %rbp,%rdi
   47d9d:	mov    $0x1,%bpl
   47da0:	mov    0x50(%rsp),%rcx
   47da5:	mov    $0x6,%r9d
   47dab:	lea    -0x3d4d2(%rip),%r8        # a8e0 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111>
   47db2:	call   48f10 <construction_bench::edges>
   47db7:	mov    0x28(%rsp),%rax
   47dbc:	mov    0x28(%rax),%rax
   47dc0:	lea    0x4f0(%rsp),%rbp
   47dc8:	cmp    $0xe,%rax
   47dcc:	je     47b5a <construction_bench::main+0x44a>
   47dd2:	cmp    $0x5,%rax
   47dd6:	jne    47df9 <construction_bench::main+0x6e9>
   47dd8:	mov    0x28(%rsp),%rax
   47ddd:	mov    0x20(%rax),%rax
   47de1:	mov    (%rax),%ecx
   47de3:	mov    $0x6c617473,%edx
   47de8:	xor    %edx,%ecx
   47dea:	movzbl 0x4(%rax),%eax
   47dee:	xor    $0x65,%eax
   47df1:	or     %ecx,%eax
   47df3:	je     48730 <construction_bench::main+0x1020>
   47df9:	xor    %r15d,%r15d
   47dfc:	mov    $0x1,%bpl
   47dff:	call   *0x5cc0b(%rip)        # a4a10 <_DYNAMIC+0x550>
   47e05:	mov    %rax,0x88(%rsp)
   47e0d:	mov    %edx,0x90(%rsp)
   47e14:	mov    0x28(%rsp),%rax
   47e19:	mov    0x20(%rax),%r8
   47e1d:	mov    0x28(%rax),%r9
   47e21:	lea    -0x5(%r9),%rax
   47e25:	cmp    $0x9,%rax
   47e29:	ja     484f0 <construction_bench::main+0xde0>
   47e2f:	lea    -0x3d5d6(%rip),%rcx        # a860 <anon.5d09ad63f943746d04ae2dafc92c2e77.3.llvm.11945693191618023075+0x74>
   47e36:	movslq (%rcx,%rax,4),%rax
   47e3a:	add    %rcx,%rax
   47e3d:	jmp    *%rax
   47e3f:	mov    (%r8),%eax
   47e42:	mov    $0x65646f6e,%ecx
   47e47:	xor    %ecx,%eax
   47e49:	movzbl 0x4(%r8),%ecx
   47e4e:	xor    $0x73,%ecx
   47e51:	or     %eax,%ecx
   47e53:	je     487bf <construction_bench::main+0x10af>
   47e59:	mov    (%r8),%eax
   47e5c:	mov    $0x6c617473,%ecx
   47e61:	xor    %ecx,%eax
   47e63:	movzbl 0x4(%r8),%ecx
   47e68:	xor    $0x65,%ecx
   47e6b:	or     %eax,%ecx
   47e6d:	jne    484f0 <construction_bench::main+0xde0>
   47e73:	cmpq   $0x0,0x50(%rsp)
   47e79:	je     4850c <construction_bench::main+0xdfc>
   47e7f:	test   %r15b,%r15b
   47e82:	je     48c6e <construction_bench::main+0x155e>
   47e88:	xor    %r15d,%r15d
   47e8b:	jmp    47e9e <construction_bench::main+0x78e>
   47e8d:	nopl   (%rax)
   47e90:	inc    %r15
   47e93:	cmp    0x50(%rsp),%r15
   47e98:	jae    4850c <construction_bench::main+0xdfc>
   47e9e:	cmpq   $0x0,0x40(%rsp)
   47ea4:	je     48cb8 <construction_bench::main+0x15a8>
   47eaa:	mov    0x38(%rsp),%rax
   47eaf:	mov    (%rax),%r8d
   47eb2:	mov    0x4(%rax),%r9d
   47eb6:	movq   $0x0,0x10(%rsp)
   47ebf:	movq   $0x0,(%rsp)
   47ec7:	mov    %r12,%rdi
   47eca:	lea    0x4f0(%rsp),%rsi
   47ed2:	mov    0xbc(%rsp),%edx
   47ed9:	mov    0xb8(%rsp),%ecx
   47ee0:	call   39da0 <<ironweaver_core::graph::Graph<(), ()>>::insert_edge>
   47ee5:	cmpl   $0xffffffff,0x110(%rsp)
   47eed:	je     48abe <construction_bench::main+0x13ae>
   47ef3:	movupd 0x110(%rsp),%xmm0
   47efc:	movupd 0x120(%rsp),%xmm1
   47f05:	movapd %xmm1,0x310(%rsp)
   47f0e:	movapd %xmm0,0x300(%rsp)
   47f17:	lea    0x300(%rsp),%rax
   47f1f:	mov    0x300(%rsp),%rax
   47f27:	cmp    $0xa,%rax
   47f2b:	ja     47f3c <construction_bench::main+0x82c>
   47f2d:	mov    $0x51c,%ecx
   47f32:	bt     %rax,%rcx
   47f36:	jb     47e90 <construction_bench::main+0x780>
   47f3c:	mov    0x308(%rsp),%rsi
   47f44:	test   %rsi,%rsi
   47f47:	je     47e90 <construction_bench::main+0x780>
   47f4d:	mov    0x310(%rsp),%rdi
   47f55:	mov    $0x1,%edx
   47f5a:	call   *0x5c7a0(%rip)        # a4700 <_DYNAMIC+0x240>
   47f60:	jmp    47e90 <construction_bench::main+0x780>
   47f65:	movabs $0x400000000,%rax
   47f6f:	mov    %rax,0x120(%rsp)
   47f77:	lea    0x58(%rsp),%rax
   47f7c:	mov    %rax,0x110(%rsp)
   47f84:	lea    0x50(%rsp),%rax
   47f89:	mov    %rax,0x118(%rsp)
   47f91:	lea    0x30(%rsp),%rdi
   47f96:	mov    %r12,%rsi
   47f99:	call   410b0 <<alloc::vec::Vec<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>), core::iter::adapters::map::Map<core::ops::range::Range<i32>, construction_bench::main::{closure#1}>>>::from_iter>
   47f9e:	call   *0x5ca6c(%rip)        # a4a10 <_DYNAMIC+0x550>
   47fa4:	mov    %rax,0x88(%rsp)
   47fac:	mov    %edx,0x90(%rsp)
   47fb3:	mov    0x40(%rsp),%rax
   47fb8:	mov    %rax,0x120(%rsp)
   47fc0:	movups 0x30(%rsp),%xmm0
   47fc5:	movaps %xmm0,0x110(%rsp)
   47fcd:	movq   $0x0,0x300(%rsp)
   47fd9:	movq   $0x8,0x308(%rsp)
   47fe5:	movq   $0x0,0x310(%rsp)
   47ff1:	lea    0x50(%rsp),%rax
   47ff6:	mov    %rax,0x128(%rsp)
   47ffe:	lea    0x300(%rsp),%rdi
   48006:	mov    %r12,%rsi
   48009:	call   40c10 <<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>> as rayon::iter::ParallelExtend<ironweaver_core::graph::Graph<(), ()>>>::par_extend::<rayon::iter::map::Map<rayon::vec::IntoIter<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)>, construction_bench::main::{closure#2}>>>
   4800e:	movupd 0x300(%rsp),%xmm0
   48017:	movapd %xmm0,0x4f0(%rsp)
   48020:	mov    0x310(%rsp),%rax
   48028:	mov    %rax,0x500(%rsp)
   48030:	lea    0x88(%rsp),%rdi
   48038:	call   *0x5c9da(%rip)        # a4a18 <_DYNAMIC+0x558>
   4803e:	movq   %rax,%xmm0
   48043:	punpckldq -0x4038b(%rip),%xmm0        # 7cc0 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.1550166086514486265+0x70>
   4804b:	xorps  %xmm1,%xmm1
   4804e:	cvtsi2sd %edx,%xmm1
   48052:	subpd  -0x403fa(%rip),%xmm0        # 7c60 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.1550166086514486265+0x10>
   4805a:	movapd %xmm0,0x70(%rsp)
   48060:	divsd  -0x3dc08(%rip),%xmm1        # a460 <anon.2511809ce763e2139425809bcda7322c.34.llvm.18327950015791369945+0x88>
   48068:	movsd  %xmm1,0x68(%rsp)
   4806e:	mov    0x500(%rsp),%rcx
   48076:	test   %rcx,%rcx
   48079:	je     480b7 <construction_bench::main+0x9a7>
   4807b:	mov    0x4f8(%rsp),%rax
   48083:	imul   $0x1d8,%rcx,%rcx
   4808a:	mov    0x50(%rsp),%rdx
   4808f:	xor    %esi,%esi
   48091:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   480a0:	cmp    %rdx,0x68(%rax,%rsi,1)
   480a5:	jne    48c8f <construction_bench::main+0x157f>
   480ab:	add    $0x1d8,%rsi
   480b2:	cmp    %rsi,%rcx
   480b5:	jne    480a0 <construction_bench::main+0x990>
   480b7:	mov    0x500(%rsp),%rax
   480bf:	mov    %rax,0x120(%rsp)
   480c7:	movapd 0x4f0(%rsp),%xmm0
   480d0:	movapd %xmm0,0x110(%rsp)
   480d9:	mov    0x120(%rsp),%rax
   480e1:	test   %rax,%rax
   480e4:	je     48118 <construction_bench::main+0xa08>
   480e6:	mov    0x118(%rsp),%rbp
   480ee:	mov    $0x1,%r15d
   480f4:	sub    %rax,%r15
   480f7:	nopw   0x0(%rax,%rax,1)
   48100:	mov    %rbp,%rdi
   48103:	call   405c0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48108:	add    $0x1d8,%rbp
   4810f:	inc    %r15
   48112:	cmp    $0x1,%r15
   48116:	jne    48100 <construction_bench::main+0x9f0>
   48118:	mov    0x110(%rsp),%rax
   48120:	test   %rax,%rax
   48123:	je     4813f <construction_bench::main+0xa2f>
   48125:	mov    0x118(%rsp),%rdi
   4812d:	imul   $0x1d8,%rax,%rsi
   48134:	mov    $0x8,%edx
   48139:	call   *0x5c5c1(%rip)        # a4700 <_DYNAMIC+0x240>
   4813f:	movapd 0x70(%rsp),%xmm1
   48145:	movapd %xmm1,%xmm0
   48149:	unpckhpd %xmm1,%xmm0
   4814d:	addsd  %xmm1,%xmm0
   48151:	movsd  0x68(%rsp),%xmm1
   48157:	addsd  %xmm0,%xmm1
   4815b:	movsd  %xmm1,0x300(%rsp)
   48164:	jmp    486b2 <construction_bench::main+0xfa2>
   48169:	mov    (%r8),%rax
   4816c:	movabs $0x726f62686769656e,%rcx
   48176:	xor    %rcx,%rax
   48179:	movzbl 0x8(%r8),%ecx
   4817e:	xor    $0x73,%rcx
   48182:	or     %rax,%rcx
   48185:	jne    484f0 <construction_bench::main+0xde0>
   4818b:	mov    0x40(%rsp),%r11
   48190:	test   %r11,%r11
   48193:	je     48952 <construction_bench::main+0x1242>
   48199:	mov    0x38(%rsp),%rcx
   4819e:	mov    0x4f8(%rsp),%r15
   481a6:	mov    0x500(%rsp),%r13
   481ae:	mov    0x538(%rsp),%rdi
   481b6:	mov    0x530(%rsp),%r9
   481be:	xor    %r10d,%r10d
   481c1:	xor    %r8d,%r8d
   481c4:	mov    %r13,0x70(%rsp)
   481c9:	mov    %r11,0x68(%rsp)
   481ce:	mov    %r15,0xa0(%rsp)
   481d6:	jmp    481f6 <construction_bench::main+0xae6>
   481d8:	nopl   0x0(%rax,%rax,1)
   481e0:	xor    %esi,%esi
   481e2:	xor    %eax,%eax
   481e4:	add    %rsi,%r8
   481e7:	add    %rax,%r8
   481ea:	inc    %r10
   481ed:	cmp    %r11,%r10
   481f0:	je     48955 <construction_bench::main+0x1245>
   481f6:	mov    (%rcx,%r10,8),%eax
   481fa:	cmp    %rax,%r13
   481fd:	jbe    481e0 <construction_bench::main+0xad0>
   481ff:	mov    0x4(%rcx,%r10,8),%edx
   48204:	imul   $0x68,%rax,%rax
   48208:	cmp    %edx,0x60(%r15,%rax,1)
   4820d:	jne    481e0 <construction_bench::main+0xad0>
   4820f:	add    %r15,%rax
   48212:	cmpq   $0xffffffffffffffff,(%rax)
   48216:	je     481e0 <construction_bench::main+0xad0>
   48218:	mov    0x40(%rax),%r15
   4821c:	mov    0x50(%rax),%rdx
   48220:	mov    0x58(%rax),%r11
   48224:	test   %r15,%r15
   48227:	je     48367 <construction_bench::main+0xc57>
   4822d:	mov    0x38(%rax),%rax
   48231:	mov    (%rax),%esi
   48233:	cmp    %rsi,%rdi
   48236:	jbe    48a16 <construction_bench::main+0x1306>
   4823c:	lea    (%rsi,%rsi,4),%rsi
   48240:	mov    0x20(%r9,%rsi,8),%r13d
   48245:	cmp    0x4(%rax),%r13d
   48249:	jne    48a16 <construction_bench::main+0x1306>
   4824f:	lea    (%r9,%rsi,8),%rsi
   48253:	cmpl   $0x2,(%rsi)
   48256:	je     48a16 <construction_bench::main+0x1306>
   4825c:	mov    $0x1,%esi
   48261:	cmp    $0x1,%r15
   48265:	mov    0x98(%rsp),%rbx
   4826d:	mov    0x70(%rsp),%r13
   48272:	je     482c6 <construction_bench::main+0xbb6>
   48274:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   48280:	mov    (%rax,%rsi,8),%r13d
   48284:	cmp    %r13,%rdi
   48287:	jbe    48a16 <construction_bench::main+0x1306>
   4828d:	lea    0x0(%r13,%r13,4),%r13
   48292:	mov    0x20(%r9,%r13,8),%ebx
   48297:	cmp    0x4(%rax,%rsi,8),%ebx
   4829b:	jne    48a16 <construction_bench::main+0x1306>
   482a1:	lea    (%r9,%r13,8),%rbx
   482a5:	cmpl   $0x2,(%rbx)
   482a8:	je     48a16 <construction_bench::main+0x1306>
   482ae:	inc    %rsi
   482b1:	cmp    %rsi,%r15
   482b4:	jne    48280 <construction_bench::main+0xb70>
   482b6:	mov    %r15,%rsi
   482b9:	mov    0x98(%rsp),%rbx
   482c1:	mov    0x70(%rsp),%r13
   482c6:	test   %r11,%r11
   482c9:	je     48372 <construction_bench::main+0xc62>
   482cf:	mov    (%rdx),%eax
   482d1:	cmp    %rax,%rdi
   482d4:	jbe    48a16 <construction_bench::main+0x1306>
   482da:	lea    (%rax,%rax,4),%rax
   482de:	mov    0x20(%r9,%rax,8),%ebx
   482e3:	cmp    0x4(%rdx),%ebx
   482e6:	jne    48a16 <construction_bench::main+0x1306>
   482ec:	lea    (%r9,%rax,8),%rax
   482f0:	cmpl   $0x2,(%rax)
   482f3:	je     48a16 <construction_bench::main+0x1306>
   482f9:	mov    $0x1,%eax
   482fe:	cmp    $0x1,%r11
   48302:	je     48348 <construction_bench::main+0xc38>
   48304:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   48310:	mov    (%rdx,%rax,8),%r15d
   48314:	cmp    %r15,%rdi
   48317:	jbe    48a16 <construction_bench::main+0x1306>
   4831d:	lea    (%r15,%r15,4),%r15
   48321:	mov    0x20(%r9,%r15,8),%ebx
   48326:	cmp    0x4(%rdx,%rax,8),%ebx
   4832a:	jne    48a16 <construction_bench::main+0x1306>
   48330:	lea    (%r9,%r15,8),%rbx
   48334:	cmpl   $0x2,(%rbx)
   48337:	je     48a16 <construction_bench::main+0x1306>
   4833d:	inc    %rax
   48340:	cmp    %rax,%r11
   48343:	jne    48310 <construction_bench::main+0xc00>
   48345:	mov    %r11,%rax
   48348:	mov    0x98(%rsp),%rbx
   48350:	mov    0x68(%rsp),%r11
   48355:	mov    0xa0(%rsp),%r15
   4835d:	mov    0x70(%rsp),%r13
   48362:	jmp    481e4 <construction_bench::main+0xad4>
   48367:	xor    %esi,%esi
   48369:	test   %r11,%r11
   4836c:	jne    482cf <construction_bench::main+0xbbf>
   48372:	xor    %eax,%eax
   48374:	mov    0x68(%rsp),%r11
   48379:	mov    0xa0(%rsp),%r15
   48381:	jmp    481e4 <construction_bench::main+0xad4>
   48386:	movabs $0x6870617267627573,%rax
   48390:	cmp    %rax,(%r8)
   48393:	jne    484f0 <construction_bench::main+0xde0>
   48399:	mov    0x38(%rsp),%rdx
   4839e:	mov    0x40(%rsp),%r15
   483a3:	jmp    4886d <construction_bench::main+0x115d>
   483a8:	mov    (%r8),%rax
   483ab:	movabs $0x746163696c707564,%rcx
   483b5:	xor    %rcx,%rax
   483b8:	movzwl 0x8(%r8),%ecx
   483bd:	xor    $0x7365,%rcx
   483c4:	or     %rax,%rcx
   483c7:	jne    484f0 <construction_bench::main+0xde0>
   483cd:	cmpq   $0x0,0x58(%rsp)
   483d3:	je     4850c <construction_bench::main+0xdfc>
   483d9:	xor    %r15d,%r15d
   483dc:	jmp    483ee <construction_bench::main+0xcde>
   483de:	xchg   %ax,%ax
   483e0:	inc    %r15
   483e3:	cmp    0x58(%rsp),%r15
   483e8:	jae    4850c <construction_bench::main+0xdfc>
   483ee:	mov    %r15,0x60(%rsp)
   483f3:	lea    0x60(%rsp),%rax
   483f8:	mov    %rax,0x300(%rsp)
   48400:	mov    0x5c451(%rip),%rax        # a4858 <_DYNAMIC+0x398>
   48407:	mov    %rax,0x308(%rsp)
   4840f:	mov    %r13,%rdi
   48412:	lea    -0x3ee38(%rip),%rsi        # 95e1 <anon.7091b7ef657caedcc2fa209982c793b5.0.llvm.9337857877282664933>
   48419:	lea    0x300(%rsp),%rdx
   48421:	call   *%r14
   48424:	mov    %r12,%rdi
   48427:	lea    0x4f0(%rsp),%rsi
   4842f:	mov    %r13,%rdx
   48432:	call   393f0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   48437:	cmpl   $0xffffffff,0x110(%rsp)
   4843f:	je     48a85 <construction_bench::main+0x1375>
   48445:	movupd 0x110(%rsp),%xmm0
   4844e:	movupd 0x120(%rsp),%xmm1
   48457:	movapd %xmm1,0x310(%rsp)
   48460:	movapd %xmm0,0x300(%rsp)
   48469:	lea    0x300(%rsp),%rax
   48471:	mov    0x300(%rsp),%rax
   48479:	cmp    $0xa,%rax
   4847d:	ja     4848e <construction_bench::main+0xd7e>
   4847f:	mov    $0x51c,%ecx
   48484:	bt     %rax,%rcx
   48488:	jb     483e0 <construction_bench::main+0xcd0>
   4848e:	mov    0x308(%rsp),%rsi
   48496:	test   %rsi,%rsi
   48499:	je     483e0 <construction_bench::main+0xcd0>
   4849f:	mov    0x310(%rsp),%rdi
   484a7:	mov    $0x1,%edx
   484ac:	call   *0x5c24e(%rip)        # a4700 <_DYNAMIC+0x240>
   484b2:	jmp    483e0 <construction_bench::main+0xcd0>
   484b7:	mov    (%r8),%rax
   484ba:	movabs $0x6870617267627573,%rcx
   484c4:	xor    %rcx,%rax
   484c7:	mov    0x6(%r8),%rcx
   484cb:	movabs $0x6c6c616d732d6870,%rdx
   484d5:	xor    %rdx,%rcx
   484d8:	or     %rax,%rcx
   484db:	je     4884e <construction_bench::main+0x113e>
   484e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   484f0:	mov    0x38(%rsp),%rsi
   484f5:	mov    0x40(%rsp),%rdx
   484fa:	mov    0x50(%rsp),%rcx
   484ff:	lea    0x4f0(%rsp),%rdi
   48507:	call   48f10 <construction_bench::edges>
   4850c:	lea    0x88(%rsp),%rdi
   48514:	call   *0x5c4fe(%rip)        # a4a18 <_DYNAMIC+0x558>
   4851a:	movq   %rax,%xmm0
   4851f:	punpckldq -0x40867(%rip),%xmm0        # 7cc0 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.1550166086514486265+0x70>
   48527:	subpd  -0x408cf(%rip),%xmm0        # 7c60 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.1550166086514486265+0x10>
   4852f:	xorps  %xmm1,%xmm1
   48532:	cvtsi2sd %edx,%xmm1
   48536:	divsd  -0x3e0de(%rip),%xmm1        # a460 <anon.2511809ce763e2139425809bcda7322c.34.llvm.18327950015791369945+0x88>
   4853e:	mov    0x28(%rsp),%rax
   48543:	mov    0x28(%rax),%rcx
   48547:	add    $0xfffffffffffffffb,%rcx
   4854b:	cmp    $0x9,%rcx
   4854f:	lea    0x4f0(%rsp),%rsi
   48557:	ja     48630 <construction_bench::main+0xf20>
   4855d:	mov    0x28(%rsp),%rax
   48562:	mov    0x20(%rax),%rax
   48566:	lea    -0x3dce5(%rip),%rdx        # a888 <anon.5d09ad63f943746d04ae2dafc92c2e77.3.llvm.11945693191618023075+0x9c>
   4856d:	movslq (%rdx,%rcx,4),%rcx
   48571:	add    %rdx,%rcx
   48574:	jmp    *%rcx
   48576:	mov    (%rax),%ecx
   48578:	mov    $0x65646f6e,%edx
   4857d:	xor    %edx,%ecx
   4857f:	movzbl 0x4(%rax),%edx
   48583:	xor    $0x73,%edx
   48586:	or     %ecx,%edx
   48588:	je     4864b <construction_bench::main+0xf3b>
   4858e:	mov    (%rax),%ecx
   48590:	mov    $0x6c617473,%edx
   48595:	xor    %edx,%ecx
   48597:	movzbl 0x4(%rax),%eax
   4859b:	xor    $0x65,%eax
   4859e:	or     %ecx,%eax
   485a0:	jne    48630 <construction_bench::main+0xf20>
   485a6:	jmp    4864b <construction_bench::main+0xf3b>
   485ab:	mov    (%rax),%rcx
   485ae:	movabs $0x726f62686769656e,%rdx
   485b8:	xor    %rdx,%rcx
   485bb:	movzbl 0x8(%rax),%eax
   485bf:	xor    $0x73,%rax
   485c3:	or     %rcx,%rax
   485c6:	jne    48630 <construction_bench::main+0xf20>
   485c8:	jmp    4864b <construction_bench::main+0xf3b>
   485cd:	movabs $0x6870617267627573,%rcx
   485d7:	cmp    %rcx,(%rax)
   485da:	jne    48630 <construction_bench::main+0xf20>
   485dc:	jmp    4864b <construction_bench::main+0xf3b>
   485de:	mov    (%rax),%rcx
   485e1:	movabs $0x746163696c707564,%rdx
   485eb:	xor    %rdx,%rcx
   485ee:	movzwl 0x8(%rax),%eax
   485f2:	xor    $0x7365,%rax
   485f8:	or     %rcx,%rax
   485fb:	jne    48630 <construction_bench::main+0xf20>
   485fd:	jmp    4864b <construction_bench::main+0xf3b>
   485ff:	mov    (%rax),%rcx
   48602:	movabs $0x6870617267627573,%rdx
   4860c:	xor    %rdx,%rcx
   4860f:	mov    0x6(%rax),%rax
   48613:	movabs $0x6c6c616d732d6870,%rdx
   4861d:	xor    %rdx,%rax
   48620:	or     %rcx,%rax
   48623:	je     4864b <construction_bench::main+0xf3b>
   48625:	data16 cs nopw 0x0(%rax,%rax,1)
   48630:	mov    0x558(%rsp),%rax
   48638:	mov    %rax,0x110(%rsp)
   48640:	cmp    0x50(%rsp),%rax
   48645:	jne    48b01 <construction_bench::main+0x13f1>
   4864b:	movsd  %xmm1,0x68(%rsp)
   48651:	movapd %xmm0,0x70(%rsp)
   48657:	mov    $0x1d8,%edx
   4865c:	mov    %r12,%rdi
   4865f:	call   *0x5c0e3(%rip)        # a4748 <memcpy@GLIBC_2.14>
   48665:	xor    %ebp,%ebp
   48667:	mov    %r12,%rdi
   4866a:	call   46e60 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   4866f:	movapd 0x70(%rsp),%xmm1
   48675:	movapd %xmm1,%xmm0
   48679:	unpckhpd %xmm1,%xmm0
   4867d:	addsd  %xmm1,%xmm0
   48681:	movsd  0x68(%rsp),%xmm1
   48687:	addsd  %xmm0,%xmm1
   4868b:	movsd  %xmm1,0x300(%rsp)
   48694:	mov    0x30(%rsp),%rsi
   48699:	test   %rsi,%rsi
   4869c:	je     486b2 <construction_bench::main+0xfa2>
   4869e:	mov    0x38(%rsp),%rdi
   486a3:	shl    $0x3,%rsi
   486a7:	mov    $0x4,%edx
   486ac:	call   *0x5c04e(%rip)        # a4700 <_DYNAMIC+0x240>
   486b2:	cmpq   $0x1,0xb0(%rsp)
   486bb:	jbe    479d0 <construction_bench::main+0x2c0>
   486c1:	lea    0xf0(%rsp),%rax
   486c9:	mov    %rax,0x110(%rsp)
   486d1:	lea    -0x1e98(%rip),%rax        # 46840 <<&alloc::string::String as core::fmt::Display>::fmt>
   486d8:	mov    %rax,0x118(%rsp)
   486e0:	lea    0x58(%rsp),%rax
   486e5:	mov    %rax,0x120(%rsp)
   486ed:	mov    0x5c164(%rip),%rax        # a4858 <_DYNAMIC+0x398>
   486f4:	mov    %rax,0x128(%rsp)
   486fc:	lea    0x300(%rsp),%rax
   48704:	mov    %rax,0x130(%rsp)
   4870c:	mov    0x5c30d(%rip),%rax        # a4a20 <_DYNAMIC+0x560>
   48713:	mov    %rax,0x138(%rsp)
   4871b:	lea    -0x40892(%rip),%rdi        # 7e90 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.1550166086514486265+0x240>
   48722:	mov    %r12,%rsi
   48725:	call   *0x5c2cd(%rip)        # a49f8 <_DYNAMIC+0x538>
   4872b:	jmp    479d0 <construction_bench::main+0x2c0>
   48730:	mov    %rbp,%rsi
   48733:	mov    $0x1,%bpl
   48736:	mov    $0x7,%ecx
   4873b:	lea    0x300(%rsp),%rdi
   48743:	lea    -0x3de55(%rip),%rdx        # a8f5 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x15>
   4874a:	call   394a0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<&str>>
   4874f:	cmpl   $0xffffffff,0x300(%rsp)
   48757:	jne    48bb0 <construction_bench::main+0x14a0>
   4875d:	mov    0x308(%rsp),%edx
   48764:	mov    0x30c(%rsp),%ecx
   4876b:	mov    %r12,%rdi
   4876e:	lea    0x4f0(%rsp),%rsi
   48776:	mov    %edx,0xbc(%rsp)
   4877d:	mov    %ecx,0xb8(%rsp)
   48784:	call   3a540 <<ironweaver_core::graph::Graph<(), ()>>::remove_node>
   48789:	mov    0x110(%rsp),%rsi
   48791:	cmp    $0xffffffffffffffff,%rsi
   48795:	je     48c01 <construction_bench::main+0x14f1>
   4879b:	mov    $0x1,%r15b
   4879e:	test   %rsi,%rsi
   487a1:	je     47dfc <construction_bench::main+0x6ec>
   487a7:	mov    0x118(%rsp),%rdi
   487af:	mov    $0x1,%edx
   487b4:	call   *0x5bf46(%rip)        # a4700 <_DYNAMIC+0x240>
   487ba:	jmp    47dfc <construction_bench::main+0x6ec>
   487bf:	cmpq   $0x0,0x58(%rsp)
   487c5:	je     4850c <construction_bench::main+0xdfc>
   487cb:	xor    %r15d,%r15d
   487ce:	xchg   %ax,%ax
   487d0:	mov    %r15,0x60(%rsp)
   487d5:	lea    0x60(%rsp),%rax
   487da:	mov    %rax,0x110(%rsp)
   487e2:	mov    0x5c06f(%rip),%rax        # a4858 <_DYNAMIC+0x398>
   487e9:	mov    %rax,0x118(%rsp)
   487f1:	lea    0x6d0(%rsp),%r13
   487f9:	mov    %r13,%rdi
   487fc:	lea    -0x3faf9(%rip),%rsi        # 8d0a <anon.6ce2bd37e1c81bd133be53b065f15922.5.llvm.5838934960365399480+0x55f>
   48803:	mov    %r12,%rdx
   48806:	call   *%r14
   48809:	lea    0x300(%rsp),%rdi
   48811:	lea    0x4f0(%rsp),%rsi
   48819:	mov    %r13,%rdx
   4881c:	call   393f0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   48821:	cmpl   $0xffffffff,0x300(%rsp)
   48829:	jne    48a34 <construction_bench::main+0x1324>
   4882f:	inc    %r15
   48832:	mov    0x308(%rsp),%rax
   4883a:	mov    %rax,0x110(%rsp)
   48842:	cmp    0x58(%rsp),%r15
   48847:	jb     487d0 <construction_bench::main+0x10c0>
   48849:	jmp    4850c <construction_bench::main+0xdfc>
   4884e:	mov    0x40(%rsp),%rsi
   48853:	mov    0x58(%rsp),%rdx
   48858:	mov    %rsi,%r15
   4885b:	sub    %rdx,%r15
   4885e:	jb     48c56 <construction_bench::main+0x1546>
   48864:	shl    $0x3,%rdx
   48868:	add    0x38(%rsp),%rdx
   4886d:	lea    (%rdx,%r15,8),%rcx
   48871:	mov    %r12,%rdi
   48874:	lea    0x4f0(%rsp),%rsi
   4887c:	call   377f0 <<ironweaver_core::graph::Graph<(), ()>>::induced_subgraph::<(), (), core::convert::Infallible, core::iter::adapters::copied::Copied<core::slice::iter::Iter<ironweaver_core::graph::NodeIx>>, construction_bench::main::{closure#3}, construction_bench::main::{closure#4}>>
   48881:	mov    $0x1d8,%edx
   48886:	lea    0x300(%rsp),%rdi
   4888e:	mov    %r12,%rsi
   48891:	call   *0x5beb1(%rip)        # a4748 <memcpy@GLIBC_2.14>
   48897:	mov    0x330(%rsp),%rax
   4889f:	mov    %rax,0x60(%rsp)
   488a4:	mov    %r15,0x110(%rsp)
   488ac:	cmp    %r15,%rax
   488af:	jne    48c13 <construction_bench::main+0x1503>
   488b5:	mov    0x4c0(%rsp),%rax
   488bd:	mov    %rax,0x60(%rsp)
   488c2:	mov    0x6b0(%rsp),%rcx
   488ca:	mov    %rcx,0x110(%rsp)
   488d2:	cmp    %rcx,%rax
   488d5:	jne    48c34 <construction_bench::main+0x1524>
   488db:	mov    0x28(%rsp),%rax
   488e0:	cmpq   $0xe,0x28(%rax)
   488e5:	jne    4892f <construction_bench::main+0x121f>
   488e7:	mov    0x28(%rsp),%rax
   488ec:	mov    0x20(%rax),%rax
   488f0:	mov    (%rax),%rcx
   488f3:	movabs $0x6870617267627573,%rdx
   488fd:	xor    %rdx,%rcx
   48900:	mov    0x6(%rax),%rax
   48904:	movabs $0x6c6c616d732d6870,%rdx
   4890e:	xor    %rdx,%rax
   48911:	or     %rcx,%rax
   48914:	jne    4892f <construction_bench::main+0x121f>
   48916:	mov    0x368(%rsp),%rax
   4891e:	mov    %rax,0x110(%rsp)
   48926:	test   %rax,%rax
   48929:	jne    48c77 <construction_bench::main+0x1567>
   4892f:	mov    $0x1d8,%edx
   48934:	mov    %r12,%rdi
   48937:	lea    0x300(%rsp),%rsi
   4893f:	call   *0x5be03(%rip)        # a4748 <memcpy@GLIBC_2.14>
   48945:	mov    %r12,%rdi
   48948:	call   46e60 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   4894d:	jmp    4850c <construction_bench::main+0xdfc>
   48952:	xor    %r8d,%r8d
   48955:	mov    %r8,0x300(%rsp)
   4895d:	lea    0x300(%rsp),%rax
   48965:	mov    0x50(%rsp),%rax
   4896a:	add    %rax,%rax
   4896d:	mov    %rax,0x110(%rsp)
   48975:	cmp    %rax,0x300(%rsp)
   4897d:	je     4850c <construction_bench::main+0xdfc>
   48983:	lea    0x300(%rsp),%rsi
   4898b:	lea    0x58aee(%rip),%r9        # a1480 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xd8>
   48992:	jmp    48b10 <construction_bench::main+0x1400>
   48997:	mov    0x28(%rsp),%rax
   4899c:	lea    0x8(%rax),%rbx
   489a0:	mov    0x5bd59(%rip),%r15        # a4700 <_DYNAMIC+0x240>
   489a7:	mov    0xa8(%rsp),%r14
   489af:	jmp    489c9 <construction_bench::main+0x12b9>
   489b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   489c0:	add    $0x18,%rbx
   489c4:	dec    %r14
   489c7:	je     489df <construction_bench::main+0x12cf>
   489c9:	mov    -0x8(%rbx),%rsi
   489cd:	test   %rsi,%rsi
   489d0:	je     489c0 <construction_bench::main+0x12b0>
   489d2:	mov    (%rbx),%rdi
   489d5:	mov    $0x1,%edx
   489da:	call   *%r15
   489dd:	jmp    489c0 <construction_bench::main+0x12b0>
   489df:	mov    0xc8(%rsp),%rax
   489e7:	test   %rax,%rax
   489ea:	je     48a04 <construction_bench::main+0x12f4>
   489ec:	shl    $0x3,%rax
   489f0:	lea    (%rax,%rax,2),%rsi
   489f4:	mov    $0x8,%edx
   489f9:	mov    0x28(%rsp),%rdi
   489fe:	call   *0x5bcfc(%rip)        # a4700 <_DYNAMIC+0x240>
   48a04:	add    $0x6e8,%rsp
   48a0b:	pop    %rbx
   48a0c:	pop    %r12
   48a0e:	pop    %r13
   48a10:	pop    %r14
   48a12:	pop    %r15
   48a14:	pop    %rbp
   48a15:	ret
   48a16:	lea    -0x3e645(%rip),%rdi        # a3d8 <anon.2511809ce763e2139425809bcda7322c.34.llvm.18327950015791369945>
   48a1d:	lea    0x585e4(%rip),%rdx        # a1008 <anon.2511809ce763e2139425809bcda7322c.35.llvm.18327950015791369945>
   48a24:	mov    $0x24,%esi
   48a29:	call   *0x5bd59(%rip)        # a4788 <_DYNAMIC+0x2c8>
   48a2f:	jmp    48cf3 <construction_bench::main+0x15e3>
   48a34:	movupd 0x300(%rsp),%xmm0
   48a3d:	movupd 0x310(%rsp),%xmm1
   48a46:	movapd %xmm1,0x120(%rsp)
   48a4f:	movapd %xmm0,0x110(%rsp)
   48a58:	lea    -0x3e127(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48a5f:	lea    0x58c02(%rip),%rcx        # a1668 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48a66:	lea    0x58a8b(%rip),%r8        # a14f8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x150>
   48a6d:	lea    0x110(%rsp),%rdx
   48a75:	mov    $0x2b,%esi
   48a7a:	call   *0x5bd10(%rip)        # a4790 <_DYNAMIC+0x2d0>
   48a80:	jmp    48cf3 <construction_bench::main+0x15e3>
   48a85:	lea    0x58a54(%rip),%r8        # a14e0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x138>
   48a8c:	lea    0x58bf5(%rip),%rcx        # a1688 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2e0>
   48a93:	lea    0x300(%rsp),%rdx
   48a9b:	jmp    48ad1 <construction_bench::main+0x13c1>
   48a9d:	add    $0xd0,%dl
   48aa0:	xor    %eax,%eax
   48aa2:	cmp    $0xa,%dl
   48aa5:	adc    $0x1,%al
   48aa7:	jmp    48aab <construction_bench::main+0x139b>
   48aa9:	mov    $0x2,%al
   48aab:	mov    %al,0x110(%rsp)
   48ab2:	lea    0x5897f(%rip),%r8        # a1438 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x90>
   48ab9:	jmp    48b3e <construction_bench::main+0x142e>
   48abe:	lea    0x58a03(%rip),%r8        # a14c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x120>
   48ac5:	lea    0x58b7c(%rip),%rcx        # a1648 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2a0>
   48acc:	lea    0x60(%rsp),%rdx
   48ad1:	mov    0xe8(%rsp),%rax
   48ad9:	mov    (%rax),%eax
   48adb:	mov    0xe0(%rsp),%rsi
   48ae3:	mov    (%rsi),%esi
   48ae5:	mov    %eax,(%rdx)
   48ae7:	mov    %esi,0x4(%rdx)
   48aea:	lea    -0x3e18e(%rip),%rdi        # a963 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x83>
   48af1:	mov    $0x2e,%esi
   48af6:	call   *0x5bc94(%rip)        # a4790 <_DYNAMIC+0x2d0>
   48afc:	jmp    48cf3 <construction_bench::main+0x15e3>
   48b01:	mov    %r12,%rsi
   48b04:	lea    0x50(%rsp),%r12
   48b09:	lea    0x58a30(%rip),%r9        # a1540 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x198>
   48b10:	xor    %edi,%edi
   48b12:	mov    %r12,%rdx
   48b15:	xor    %ecx,%ecx
   48b17:	call   *0x5bf0b(%rip)        # a4a28 <_DYNAMIC+0x568>
   48b1d:	jmp    48cf3 <construction_bench::main+0x15e3>
   48b22:	add    $0xd0,%dl
   48b25:	xor    %eax,%eax
   48b27:	cmp    $0xa,%dl
   48b2a:	adc    $0x1,%al
   48b2c:	jmp    48b30 <construction_bench::main+0x1420>
   48b2e:	mov    $0x2,%al
   48b30:	mov    %al,0x110(%rsp)
   48b37:	lea    0x588b2(%rip),%r8        # a13f0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x48>
   48b3e:	lea    -0x3e20d(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48b45:	lea    0x58b5c(%rip),%rcx        # a16a8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x300>
   48b4c:	mov    $0x2b,%esi
   48b51:	mov    %r12,%rdx
   48b54:	call   *0x5bc36(%rip)        # a4790 <_DYNAMIC+0x2d0>
   48b5a:	jmp    48cf3 <construction_bench::main+0x15e3>
   48b5f:	movupd 0x300(%rsp),%xmm0
   48b68:	movupd 0x310(%rsp),%xmm1
   48b71:	movapd %xmm1,0x120(%rsp)
   48b7a:	movapd %xmm0,0x110(%rsp)
   48b83:	lea    -0x3e252(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48b8a:	lea    0x58ad7(%rip),%rcx        # a1668 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48b91:	lea    0x589f0(%rip),%r8        # a1588 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1e0>
   48b98:	lea    0x110(%rsp),%rdx
   48ba0:	mov    $0x2b,%esi
   48ba5:	call   *0x5bbe5(%rip)        # a4790 <_DYNAMIC+0x2d0>
   48bab:	jmp    48cf3 <construction_bench::main+0x15e3>
   48bb0:	movupd 0x300(%rsp),%xmm0
   48bb9:	movupd 0x310(%rsp),%xmm1
   48bc2:	movapd %xmm1,0x120(%rsp)
   48bcb:	movapd %xmm0,0x110(%rsp)
   48bd4:	lea    -0x3e2a3(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48bdb:	lea    0x58a86(%rip),%rcx        # a1668 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48be2:	lea    0x58867(%rip),%r8        # a1450 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xa8>
   48be9:	lea    0x110(%rsp),%rdx
   48bf1:	mov    $0x2b,%esi
   48bf6:	call   *0x5bb94(%rip)        # a4790 <_DYNAMIC+0x2d0>
   48bfc:	jmp    48cf3 <construction_bench::main+0x15e3>
   48c01:	lea    0x58860(%rip),%rdi        # a1468 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xc0>
   48c08:	call   *0x5bcb2(%rip)        # a48c0 <_DYNAMIC+0x400>
   48c0e:	jmp    48cf3 <construction_bench::main+0x15e3>
   48c13:	lea    0x588f6(%rip),%r9        # a1510 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x168>
   48c1a:	xor    %edi,%edi
   48c1c:	mov    0xc0(%rsp),%rsi
   48c24:	mov    %r12,%rdx
   48c27:	xor    %ecx,%ecx
   48c29:	call   *0x5bdf9(%rip)        # a4a28 <_DYNAMIC+0x568>
   48c2f:	jmp    48cf3 <construction_bench::main+0x15e3>
   48c34:	lea    0x588ed(%rip),%r9        # a1528 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x180>
   48c3b:	lea    0x60(%rsp),%rsi
   48c40:	lea    0x110(%rsp),%rdx
   48c48:	xor    %edi,%edi
   48c4a:	xor    %ecx,%ecx
   48c4c:	call   44f7b <core::panicking::assert_failed::<ironweaver_core::graph::EdgeId, ironweaver_core::graph::EdgeId>>
   48c51:	jmp    48cf3 <construction_bench::main+0x15e3>
   48c56:	lea    0x58913(%rip),%rcx        # a1570 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1c8>
   48c5d:	mov    %rdx,%rdi
   48c60:	mov    %rsi,%rdx
   48c63:	call   *0x5bcb7(%rip)        # a4920 <_DYNAMIC+0x460>
   48c69:	jmp    48cf3 <construction_bench::main+0x15e3>
   48c6e:	lea    0x58823(%rip),%rdi        # a1498 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xf0>
   48c75:	jmp    48c08 <construction_bench::main+0x14f8>
   48c77:	mov    %r12,0xc0(%rsp)
   48c7f:	lea    -0x3e7ee(%rip),%r12        # a498 <anon.2511809ce763e2139425809bcda7322c.34.llvm.18327950015791369945+0xc0>
   48c86:	lea    0x588cb(%rip),%r9        # a1558 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1b0>
   48c8d:	jmp    48c1a <construction_bench::main+0x150a>
   48c8f:	lea    -0x3e39a(%rip),%rdi        # a8fc <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x1c>
   48c96:	lea    0x58903(%rip),%rdx        # a15a0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1f8>
   48c9d:	mov    $0x3c,%esi
   48ca2:	call   *0x5bbf0(%rip)        # a4898 <_DYNAMIC+0x3d8>
   48ca8:	jmp    48cf3 <construction_bench::main+0x15e3>
   48caa:	mov    $0x1,%al
   48cac:	jmp    48aab <construction_bench::main+0x139b>
   48cb1:	mov    $0x1,%al
   48cb3:	jmp    48b30 <construction_bench::main+0x1420>
   48cb8:	lea    0x587f1(%rip),%rdx        # a14b0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x108>
   48cbf:	xor    %edi,%edi
   48cc1:	xor    %esi,%esi
   48cc3:	call   *0x5bacf(%rip)        # a4798 <_DYNAMIC+0x2d8>
   48cc9:	jmp    48cf3 <construction_bench::main+0x15e3>
   48ccb:	lea    0x58736(%rip),%rdx        # a1408 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x60>
   48cd2:	mov    $0x1,%edi
   48cd7:	jmp    48ce5 <construction_bench::main+0x15d5>
   48cd9:	lea    0x58740(%rip),%rdx        # a1420 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x78>
   48ce0:	mov    $0x2,%edi
   48ce5:	mov    0xa8(%rsp),%rsi
   48ced:	call   *0x5baa5(%rip)        # a4798 <_DYNAMIC+0x2d8>
   48cf3:	ud2
   48cf5:	xor    %eax,%eax
   48cf7:	jmp    48aab <construction_bench::main+0x139b>
   48cfc:	xor    %eax,%eax
   48cfe:	jmp    48b30 <construction_bench::main+0x1420>
   48d03:	jmp    48e5a <construction_bench::main+0x174a>
   48d08:	mov    %rax,%r14
   48d0b:	lea    0x30(%rsp),%rdi
   48d10:	call   46da0 <core::ptr::drop_glue::<alloc::vec::Vec<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)>>>
   48d15:	jmp    48e90 <construction_bench::main+0x1780>
   48d1a:	jmp    48dda <construction_bench::main+0x16ca>
   48d1f:	mov    %rax,%r14
   48d22:	lea    0x300(%rsp),%rdi
   48d2a:	call   41490 <core::ptr::drop_glue::<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>>>>
   48d2f:	jmp    48e90 <construction_bench::main+0x1780>
   48d34:	call   *0x5ba66(%rip)        # a47a0 <_DYNAMIC+0x2e0>
   48d3a:	jmp    48e5a <construction_bench::main+0x174a>
   48d3f:	mov    %rax,%r14
   48d42:	lea    0x300(%rsp),%rdi
   48d4a:	call   46e60 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48d4f:	jmp    48e90 <construction_bench::main+0x1780>
   48d54:	call   *0x5ba46(%rip)        # a47a0 <_DYNAMIC+0x2e0>
   48d5a:	jmp    48e5a <construction_bench::main+0x174a>
   48d5f:	mov    %rax,%r14
   48d62:	jmp    48e90 <construction_bench::main+0x1780>
   48d67:	jmp    48e5a <construction_bench::main+0x174a>
   48d6c:	jmp    48e5a <construction_bench::main+0x174a>
   48d71:	mov    %rax,%r14
   48d74:	jmp    48e60 <construction_bench::main+0x1750>
   48d79:	mov    %rax,%r14
   48d7c:	test   %r15,%r15
   48d7f:	je     48da4 <construction_bench::main+0x1694>
   48d81:	add    $0x1d8,%rbp
   48d88:	neg    %r15
   48d8b:	nopl   0x0(%rax,%rax,1)
   48d90:	mov    %rbp,%rdi
   48d93:	call   405c0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48d98:	add    $0x1d8,%rbp
   48d9f:	dec    %r15
   48da2:	jne    48d90 <construction_bench::main+0x1680>
   48da4:	mov    0x110(%rsp),%rax
   48dac:	test   %rax,%rax
   48daf:	je     48e90 <construction_bench::main+0x1780>
   48db5:	mov    0x118(%rsp),%rdi
   48dbd:	imul   $0x1d8,%rax,%rsi
   48dc4:	mov    $0x8,%edx
   48dc9:	call   *0x5b931(%rip)        # a4700 <_DYNAMIC+0x240>
   48dcf:	jmp    48e90 <construction_bench::main+0x1780>
   48dd4:	call   *0x5b9c6(%rip)        # a47a0 <_DYNAMIC+0x2e0>
   48dda:	mov    %rax,%r14
   48ddd:	lea    0x4f0(%rsp),%rdi
   48de5:	call   46c10 <core::ptr::drop_glue::<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>>>>
   48dea:	jmp    48e90 <construction_bench::main+0x1780>
   48def:	jmp    48e05 <construction_bench::main+0x16f5>
   48df1:	mov    %rax,%r14
   48df4:	lea    0x300(%rsp),%rdi
   48dfc:	call   46e60 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48e01:	jmp    48e5d <construction_bench::main+0x174d>
   48e03:	jmp    48e05 <construction_bench::main+0x16f5>
   48e05:	mov    %rax,%r14
   48e08:	mov    $0x1,%bpl
   48e0b:	mov    0x110(%rsp),%rax
   48e13:	cmp    $0xa,%rax
   48e17:	ja     48e24 <construction_bench::main+0x1714>
   48e19:	mov    $0x51c,%ecx
   48e1e:	bt     %rax,%rcx
   48e22:	jb     48e60 <construction_bench::main+0x1750>
   48e24:	mov    0x118(%rsp),%rsi
   48e2c:	test   %rsi,%rsi
   48e2f:	je     48e60 <construction_bench::main+0x1750>
   48e31:	mov    0x120(%rsp),%rdi
   48e39:	mov    $0x1,%edx
   48e3e:	call   *0x5b8bc(%rip)        # a4700 <_DYNAMIC+0x240>
   48e44:	jmp    48e60 <construction_bench::main+0x1750>
   48e46:	jmp    48e5a <construction_bench::main+0x174a>
   48e48:	mov    %rax,%r14
   48e4b:	mov    0xd0(%rsp),%rax
   48e53:	mov    %rax,0x28(%rsp)
   48e58:	jmp    48e90 <construction_bench::main+0x1780>
   48e5a:	mov    %rax,%r14
   48e5d:	mov    $0x1,%bpl
   48e60:	mov    0x30(%rsp),%rsi
   48e65:	test   %rsi,%rsi
   48e68:	je     48e7e <construction_bench::main+0x176e>
   48e6a:	mov    0x38(%rsp),%rdi
   48e6f:	shl    $0x3,%rsi
   48e73:	mov    $0x4,%edx
   48e78:	call   *0x5b882(%rip)        # a4700 <_DYNAMIC+0x240>
   48e7e:	test   %bpl,%bpl
   48e81:	je     48e90 <construction_bench::main+0x1780>
   48e83:	lea    0x4f0(%rsp),%rdi
   48e8b:	call   46e60 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48e90:	mov    0xd8(%rsp),%rbx
   48e98:	test   %rbx,%rbx
   48e9b:	jne    48eca <construction_bench::main+0x17ba>
   48e9d:	mov    0xc8(%rsp),%rax
   48ea5:	test   %rax,%rax
   48ea8:	je     48ec2 <construction_bench::main+0x17b2>
   48eaa:	shl    $0x3,%rax
   48eae:	lea    (%rax,%rax,2),%rsi
   48eb2:	mov    $0x8,%edx
   48eb7:	mov    0x28(%rsp),%rdi
   48ebc:	call   *0x5b83e(%rip)        # a4700 <_DYNAMIC+0x240>
   48ec2:	mov    %r14,%rdi
   48ec5:	call   9fdf0 <_Unwind_Resume@plt>
   48eca:	mov    0x28(%rsp),%rax
   48ecf:	lea    0x8(%rax),%r15
   48ed3:	mov    0x5b826(%rip),%r12        # a4700 <_DYNAMIC+0x240>
   48eda:	jmp    48ee9 <construction_bench::main+0x17d9>
   48edc:	nopl   0x0(%rax)
   48ee0:	add    $0x18,%r15
   48ee4:	dec    %rbx
   48ee7:	je     48e9d <construction_bench::main+0x178d>
   48ee9:	mov    -0x8(%r15),%rsi
   48eed:	test   %rsi,%rsi
   48ef0:	je     48ee0 <construction_bench::main+0x17d0>
   48ef2:	mov    (%r15),%rdi
   48ef5:	mov    $0x1,%edx
   48efa:	call   *%r12
   48efd:	jmp    48ee0 <construction_bench::main+0x17d0>
   48eff:	call   *0x5b89b(%rip)        # a47a0 <_DYNAMIC+0x2e0>
   48f05:	int3
   48f06:	int3
   48f07:	int3
   48f08:	int3
   48f09:	int3
   48f0a:	int3
   48f0b:	int3
   48f0c:	int3
   48f0d:	int3
   48f0e:	int3
   48f0f:	int3
