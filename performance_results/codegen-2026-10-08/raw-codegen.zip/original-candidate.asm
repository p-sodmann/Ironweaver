   47760:	push   %rbp
   47761:	push   %r15
   47763:	push   %r14
   47765:	push   %r13
   47767:	push   %r12
   47769:	push   %rbx
   4776a:	sub    $0x6e8,%rsp
   47771:	lea    0x110(%rsp),%r12
   47779:	mov    %r12,%rdi
   4777c:	call   *0x5d2ce(%rip)        # a4a50 <_DYNAMIC+0x530>
   47782:	lea    0xc8(%rsp),%rdi
   4778a:	mov    %r12,%rsi
   4778d:	call   40c90 <<alloc::vec::Vec<alloc::string::String> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<alloc::string::String, std::env::Args>>::from_iter>
   47792:	mov    0xd8(%rsp),%rcx
   4779a:	cmp    $0x2,%rcx
   4779e:	mov    %rcx,0xa8(%rsp)
   477a6:	jb     48d1b <construction_bench::main+0x15bb>
   477ac:	mov    0xd0(%rsp),%rax
   477b4:	mov    %rax,0x28(%rsp)
   477b9:	add    $0x18,%rax
   477bd:	mov    %rax,0xf0(%rsp)
   477c5:	cmp    $0x2,%rcx
   477c9:	je     48d29 <construction_bench::main+0x15c9>
   477cf:	mov    0x28(%rsp),%rax
   477d4:	mov    0x38(%rax),%rcx
   477d8:	mov    0x40(%rax),%rsi
   477dc:	cmp    $0x1,%rsi
   477e0:	je     477f0 <construction_bench::main+0x90>
   477e2:	test   %rsi,%rsi
   477e5:	je     48d45 <construction_bench::main+0x15e5>
   477eb:	movzbl (%rcx),%edx
   477ee:	jmp    47807 <construction_bench::main+0xa7>
   477f0:	movzbl (%rcx),%edx
   477f3:	mov    $0x1,%al
   477f5:	cmp    $0x2b,%edx
   477f8:	je     48afb <construction_bench::main+0x139b>
   477fe:	cmp    $0x2d,%edx
   47801:	je     48afb <construction_bench::main+0x139b>
   47807:	xor    %eax,%eax
   47809:	cmp    $0x2b,%dl
   4780c:	sete   %al
   4780f:	mov    %rsi,%rdx
   47812:	sub    %rax,%rdx
   47815:	add    %rax,%rcx
   47818:	neg    %rax
   4781b:	cmp    $0x11,%rdx
   4781f:	jae    47857 <construction_bench::main+0xf7>
   47821:	test   %rdx,%rdx
   47824:	je     478a2 <construction_bench::main+0x142>
   47826:	add    %rax,%rsi
   47829:	neg    %rsi
   4782c:	xor    %eax,%eax
   4782e:	xor    %edx,%edx
   47830:	movzbl (%rcx,%rdx,1),%edi
   47834:	add    $0xffffffd0,%edi
   47837:	cmp    $0x9,%edi
   4783a:	ja     48cfa <construction_bench::main+0x159a>
   47840:	lea    (%rax,%rax,4),%rax
   47844:	mov    %edi,%edi
   47846:	lea    (%rdi,%rax,2),%rax
   4784a:	inc    %rdx
   4784d:	mov    %rsi,%rdi
   47850:	add    %rdx,%rdi
   47853:	jne    47830 <construction_bench::main+0xd0>
   47855:	jmp    478a4 <construction_bench::main+0x144>
   47857:	add    %rax,%rsi
   4785a:	neg    %rsi
   4785d:	xor    %eax,%eax
   4785f:	mov    $0xa,%edi
   47864:	xor    %r8d,%r8d
   47867:	nopw   0x0(%rax,%rax,1)
   47870:	mul    %rdi
   47873:	movzbl (%rcx,%r8,1),%edx
   47878:	jo     48aed <construction_bench::main+0x138d>
   4787e:	add    $0xffffffd0,%edx
   47881:	cmp    $0xa,%edx
   47884:	jae    48cfa <construction_bench::main+0x159a>
   4788a:	mov    %edx,%edx
   4788c:	add    %rdx,%rax
   4788f:	jb     48af9 <construction_bench::main+0x1399>
   47895:	inc    %r8
   47898:	mov    %rsi,%rdx
   4789b:	add    %r8,%rdx
   4789e:	jne    47870 <construction_bench::main+0x110>
   478a0:	jmp    478a4 <construction_bench::main+0x144>
   478a2:	xor    %eax,%eax
   478a4:	mov    %rax,0x58(%rsp)
   478a9:	lea    (%rax,%rax,4),%rax
   478ad:	mov    %rax,0x50(%rsp)
   478b2:	mov    $0x7,%ebx
   478b7:	cmpq   $0x4,0xa8(%rsp)
   478c0:	jb     479aa <construction_bench::main+0x24a>
   478c6:	mov    0x28(%rsp),%rax
   478cb:	mov    0x50(%rax),%rcx
   478cf:	mov    0x58(%rax),%rsi
   478d3:	cmp    $0x1,%rsi
   478d7:	je     478e7 <construction_bench::main+0x187>
   478d9:	test   %rsi,%rsi
   478dc:	je     48d4c <construction_bench::main+0x15ec>
   478e2:	movzbl (%rcx),%edx
   478e5:	jmp    478fe <construction_bench::main+0x19e>
   478e7:	movzbl (%rcx),%edx
   478ea:	mov    $0x1,%al
   478ec:	cmp    $0x2b,%edx
   478ef:	je     48b80 <construction_bench::main+0x1420>
   478f5:	cmp    $0x2d,%edx
   478f8:	je     48b80 <construction_bench::main+0x1420>
   478fe:	xor    %eax,%eax
   47900:	cmp    $0x2b,%dl
   47903:	sete   %al
   47906:	mov    %rsi,%rdx
   47909:	sub    %rax,%rdx
   4790c:	add    %rax,%rcx
   4790f:	neg    %rax
   47912:	cmp    $0x11,%rdx
   47916:	jae    47957 <construction_bench::main+0x1f7>
   47918:	test   %rdx,%rdx
   4791b:	je     479a8 <construction_bench::main+0x248>
   47921:	add    %rax,%rsi
   47924:	neg    %rsi
   47927:	xor    %ebx,%ebx
   47929:	xor    %eax,%eax
   4792b:	nopl   0x0(%rax,%rax,1)
   47930:	movzbl (%rcx,%rax,1),%edx
   47934:	add    $0xffffffd0,%edx
   47937:	cmp    $0x9,%edx
   4793a:	ja     48d01 <construction_bench::main+0x15a1>
   47940:	lea    (%rbx,%rbx,4),%rdi
   47944:	mov    %edx,%edx
   47946:	lea    (%rdx,%rdi,2),%rbx
   4794a:	inc    %rax
   4794d:	mov    %rsi,%rdx
   47950:	add    %rax,%rdx
   47953:	jne    47930 <construction_bench::main+0x1d0>
   47955:	jmp    479aa <construction_bench::main+0x24a>
   47957:	add    %rax,%rsi
   4795a:	neg    %rsi
   4795d:	xor    %ebx,%ebx
   4795f:	mov    $0xa,%edi
   47964:	xor    %r8d,%r8d
   47967:	nopw   0x0(%rax,%rax,1)
   47970:	mov    %rbx,%rax
   47973:	mul    %rdi
   47976:	movzbl (%rcx,%r8,1),%edx
   4797b:	jo     48b72 <construction_bench::main+0x1412>
   47981:	add    $0xffffffd0,%edx
   47984:	cmp    $0xa,%edx
   47987:	jae    48d01 <construction_bench::main+0x15a1>
   4798d:	mov    %rax,%rbx
   47990:	mov    %edx,%eax
   47992:	add    %rax,%rbx
   47995:	jb     48b7e <construction_bench::main+0x141e>
   4799b:	inc    %r8
   4799e:	mov    %rsi,%rax
   479a1:	add    %r8,%rax
   479a4:	jne    47970 <construction_bench::main+0x210>
   479a6:	jmp    479aa <construction_bench::main+0x24a>
   479a8:	xor    %ebx,%ebx
   479aa:	lea    -0x3d0cb(%rip),%rdi        # a8e6 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x6>
   479b1:	mov    $0x1f,%esi
   479b6:	call   *0x5d09c(%rip)        # a4a58 <_DYNAMIC+0x538>
   479bc:	add    $0x2,%rbx
   479c0:	je     489e7 <construction_bench::main+0x1287>
   479c6:	lea    0x118(%rsp),%rax
   479ce:	mov    %rax,0xe8(%rsp)
   479d6:	lea    0x11c(%rsp),%rax
   479de:	mov    %rax,0xe0(%rsp)
   479e6:	movq   $0x0,0xb0(%rsp)
   479f2:	lea    0x110(%rsp),%r12
   479fa:	mov    0x5ce1f(%rip),%r14        # a4820 <_DYNAMIC+0x300>
   47a01:	lea    0x60(%rsp),%rax
   47a06:	mov    %rax,0xc0(%rsp)
   47a0e:	mov    %rbx,0x98(%rsp)
   47a16:	jmp    47a3c <construction_bench::main+0x2dc>
   47a18:	nopl   0x0(%rax,%rax,1)
   47a20:	mov    0xb0(%rsp),%rcx
   47a28:	inc    %rcx
   47a2b:	mov    %rcx,0xb0(%rsp)
   47a33:	cmp    %rbx,%rcx
   47a36:	je     489e7 <construction_bench::main+0x1287>
   47a3c:	mov    0x28(%rsp),%rax
   47a41:	cmpq   $0xa,0x28(%rax)
   47a46:	jne    47a74 <construction_bench::main+0x314>
   47a48:	mov    0x28(%rsp),%rax
   47a4d:	mov    0x20(%rax),%rax
   47a51:	mov    (%rax),%rcx
   47a54:	movabs $0x65727275636e6f63,%rdx
   47a5e:	xor    %rdx,%rcx
   47a61:	movzwl 0x8(%rax),%eax
   47a65:	xor    $0x746e,%rax
   47a6b:	or     %rcx,%rax
   47a6e:	je     47fb5 <construction_bench::main+0x855>
   47a74:	mov    0x58(%rsp),%rbp
   47a79:	mov    0x50(%rsp),%rdx
   47a7e:	lea    0x300(%rsp),%r15
   47a86:	mov    %r15,%rdi
   47a89:	mov    %rbp,%rsi
   47a8c:	call   3b560 <<ironweaver_core::graph::Graph<(), ()>>::with_capacity>
   47a91:	mov    0x28(%rsp),%r13
   47a96:	movq   $0x0,0x4f8(%rsp)
   47aa2:	mov    %rbp,0x500(%rsp)
   47aaa:	mov    %r15,0x4f0(%rsp)
   47ab2:	lea    0x30(%rsp),%rdi
   47ab7:	lea    0x4f0(%rsp),%rbp
   47abf:	mov    %rbp,%rsi
   47ac2:	call   40ff0 <<alloc::vec::Vec<ironweaver_core::graph::NodeIx> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<ironweaver_core::graph::NodeIx, core::iter::adapters::map::Map<core::ops::range::Range<usize>, construction_bench::fixture::{closure#0}>>>::from_iter>
   47ac7:	mov    $0x1d8,%edx
   47acc:	mov    %r12,%rdi
   47acf:	mov    %r15,%rsi
   47ad2:	mov    0x5cccf(%rip),%r15        # a47a8 <memcpy@GLIBC_2.14>
   47ad9:	call   *%r15
   47adc:	mov    %r15,%rcx
   47adf:	movups 0x30(%rsp),%xmm0
   47ae4:	lea    0x118(%rsp),%r15
   47aec:	movups %xmm0,0x1d0(%r15)
   47af4:	mov    0x40(%rsp),%rax
   47af9:	mov    %rax,0x1e0(%r15)
   47b00:	mov    $0x1d8,%edx
   47b05:	mov    %rbp,%rdi
   47b08:	mov    %r12,%rbp
   47b0b:	mov    %r12,%rsi
   47b0e:	call   *%rcx
   47b10:	mov    0x1e0(%r15),%rax
   47b17:	mov    %rax,0x40(%rsp)
   47b1c:	movupd 0x1d0(%r15),%xmm0
   47b25:	movapd %xmm0,0x30(%rsp)
   47b2b:	mov    0x20(%r13),%rcx
   47b2f:	mov    0x28(%r13),%rax
   47b33:	cmp    $0x9,%rax
   47b37:	jne    47b70 <construction_bench::main+0x410>
   47b39:	mov    (%rcx),%rdx
   47b3c:	movabs $0x726f62686769656e,%rsi
   47b46:	xor    %rsi,%rdx
   47b49:	movzbl 0x8(%rcx),%esi
   47b4d:	xor    $0x73,%rsi
   47b51:	or     %rdx,%rsi
   47b54:	mov    %rbp,%r12
   47b57:	lea    0x4d8(%rsp),%r13
   47b5f:	lea    0x4f0(%rsp),%rbp
   47b67:	jne    47b8d <construction_bench::main+0x42d>
   47b69:	jmp    47de0 <construction_bench::main+0x680>
   47b6e:	xchg   %ax,%ax
   47b70:	cmp    $0x8,%rax
   47b74:	mov    %rbp,%r12
   47b77:	lea    0x4d8(%rsp),%r13
   47b7f:	lea    0x4f0(%rsp),%rbp
   47b87:	jb     47e22 <construction_bench::main+0x6c2>
   47b8d:	movabs $0x6870617267627573,%rdx
   47b97:	cmp    (%rcx),%rdx
   47b9a:	je     47de0 <construction_bench::main+0x680>
   47ba0:	cmp    $0xe,%rax
   47ba4:	jne    47e22 <construction_bench::main+0x6c2>
   47baa:	mov    0x28(%rsp),%rax
   47baf:	mov    0x20(%rax),%rax
   47bb3:	mov    (%rax),%rcx
   47bb6:	movabs $0x6870617267627573,%rdx
   47bc0:	xor    %rdx,%rcx
   47bc3:	mov    0x6(%rax),%rax
   47bc7:	movabs $0x6c6c616d732d6870,%rdx
   47bd1:	xor    %rdx,%rax
   47bd4:	or     %rcx,%rax
   47bd7:	jne    47e49 <construction_bench::main+0x6e9>
   47bdd:	movl   $0x0,0x88(%rsp)
   47be8:	lea    0x88(%rsp),%rax
   47bf0:	mov    %rax,0x110(%rsp)
   47bf8:	mov    0x5ce61(%rip),%rax        # a4a60 <_DYNAMIC+0x540>
   47bff:	mov    %rax,0x118(%rsp)
   47c07:	lea    0xf8(%rsp),%rdi
   47c0f:	lea    -0x3e7a1(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47c16:	mov    %r12,%rdx
   47c19:	call   *%r14
   47c1c:	lea    0x300(%rsp),%rdi
   47c24:	mov    %rbp,%rsi
   47c27:	lea    0xf8(%rsp),%rdx
   47c2f:	call   39440 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47c34:	cmpl   $0xffffffff,0x300(%rsp)
   47c3c:	jne    48baf <construction_bench::main+0x144f>
   47c42:	movsd  0x308(%rsp),%xmm0
   47c4b:	movapd %xmm0,0x70(%rsp)
   47c51:	mov    0x40(%rsp),%r15
   47c56:	cmp    0x30(%rsp),%r15
   47c5b:	jne    47c68 <construction_bench::main+0x508>
   47c5d:	lea    0x30(%rsp),%rdi
   47c62:	call   *0x5ce00(%rip)        # a4a68 <_DYNAMIC+0x548>
   47c68:	mov    0x38(%rsp),%rax
   47c6d:	movapd 0x70(%rsp),%xmm0
   47c73:	movlpd %xmm0,(%rax,%r15,8)
   47c79:	inc    %r15
   47c7c:	mov    %r15,0x40(%rsp)
   47c81:	movl   $0x1,0x88(%rsp)
   47c8c:	lea    0x88(%rsp),%rax
   47c94:	mov    %rax,0x110(%rsp)
   47c9c:	mov    0x5cdbd(%rip),%rax        # a4a60 <_DYNAMIC+0x540>
   47ca3:	mov    %rax,0x118(%rsp)
   47cab:	lea    0xf8(%rsp),%rdi
   47cb3:	lea    -0x3e845(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47cba:	mov    %r12,%rdx
   47cbd:	call   *%r14
   47cc0:	lea    0x300(%rsp),%rdi
   47cc8:	mov    %rbp,%rsi
   47ccb:	lea    0xf8(%rsp),%rdx
   47cd3:	call   39440 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47cd8:	cmpl   $0xffffffff,0x300(%rsp)
   47ce0:	jne    48baf <construction_bench::main+0x144f>
   47ce6:	movsd  0x308(%rsp),%xmm0
   47cef:	movapd %xmm0,0x70(%rsp)
   47cf5:	mov    0x40(%rsp),%r15
   47cfa:	cmp    0x30(%rsp),%r15
   47cff:	jne    47d0c <construction_bench::main+0x5ac>
   47d01:	lea    0x30(%rsp),%rdi
   47d06:	call   *0x5cd5c(%rip)        # a4a68 <_DYNAMIC+0x548>
   47d0c:	mov    0x38(%rsp),%rax
   47d11:	movapd 0x70(%rsp),%xmm0
   47d17:	movlpd %xmm0,(%rax,%r15,8)
   47d1d:	inc    %r15
   47d20:	mov    %r15,0x40(%rsp)
   47d25:	movl   $0x2,0x88(%rsp)
   47d30:	lea    0x88(%rsp),%rax
   47d38:	mov    %rax,0x110(%rsp)
   47d40:	mov    0x5cd19(%rip),%rax        # a4a60 <_DYNAMIC+0x540>
   47d47:	mov    %rax,0x118(%rsp)
   47d4f:	lea    0xf8(%rsp),%rdi
   47d57:	lea    -0x3e8e9(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47d5e:	mov    %r12,%rdx
   47d61:	call   *%r14
   47d64:	lea    0x300(%rsp),%rdi
   47d6c:	mov    %rbp,%rsi
   47d6f:	lea    0xf8(%rsp),%rdx
   47d77:	call   39440 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47d7c:	cmpl   $0xffffffff,0x300(%rsp)
   47d84:	jne    48baf <construction_bench::main+0x144f>
   47d8a:	movsd  0x308(%rsp),%xmm0
   47d93:	movapd %xmm0,0x70(%rsp)
   47d99:	mov    0x40(%rsp),%r15
   47d9e:	cmp    0x30(%rsp),%r15
   47da3:	jne    47db0 <construction_bench::main+0x650>
   47da5:	lea    0x30(%rsp),%rdi
   47daa:	call   *0x5ccb8(%rip)        # a4a68 <_DYNAMIC+0x548>
   47db0:	mov    0x38(%rsp),%rax
   47db5:	movapd 0x70(%rsp),%xmm0
   47dbb:	movlpd %xmm0,(%rax,%r15,8)
   47dc1:	inc    %r15
   47dc4:	mov    %r15,0x40(%rsp)
   47dc9:	mov    0x28(%rsp),%rax
   47dce:	mov    0x28(%rax),%rax
   47dd2:	cmp    $0x5,%rax
   47dd6:	je     47e28 <construction_bench::main+0x6c8>
   47dd8:	jmp    47e49 <construction_bench::main+0x6e9>
   47dda:	nopw   0x0(%rax,%rax,1)
   47de0:	mov    0x38(%rsp),%rsi
   47de5:	mov    0x40(%rsp),%rdx
   47dea:	mov    %rbp,%rdi
   47ded:	mov    $0x1,%bpl
   47df0:	mov    0x50(%rsp),%rcx
   47df5:	mov    $0x6,%r9d
   47dfb:	lea    -0x3d522(%rip),%r8        # a8e0 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111>
   47e02:	call   48f60 <construction_bench::edges>
   47e07:	mov    0x28(%rsp),%rax
   47e0c:	mov    0x28(%rax),%rax
   47e10:	lea    0x4f0(%rsp),%rbp
   47e18:	cmp    $0xe,%rax
   47e1c:	je     47baa <construction_bench::main+0x44a>
   47e22:	cmp    $0x5,%rax
   47e26:	jne    47e49 <construction_bench::main+0x6e9>
   47e28:	mov    0x28(%rsp),%rax
   47e2d:	mov    0x20(%rax),%rax
   47e31:	mov    (%rax),%ecx
   47e33:	mov    $0x6c617473,%edx
   47e38:	xor    %edx,%ecx
   47e3a:	movzbl 0x4(%rax),%eax
   47e3e:	xor    $0x65,%eax
   47e41:	or     %ecx,%eax
   47e43:	je     48780 <construction_bench::main+0x1020>
   47e49:	xor    %r15d,%r15d
   47e4c:	mov    $0x1,%bpl
   47e4f:	call   *0x5cc1b(%rip)        # a4a70 <_DYNAMIC+0x550>
   47e55:	mov    %rax,0x88(%rsp)
   47e5d:	mov    %edx,0x90(%rsp)
   47e64:	mov    0x28(%rsp),%rax
   47e69:	mov    0x20(%rax),%r8
   47e6d:	mov    0x28(%rax),%r9
   47e71:	lea    -0x5(%r9),%rax
   47e75:	cmp    $0x9,%rax
   47e79:	ja     48540 <construction_bench::main+0xde0>
   47e7f:	lea    -0x3d626(%rip),%rcx        # a860 <anon.5d09ad63f943746d04ae2dafc92c2e77.3.llvm.11945693191618023075+0x74>
   47e86:	movslq (%rcx,%rax,4),%rax
   47e8a:	add    %rcx,%rax
   47e8d:	jmp    *%rax
   47e8f:	mov    (%r8),%eax
   47e92:	mov    $0x65646f6e,%ecx
   47e97:	xor    %ecx,%eax
   47e99:	movzbl 0x4(%r8),%ecx
   47e9e:	xor    $0x73,%ecx
   47ea1:	or     %eax,%ecx
   47ea3:	je     4880f <construction_bench::main+0x10af>
   47ea9:	mov    (%r8),%eax
   47eac:	mov    $0x6c617473,%ecx
   47eb1:	xor    %ecx,%eax
   47eb3:	movzbl 0x4(%r8),%ecx
   47eb8:	xor    $0x65,%ecx
   47ebb:	or     %eax,%ecx
   47ebd:	jne    48540 <construction_bench::main+0xde0>
   47ec3:	cmpq   $0x0,0x50(%rsp)
   47ec9:	je     4855c <construction_bench::main+0xdfc>
   47ecf:	test   %r15b,%r15b
   47ed2:	je     48cbe <construction_bench::main+0x155e>
   47ed8:	xor    %r15d,%r15d
   47edb:	jmp    47eee <construction_bench::main+0x78e>
   47edd:	nopl   (%rax)
   47ee0:	inc    %r15
   47ee3:	cmp    0x50(%rsp),%r15
   47ee8:	jae    4855c <construction_bench::main+0xdfc>
   47eee:	cmpq   $0x0,0x40(%rsp)
   47ef4:	je     48d08 <construction_bench::main+0x15a8>
   47efa:	mov    0x38(%rsp),%rax
   47eff:	mov    (%rax),%r8d
   47f02:	mov    0x4(%rax),%r9d
   47f06:	movq   $0x0,0x10(%rsp)
   47f0f:	movq   $0x0,(%rsp)
   47f17:	mov    %r12,%rdi
   47f1a:	lea    0x4f0(%rsp),%rsi
   47f22:	mov    0xbc(%rsp),%edx
   47f29:	mov    0xb8(%rsp),%ecx
   47f30:	call   39df0 <<ironweaver_core::graph::Graph<(), ()>>::insert_edge>
   47f35:	cmpl   $0xffffffff,0x110(%rsp)
   47f3d:	je     48b0e <construction_bench::main+0x13ae>
   47f43:	movupd 0x110(%rsp),%xmm0
   47f4c:	movupd 0x120(%rsp),%xmm1
   47f55:	movapd %xmm1,0x310(%rsp)
   47f5e:	movapd %xmm0,0x300(%rsp)
   47f67:	lea    0x300(%rsp),%rax
   47f6f:	mov    0x300(%rsp),%rax
   47f77:	cmp    $0xa,%rax
   47f7b:	ja     47f8c <construction_bench::main+0x82c>
   47f7d:	mov    $0x51c,%ecx
   47f82:	bt     %rax,%rcx
   47f86:	jb     47ee0 <construction_bench::main+0x780>
   47f8c:	mov    0x308(%rsp),%rsi
   47f94:	test   %rsi,%rsi
   47f97:	je     47ee0 <construction_bench::main+0x780>
   47f9d:	mov    0x310(%rsp),%rdi
   47fa5:	mov    $0x1,%edx
   47faa:	call   *0x5c7b0(%rip)        # a4760 <_DYNAMIC+0x240>
   47fb0:	jmp    47ee0 <construction_bench::main+0x780>
   47fb5:	movabs $0x400000000,%rax
   47fbf:	mov    %rax,0x120(%rsp)
   47fc7:	lea    0x58(%rsp),%rax
   47fcc:	mov    %rax,0x110(%rsp)
   47fd4:	lea    0x50(%rsp),%rax
   47fd9:	mov    %rax,0x118(%rsp)
   47fe1:	lea    0x30(%rsp),%rdi
   47fe6:	mov    %r12,%rsi
   47fe9:	call   41100 <<alloc::vec::Vec<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>), core::iter::adapters::map::Map<core::ops::range::Range<i32>, construction_bench::main::{closure#1}>>>::from_iter>
   47fee:	call   *0x5ca7c(%rip)        # a4a70 <_DYNAMIC+0x550>
   47ff4:	mov    %rax,0x88(%rsp)
   47ffc:	mov    %edx,0x90(%rsp)
   48003:	mov    0x40(%rsp),%rax
   48008:	mov    %rax,0x120(%rsp)
   48010:	movups 0x30(%rsp),%xmm0
   48015:	movaps %xmm0,0x110(%rsp)
   4801d:	movq   $0x0,0x300(%rsp)
   48029:	movq   $0x8,0x308(%rsp)
   48035:	movq   $0x0,0x310(%rsp)
   48041:	lea    0x50(%rsp),%rax
   48046:	mov    %rax,0x128(%rsp)
   4804e:	lea    0x300(%rsp),%rdi
   48056:	mov    %r12,%rsi
   48059:	call   40c60 <<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>> as rayon::iter::ParallelExtend<ironweaver_core::graph::Graph<(), ()>>>::par_extend::<rayon::iter::map::Map<rayon::vec::IntoIter<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)>, construction_bench::main::{closure#2}>>>
   4805e:	movupd 0x300(%rsp),%xmm0
   48067:	movapd %xmm0,0x4f0(%rsp)
   48070:	mov    0x310(%rsp),%rax
   48078:	mov    %rax,0x500(%rsp)
   48080:	lea    0x88(%rsp),%rdi
   48088:	call   *0x5c9ea(%rip)        # a4a78 <_DYNAMIC+0x558>
   4808e:	movq   %rax,%xmm0
   48093:	punpckldq -0x403db(%rip),%xmm0        # 7cc0 <anon.dfee4cbf5dd847bdf7978be4d7a189df.0.llvm.10118388184640623510+0x70>
   4809b:	xorps  %xmm1,%xmm1
   4809e:	cvtsi2sd %edx,%xmm1
   480a2:	subpd  -0x4044a(%rip),%xmm0        # 7c60 <anon.dfee4cbf5dd847bdf7978be4d7a189df.0.llvm.10118388184640623510+0x10>
   480aa:	movapd %xmm0,0x70(%rsp)
   480b0:	divsd  -0x3dc58(%rip),%xmm1        # a460 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763+0x88>
   480b8:	movsd  %xmm1,0x68(%rsp)
   480be:	mov    0x500(%rsp),%rcx
   480c6:	test   %rcx,%rcx
   480c9:	je     48107 <construction_bench::main+0x9a7>
   480cb:	mov    0x4f8(%rsp),%rax
   480d3:	imul   $0x1d8,%rcx,%rcx
   480da:	mov    0x50(%rsp),%rdx
   480df:	xor    %esi,%esi
   480e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   480f0:	cmp    %rdx,0x68(%rax,%rsi,1)
   480f5:	jne    48cdf <construction_bench::main+0x157f>
   480fb:	add    $0x1d8,%rsi
   48102:	cmp    %rsi,%rcx
   48105:	jne    480f0 <construction_bench::main+0x990>
   48107:	mov    0x500(%rsp),%rax
   4810f:	mov    %rax,0x120(%rsp)
   48117:	movapd 0x4f0(%rsp),%xmm0
   48120:	movapd %xmm0,0x110(%rsp)
   48129:	mov    0x120(%rsp),%rax
   48131:	test   %rax,%rax
   48134:	je     48168 <construction_bench::main+0xa08>
   48136:	mov    0x118(%rsp),%rbp
   4813e:	mov    $0x1,%r15d
   48144:	sub    %rax,%r15
   48147:	nopw   0x0(%rax,%rax,1)
   48150:	mov    %rbp,%rdi
   48153:	call   40610 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48158:	add    $0x1d8,%rbp
   4815f:	inc    %r15
   48162:	cmp    $0x1,%r15
   48166:	jne    48150 <construction_bench::main+0x9f0>
   48168:	mov    0x110(%rsp),%rax
   48170:	test   %rax,%rax
   48173:	je     4818f <construction_bench::main+0xa2f>
   48175:	mov    0x118(%rsp),%rdi
   4817d:	imul   $0x1d8,%rax,%rsi
   48184:	mov    $0x8,%edx
   48189:	call   *0x5c5d1(%rip)        # a4760 <_DYNAMIC+0x240>
   4818f:	movapd 0x70(%rsp),%xmm1
   48195:	movapd %xmm1,%xmm0
   48199:	unpckhpd %xmm1,%xmm0
   4819d:	addsd  %xmm1,%xmm0
   481a1:	movsd  0x68(%rsp),%xmm1
   481a7:	addsd  %xmm0,%xmm1
   481ab:	movsd  %xmm1,0x300(%rsp)
   481b4:	jmp    48702 <construction_bench::main+0xfa2>
   481b9:	mov    (%r8),%rax
   481bc:	movabs $0x726f62686769656e,%rcx
   481c6:	xor    %rcx,%rax
   481c9:	movzbl 0x8(%r8),%ecx
   481ce:	xor    $0x73,%rcx
   481d2:	or     %rax,%rcx
   481d5:	jne    48540 <construction_bench::main+0xde0>
   481db:	mov    0x40(%rsp),%r11
   481e0:	test   %r11,%r11
   481e3:	je     489a2 <construction_bench::main+0x1242>
   481e9:	mov    0x38(%rsp),%rcx
   481ee:	mov    0x4f8(%rsp),%r15
   481f6:	mov    0x500(%rsp),%r13
   481fe:	mov    0x538(%rsp),%rdi
   48206:	mov    0x530(%rsp),%r9
   4820e:	xor    %r10d,%r10d
   48211:	xor    %r8d,%r8d
   48214:	mov    %r13,0x70(%rsp)
   48219:	mov    %r11,0x68(%rsp)
   4821e:	mov    %r15,0xa0(%rsp)
   48226:	jmp    48246 <construction_bench::main+0xae6>
   48228:	nopl   0x0(%rax,%rax,1)
   48230:	xor    %esi,%esi
   48232:	xor    %eax,%eax
   48234:	add    %rsi,%r8
   48237:	add    %rax,%r8
   4823a:	inc    %r10
   4823d:	cmp    %r11,%r10
   48240:	je     489a5 <construction_bench::main+0x1245>
   48246:	mov    (%rcx,%r10,8),%eax
   4824a:	cmp    %rax,%r13
   4824d:	jbe    48230 <construction_bench::main+0xad0>
   4824f:	mov    0x4(%rcx,%r10,8),%edx
   48254:	imul   $0x68,%rax,%rax
   48258:	cmp    %edx,0x60(%r15,%rax,1)
   4825d:	jne    48230 <construction_bench::main+0xad0>
   4825f:	add    %r15,%rax
   48262:	cmpq   $0xffffffffffffffff,(%rax)
   48266:	je     48230 <construction_bench::main+0xad0>
   48268:	mov    0x40(%rax),%r15
   4826c:	mov    0x50(%rax),%rdx
   48270:	mov    0x58(%rax),%r11
   48274:	test   %r15,%r15
   48277:	je     483b7 <construction_bench::main+0xc57>
   4827d:	mov    0x38(%rax),%rax
   48281:	mov    (%rax),%esi
   48283:	cmp    %rsi,%rdi
   48286:	jbe    48a66 <construction_bench::main+0x1306>
   4828c:	lea    (%rsi,%rsi,4),%rsi
   48290:	mov    0x20(%r9,%rsi,8),%r13d
   48295:	cmp    0x4(%rax),%r13d
   48299:	jne    48a66 <construction_bench::main+0x1306>
   4829f:	lea    (%r9,%rsi,8),%rsi
   482a3:	cmpl   $0x2,(%rsi)
   482a6:	je     48a66 <construction_bench::main+0x1306>
   482ac:	mov    $0x1,%esi
   482b1:	cmp    $0x1,%r15
   482b5:	mov    0x98(%rsp),%rbx
   482bd:	mov    0x70(%rsp),%r13
   482c2:	je     48316 <construction_bench::main+0xbb6>
   482c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   482d0:	mov    (%rax,%rsi,8),%r13d
   482d4:	cmp    %r13,%rdi
   482d7:	jbe    48a66 <construction_bench::main+0x1306>
   482dd:	lea    0x0(%r13,%r13,4),%r13
   482e2:	mov    0x20(%r9,%r13,8),%ebx
   482e7:	cmp    0x4(%rax,%rsi,8),%ebx
   482eb:	jne    48a66 <construction_bench::main+0x1306>
   482f1:	lea    (%r9,%r13,8),%rbx
   482f5:	cmpl   $0x2,(%rbx)
   482f8:	je     48a66 <construction_bench::main+0x1306>
   482fe:	inc    %rsi
   48301:	cmp    %rsi,%r15
   48304:	jne    482d0 <construction_bench::main+0xb70>
   48306:	mov    %r15,%rsi
   48309:	mov    0x98(%rsp),%rbx
   48311:	mov    0x70(%rsp),%r13
   48316:	test   %r11,%r11
   48319:	je     483c2 <construction_bench::main+0xc62>
   4831f:	mov    (%rdx),%eax
   48321:	cmp    %rax,%rdi
   48324:	jbe    48a66 <construction_bench::main+0x1306>
   4832a:	lea    (%rax,%rax,4),%rax
   4832e:	mov    0x20(%r9,%rax,8),%ebx
   48333:	cmp    0x4(%rdx),%ebx
   48336:	jne    48a66 <construction_bench::main+0x1306>
   4833c:	lea    (%r9,%rax,8),%rax
   48340:	cmpl   $0x2,(%rax)
   48343:	je     48a66 <construction_bench::main+0x1306>
   48349:	mov    $0x1,%eax
   4834e:	cmp    $0x1,%r11
   48352:	je     48398 <construction_bench::main+0xc38>
   48354:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   48360:	mov    (%rdx,%rax,8),%r15d
   48364:	cmp    %r15,%rdi
   48367:	jbe    48a66 <construction_bench::main+0x1306>
   4836d:	lea    (%r15,%r15,4),%r15
   48371:	mov    0x20(%r9,%r15,8),%ebx
   48376:	cmp    0x4(%rdx,%rax,8),%ebx
   4837a:	jne    48a66 <construction_bench::main+0x1306>
   48380:	lea    (%r9,%r15,8),%rbx
   48384:	cmpl   $0x2,(%rbx)
   48387:	je     48a66 <construction_bench::main+0x1306>
   4838d:	inc    %rax
   48390:	cmp    %rax,%r11
   48393:	jne    48360 <construction_bench::main+0xc00>
   48395:	mov    %r11,%rax
   48398:	mov    0x98(%rsp),%rbx
   483a0:	mov    0x68(%rsp),%r11
   483a5:	mov    0xa0(%rsp),%r15
   483ad:	mov    0x70(%rsp),%r13
   483b2:	jmp    48234 <construction_bench::main+0xad4>
   483b7:	xor    %esi,%esi
   483b9:	test   %r11,%r11
   483bc:	jne    4831f <construction_bench::main+0xbbf>
   483c2:	xor    %eax,%eax
   483c4:	mov    0x68(%rsp),%r11
   483c9:	mov    0xa0(%rsp),%r15
   483d1:	jmp    48234 <construction_bench::main+0xad4>
   483d6:	movabs $0x6870617267627573,%rax
   483e0:	cmp    %rax,(%r8)
   483e3:	jne    48540 <construction_bench::main+0xde0>
   483e9:	mov    0x38(%rsp),%rdx
   483ee:	mov    0x40(%rsp),%r15
   483f3:	jmp    488bd <construction_bench::main+0x115d>
   483f8:	mov    (%r8),%rax
   483fb:	movabs $0x746163696c707564,%rcx
   48405:	xor    %rcx,%rax
   48408:	movzwl 0x8(%r8),%ecx
   4840d:	xor    $0x7365,%rcx
   48414:	or     %rax,%rcx
   48417:	jne    48540 <construction_bench::main+0xde0>
   4841d:	cmpq   $0x0,0x58(%rsp)
   48423:	je     4855c <construction_bench::main+0xdfc>
   48429:	xor    %r15d,%r15d
   4842c:	jmp    4843e <construction_bench::main+0xcde>
   4842e:	xchg   %ax,%ax
   48430:	inc    %r15
   48433:	cmp    0x58(%rsp),%r15
   48438:	jae    4855c <construction_bench::main+0xdfc>
   4843e:	mov    %r15,0x60(%rsp)
   48443:	lea    0x60(%rsp),%rax
   48448:	mov    %rax,0x300(%rsp)
   48450:	mov    0x5c461(%rip),%rax        # a48b8 <_DYNAMIC+0x398>
   48457:	mov    %rax,0x308(%rsp)
   4845f:	mov    %r13,%rdi
   48462:	lea    -0x3ee88(%rip),%rsi        # 95e1 <anon.7091b7ef657caedcc2fa209982c793b5.0.llvm.9337857877282664933>
   48469:	lea    0x300(%rsp),%rdx
   48471:	call   *%r14
   48474:	mov    %r12,%rdi
   48477:	lea    0x4f0(%rsp),%rsi
   4847f:	mov    %r13,%rdx
   48482:	call   39440 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   48487:	cmpl   $0xffffffff,0x110(%rsp)
   4848f:	je     48ad5 <construction_bench::main+0x1375>
   48495:	movupd 0x110(%rsp),%xmm0
   4849e:	movupd 0x120(%rsp),%xmm1
   484a7:	movapd %xmm1,0x310(%rsp)
   484b0:	movapd %xmm0,0x300(%rsp)
   484b9:	lea    0x300(%rsp),%rax
   484c1:	mov    0x300(%rsp),%rax
   484c9:	cmp    $0xa,%rax
   484cd:	ja     484de <construction_bench::main+0xd7e>
   484cf:	mov    $0x51c,%ecx
   484d4:	bt     %rax,%rcx
   484d8:	jb     48430 <construction_bench::main+0xcd0>
   484de:	mov    0x308(%rsp),%rsi
   484e6:	test   %rsi,%rsi
   484e9:	je     48430 <construction_bench::main+0xcd0>
   484ef:	mov    0x310(%rsp),%rdi
   484f7:	mov    $0x1,%edx
   484fc:	call   *0x5c25e(%rip)        # a4760 <_DYNAMIC+0x240>
   48502:	jmp    48430 <construction_bench::main+0xcd0>
   48507:	mov    (%r8),%rax
   4850a:	movabs $0x6870617267627573,%rcx
   48514:	xor    %rcx,%rax
   48517:	mov    0x6(%r8),%rcx
   4851b:	movabs $0x6c6c616d732d6870,%rdx
   48525:	xor    %rdx,%rcx
   48528:	or     %rax,%rcx
   4852b:	je     4889e <construction_bench::main+0x113e>
   48531:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   48540:	mov    0x38(%rsp),%rsi
   48545:	mov    0x40(%rsp),%rdx
   4854a:	mov    0x50(%rsp),%rcx
   4854f:	lea    0x4f0(%rsp),%rdi
   48557:	call   48f60 <construction_bench::edges>
   4855c:	lea    0x88(%rsp),%rdi
   48564:	call   *0x5c50e(%rip)        # a4a78 <_DYNAMIC+0x558>
   4856a:	movq   %rax,%xmm0
   4856f:	punpckldq -0x408b7(%rip),%xmm0        # 7cc0 <anon.dfee4cbf5dd847bdf7978be4d7a189df.0.llvm.10118388184640623510+0x70>
   48577:	subpd  -0x4091f(%rip),%xmm0        # 7c60 <anon.dfee4cbf5dd847bdf7978be4d7a189df.0.llvm.10118388184640623510+0x10>
   4857f:	xorps  %xmm1,%xmm1
   48582:	cvtsi2sd %edx,%xmm1
   48586:	divsd  -0x3e12e(%rip),%xmm1        # a460 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763+0x88>
   4858e:	mov    0x28(%rsp),%rax
   48593:	mov    0x28(%rax),%rcx
   48597:	add    $0xfffffffffffffffb,%rcx
   4859b:	cmp    $0x9,%rcx
   4859f:	lea    0x4f0(%rsp),%rsi
   485a7:	ja     48680 <construction_bench::main+0xf20>
   485ad:	mov    0x28(%rsp),%rax
   485b2:	mov    0x20(%rax),%rax
   485b6:	lea    -0x3dd35(%rip),%rdx        # a888 <anon.5d09ad63f943746d04ae2dafc92c2e77.3.llvm.11945693191618023075+0x9c>
   485bd:	movslq (%rdx,%rcx,4),%rcx
   485c1:	add    %rdx,%rcx
   485c4:	jmp    *%rcx
   485c6:	mov    (%rax),%ecx
   485c8:	mov    $0x65646f6e,%edx
   485cd:	xor    %edx,%ecx
   485cf:	movzbl 0x4(%rax),%edx
   485d3:	xor    $0x73,%edx
   485d6:	or     %ecx,%edx
   485d8:	je     4869b <construction_bench::main+0xf3b>
   485de:	mov    (%rax),%ecx
   485e0:	mov    $0x6c617473,%edx
   485e5:	xor    %edx,%ecx
   485e7:	movzbl 0x4(%rax),%eax
   485eb:	xor    $0x65,%eax
   485ee:	or     %ecx,%eax
   485f0:	jne    48680 <construction_bench::main+0xf20>
   485f6:	jmp    4869b <construction_bench::main+0xf3b>
   485fb:	mov    (%rax),%rcx
   485fe:	movabs $0x726f62686769656e,%rdx
   48608:	xor    %rdx,%rcx
   4860b:	movzbl 0x8(%rax),%eax
   4860f:	xor    $0x73,%rax
   48613:	or     %rcx,%rax
   48616:	jne    48680 <construction_bench::main+0xf20>
   48618:	jmp    4869b <construction_bench::main+0xf3b>
   4861d:	movabs $0x6870617267627573,%rcx
   48627:	cmp    %rcx,(%rax)
   4862a:	jne    48680 <construction_bench::main+0xf20>
   4862c:	jmp    4869b <construction_bench::main+0xf3b>
   4862e:	mov    (%rax),%rcx
   48631:	movabs $0x746163696c707564,%rdx
   4863b:	xor    %rdx,%rcx
   4863e:	movzwl 0x8(%rax),%eax
   48642:	xor    $0x7365,%rax
   48648:	or     %rcx,%rax
   4864b:	jne    48680 <construction_bench::main+0xf20>
   4864d:	jmp    4869b <construction_bench::main+0xf3b>
   4864f:	mov    (%rax),%rcx
   48652:	movabs $0x6870617267627573,%rdx
   4865c:	xor    %rdx,%rcx
   4865f:	mov    0x6(%rax),%rax
   48663:	movabs $0x6c6c616d732d6870,%rdx
   4866d:	xor    %rdx,%rax
   48670:	or     %rcx,%rax
   48673:	je     4869b <construction_bench::main+0xf3b>
   48675:	data16 cs nopw 0x0(%rax,%rax,1)
   48680:	mov    0x558(%rsp),%rax
   48688:	mov    %rax,0x110(%rsp)
   48690:	cmp    0x50(%rsp),%rax
   48695:	jne    48b51 <construction_bench::main+0x13f1>
   4869b:	movsd  %xmm1,0x68(%rsp)
   486a1:	movapd %xmm0,0x70(%rsp)
   486a7:	mov    $0x1d8,%edx
   486ac:	mov    %r12,%rdi
   486af:	call   *0x5c0f3(%rip)        # a47a8 <memcpy@GLIBC_2.14>
   486b5:	xor    %ebp,%ebp
   486b7:	mov    %r12,%rdi
   486ba:	call   46eb0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   486bf:	movapd 0x70(%rsp),%xmm1
   486c5:	movapd %xmm1,%xmm0
   486c9:	unpckhpd %xmm1,%xmm0
   486cd:	addsd  %xmm1,%xmm0
   486d1:	movsd  0x68(%rsp),%xmm1
   486d7:	addsd  %xmm0,%xmm1
   486db:	movsd  %xmm1,0x300(%rsp)
   486e4:	mov    0x30(%rsp),%rsi
   486e9:	test   %rsi,%rsi
   486ec:	je     48702 <construction_bench::main+0xfa2>
   486ee:	mov    0x38(%rsp),%rdi
   486f3:	shl    $0x3,%rsi
   486f7:	mov    $0x4,%edx
   486fc:	call   *0x5c05e(%rip)        # a4760 <_DYNAMIC+0x240>
   48702:	cmpq   $0x1,0xb0(%rsp)
   4870b:	jbe    47a20 <construction_bench::main+0x2c0>
   48711:	lea    0xf0(%rsp),%rax
   48719:	mov    %rax,0x110(%rsp)
   48721:	lea    -0x1e98(%rip),%rax        # 46890 <<&alloc::string::String as core::fmt::Display>::fmt>
   48728:	mov    %rax,0x118(%rsp)
   48730:	lea    0x58(%rsp),%rax
   48735:	mov    %rax,0x120(%rsp)
   4873d:	mov    0x5c174(%rip),%rax        # a48b8 <_DYNAMIC+0x398>
   48744:	mov    %rax,0x128(%rsp)
   4874c:	lea    0x300(%rsp),%rax
   48754:	mov    %rax,0x130(%rsp)
   4875c:	mov    0x5c31d(%rip),%rax        # a4a80 <_DYNAMIC+0x560>
   48763:	mov    %rax,0x138(%rsp)
   4876b:	lea    -0x408e2(%rip),%rdi        # 7e90 <anon.dfee4cbf5dd847bdf7978be4d7a189df.0.llvm.10118388184640623510+0x240>
   48772:	mov    %r12,%rsi
   48775:	call   *0x5c2dd(%rip)        # a4a58 <_DYNAMIC+0x538>
   4877b:	jmp    47a20 <construction_bench::main+0x2c0>
   48780:	mov    %rbp,%rsi
   48783:	mov    $0x1,%bpl
   48786:	mov    $0x7,%ecx
   4878b:	lea    0x300(%rsp),%rdi
   48793:	lea    -0x3dea5(%rip),%rdx        # a8f5 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x15>
   4879a:	call   394f0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<&str>>
   4879f:	cmpl   $0xffffffff,0x300(%rsp)
   487a7:	jne    48c00 <construction_bench::main+0x14a0>
   487ad:	mov    0x308(%rsp),%edx
   487b4:	mov    0x30c(%rsp),%ecx
   487bb:	mov    %r12,%rdi
   487be:	lea    0x4f0(%rsp),%rsi
   487c6:	mov    %edx,0xbc(%rsp)
   487cd:	mov    %ecx,0xb8(%rsp)
   487d4:	call   3a590 <<ironweaver_core::graph::Graph<(), ()>>::remove_node>
   487d9:	mov    0x110(%rsp),%rsi
   487e1:	cmp    $0xffffffffffffffff,%rsi
   487e5:	je     48c51 <construction_bench::main+0x14f1>
   487eb:	mov    $0x1,%r15b
   487ee:	test   %rsi,%rsi
   487f1:	je     47e4c <construction_bench::main+0x6ec>
   487f7:	mov    0x118(%rsp),%rdi
   487ff:	mov    $0x1,%edx
   48804:	call   *0x5bf56(%rip)        # a4760 <_DYNAMIC+0x240>
   4880a:	jmp    47e4c <construction_bench::main+0x6ec>
   4880f:	cmpq   $0x0,0x58(%rsp)
   48815:	je     4855c <construction_bench::main+0xdfc>
   4881b:	xor    %r15d,%r15d
   4881e:	xchg   %ax,%ax
   48820:	mov    %r15,0x60(%rsp)
   48825:	lea    0x60(%rsp),%rax
   4882a:	mov    %rax,0x110(%rsp)
   48832:	mov    0x5c07f(%rip),%rax        # a48b8 <_DYNAMIC+0x398>
   48839:	mov    %rax,0x118(%rsp)
   48841:	lea    0x6d0(%rsp),%r13
   48849:	mov    %r13,%rdi
   4884c:	lea    -0x3fb49(%rip),%rsi        # 8d0a <anon.6ce2bd37e1c81bd133be53b065f15922.5.llvm.5838934960365399480+0x55f>
   48853:	mov    %r12,%rdx
   48856:	call   *%r14
   48859:	lea    0x300(%rsp),%rdi
   48861:	lea    0x4f0(%rsp),%rsi
   48869:	mov    %r13,%rdx
   4886c:	call   39440 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   48871:	cmpl   $0xffffffff,0x300(%rsp)
   48879:	jne    48a84 <construction_bench::main+0x1324>
   4887f:	inc    %r15
   48882:	mov    0x308(%rsp),%rax
   4888a:	mov    %rax,0x110(%rsp)
   48892:	cmp    0x58(%rsp),%r15
   48897:	jb     48820 <construction_bench::main+0x10c0>
   48899:	jmp    4855c <construction_bench::main+0xdfc>
   4889e:	mov    0x40(%rsp),%rsi
   488a3:	mov    0x58(%rsp),%rdx
   488a8:	mov    %rsi,%r15
   488ab:	sub    %rdx,%r15
   488ae:	jb     48ca6 <construction_bench::main+0x1546>
   488b4:	shl    $0x3,%rdx
   488b8:	add    0x38(%rsp),%rdx
   488bd:	lea    (%rdx,%r15,8),%rcx
   488c1:	mov    %r12,%rdi
   488c4:	lea    0x4f0(%rsp),%rsi
   488cc:	call   377f0 <<ironweaver_core::graph::Graph<(), ()>>::induced_subgraph::<(), (), core::convert::Infallible, core::iter::adapters::copied::Copied<core::slice::iter::Iter<ironweaver_core::graph::NodeIx>>, construction_bench::main::{closure#3}, construction_bench::main::{closure#4}>>
   488d1:	mov    $0x1d8,%edx
   488d6:	lea    0x300(%rsp),%rdi
   488de:	mov    %r12,%rsi
   488e1:	call   *0x5bec1(%rip)        # a47a8 <memcpy@GLIBC_2.14>
   488e7:	mov    0x330(%rsp),%rax
   488ef:	mov    %rax,0x60(%rsp)
   488f4:	mov    %r15,0x110(%rsp)
   488fc:	cmp    %r15,%rax
   488ff:	jne    48c63 <construction_bench::main+0x1503>
   48905:	mov    0x4c0(%rsp),%rax
   4890d:	mov    %rax,0x60(%rsp)
   48912:	mov    0x6b0(%rsp),%rcx
   4891a:	mov    %rcx,0x110(%rsp)
   48922:	cmp    %rcx,%rax
   48925:	jne    48c84 <construction_bench::main+0x1524>
   4892b:	mov    0x28(%rsp),%rax
   48930:	cmpq   $0xe,0x28(%rax)
   48935:	jne    4897f <construction_bench::main+0x121f>
   48937:	mov    0x28(%rsp),%rax
   4893c:	mov    0x20(%rax),%rax
   48940:	mov    (%rax),%rcx
   48943:	movabs $0x6870617267627573,%rdx
   4894d:	xor    %rdx,%rcx
   48950:	mov    0x6(%rax),%rax
   48954:	movabs $0x6c6c616d732d6870,%rdx
   4895e:	xor    %rdx,%rax
   48961:	or     %rcx,%rax
   48964:	jne    4897f <construction_bench::main+0x121f>
   48966:	mov    0x368(%rsp),%rax
   4896e:	mov    %rax,0x110(%rsp)
   48976:	test   %rax,%rax
   48979:	jne    48cc7 <construction_bench::main+0x1567>
   4897f:	mov    $0x1d8,%edx
   48984:	mov    %r12,%rdi
   48987:	lea    0x300(%rsp),%rsi
   4898f:	call   *0x5be13(%rip)        # a47a8 <memcpy@GLIBC_2.14>
   48995:	mov    %r12,%rdi
   48998:	call   46eb0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   4899d:	jmp    4855c <construction_bench::main+0xdfc>
   489a2:	xor    %r8d,%r8d
   489a5:	mov    %r8,0x300(%rsp)
   489ad:	lea    0x300(%rsp),%rax
   489b5:	mov    0x50(%rsp),%rax
   489ba:	add    %rax,%rax
   489bd:	mov    %rax,0x110(%rsp)
   489c5:	cmp    %rax,0x300(%rsp)
   489cd:	je     4855c <construction_bench::main+0xdfc>
   489d3:	lea    0x300(%rsp),%rsi
   489db:	lea    0x58afe(%rip),%r9        # a14e0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xd8>
   489e2:	jmp    48b60 <construction_bench::main+0x1400>
   489e7:	mov    0x28(%rsp),%rax
   489ec:	lea    0x8(%rax),%rbx
   489f0:	mov    0x5bd69(%rip),%r15        # a4760 <_DYNAMIC+0x240>
   489f7:	mov    0xa8(%rsp),%r14
   489ff:	jmp    48a19 <construction_bench::main+0x12b9>
   48a01:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   48a10:	add    $0x18,%rbx
   48a14:	dec    %r14
   48a17:	je     48a2f <construction_bench::main+0x12cf>
   48a19:	mov    -0x8(%rbx),%rsi
   48a1d:	test   %rsi,%rsi
   48a20:	je     48a10 <construction_bench::main+0x12b0>
   48a22:	mov    (%rbx),%rdi
   48a25:	mov    $0x1,%edx
   48a2a:	call   *%r15
   48a2d:	jmp    48a10 <construction_bench::main+0x12b0>
   48a2f:	mov    0xc8(%rsp),%rax
   48a37:	test   %rax,%rax
   48a3a:	je     48a54 <construction_bench::main+0x12f4>
   48a3c:	shl    $0x3,%rax
   48a40:	lea    (%rax,%rax,2),%rsi
   48a44:	mov    $0x8,%edx
   48a49:	mov    0x28(%rsp),%rdi
   48a4e:	call   *0x5bd0c(%rip)        # a4760 <_DYNAMIC+0x240>
   48a54:	add    $0x6e8,%rsp
   48a5b:	pop    %rbx
   48a5c:	pop    %r12
   48a5e:	pop    %r13
   48a60:	pop    %r14
   48a62:	pop    %r15
   48a64:	pop    %rbp
   48a65:	ret
   48a66:	lea    -0x3e695(%rip),%rdi        # a3d8 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763>
   48a6d:	lea    0x585f4(%rip),%rdx        # a1068 <anon.2511809ce763e2139425809bcda7322c.35.llvm.4475126642733658763>
   48a74:	mov    $0x24,%esi
   48a79:	call   *0x5bd69(%rip)        # a47e8 <_DYNAMIC+0x2c8>
   48a7f:	jmp    48d43 <construction_bench::main+0x15e3>
   48a84:	movupd 0x300(%rsp),%xmm0
   48a8d:	movupd 0x310(%rsp),%xmm1
   48a96:	movapd %xmm1,0x120(%rsp)
   48a9f:	movapd %xmm0,0x110(%rsp)
   48aa8:	lea    -0x3e177(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48aaf:	lea    0x58c12(%rip),%rcx        # a16c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48ab6:	lea    0x58a9b(%rip),%r8        # a1558 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x150>
   48abd:	lea    0x110(%rsp),%rdx
   48ac5:	mov    $0x2b,%esi
   48aca:	call   *0x5bd20(%rip)        # a47f0 <_DYNAMIC+0x2d0>
   48ad0:	jmp    48d43 <construction_bench::main+0x15e3>
   48ad5:	lea    0x58a64(%rip),%r8        # a1540 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x138>
   48adc:	lea    0x58c05(%rip),%rcx        # a16e8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2e0>
   48ae3:	lea    0x300(%rsp),%rdx
   48aeb:	jmp    48b21 <construction_bench::main+0x13c1>
   48aed:	add    $0xd0,%dl
   48af0:	xor    %eax,%eax
   48af2:	cmp    $0xa,%dl
   48af5:	adc    $0x1,%al
   48af7:	jmp    48afb <construction_bench::main+0x139b>
   48af9:	mov    $0x2,%al
   48afb:	mov    %al,0x110(%rsp)
   48b02:	lea    0x5898f(%rip),%r8        # a1498 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x90>
   48b09:	jmp    48b8e <construction_bench::main+0x142e>
   48b0e:	lea    0x58a13(%rip),%r8        # a1528 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x120>
   48b15:	lea    0x58b8c(%rip),%rcx        # a16a8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2a0>
   48b1c:	lea    0x60(%rsp),%rdx
   48b21:	mov    0xe8(%rsp),%rax
   48b29:	mov    (%rax),%eax
   48b2b:	mov    0xe0(%rsp),%rsi
   48b33:	mov    (%rsi),%esi
   48b35:	mov    %eax,(%rdx)
   48b37:	mov    %esi,0x4(%rdx)
   48b3a:	lea    -0x3e1de(%rip),%rdi        # a963 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x83>
   48b41:	mov    $0x2e,%esi
   48b46:	call   *0x5bca4(%rip)        # a47f0 <_DYNAMIC+0x2d0>
   48b4c:	jmp    48d43 <construction_bench::main+0x15e3>
   48b51:	mov    %r12,%rsi
   48b54:	lea    0x50(%rsp),%r12
   48b59:	lea    0x58a40(%rip),%r9        # a15a0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x198>
   48b60:	xor    %edi,%edi
   48b62:	mov    %r12,%rdx
   48b65:	xor    %ecx,%ecx
   48b67:	call   *0x5bf1b(%rip)        # a4a88 <_DYNAMIC+0x568>
   48b6d:	jmp    48d43 <construction_bench::main+0x15e3>
   48b72:	add    $0xd0,%dl
   48b75:	xor    %eax,%eax
   48b77:	cmp    $0xa,%dl
   48b7a:	adc    $0x1,%al
   48b7c:	jmp    48b80 <construction_bench::main+0x1420>
   48b7e:	mov    $0x2,%al
   48b80:	mov    %al,0x110(%rsp)
   48b87:	lea    0x588c2(%rip),%r8        # a1450 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x48>
   48b8e:	lea    -0x3e25d(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48b95:	lea    0x58b6c(%rip),%rcx        # a1708 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x300>
   48b9c:	mov    $0x2b,%esi
   48ba1:	mov    %r12,%rdx
   48ba4:	call   *0x5bc46(%rip)        # a47f0 <_DYNAMIC+0x2d0>
   48baa:	jmp    48d43 <construction_bench::main+0x15e3>
   48baf:	movupd 0x300(%rsp),%xmm0
   48bb8:	movupd 0x310(%rsp),%xmm1
   48bc1:	movapd %xmm1,0x120(%rsp)
   48bca:	movapd %xmm0,0x110(%rsp)
   48bd3:	lea    -0x3e2a2(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48bda:	lea    0x58ae7(%rip),%rcx        # a16c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48be1:	lea    0x58a00(%rip),%r8        # a15e8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1e0>
   48be8:	lea    0x110(%rsp),%rdx
   48bf0:	mov    $0x2b,%esi
   48bf5:	call   *0x5bbf5(%rip)        # a47f0 <_DYNAMIC+0x2d0>
   48bfb:	jmp    48d43 <construction_bench::main+0x15e3>
   48c00:	movupd 0x300(%rsp),%xmm0
   48c09:	movupd 0x310(%rsp),%xmm1
   48c12:	movapd %xmm1,0x120(%rsp)
   48c1b:	movapd %xmm0,0x110(%rsp)
   48c24:	lea    -0x3e2f3(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48c2b:	lea    0x58a96(%rip),%rcx        # a16c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48c32:	lea    0x58877(%rip),%r8        # a14b0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xa8>
   48c39:	lea    0x110(%rsp),%rdx
   48c41:	mov    $0x2b,%esi
   48c46:	call   *0x5bba4(%rip)        # a47f0 <_DYNAMIC+0x2d0>
   48c4c:	jmp    48d43 <construction_bench::main+0x15e3>
   48c51:	lea    0x58870(%rip),%rdi        # a14c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xc0>
   48c58:	call   *0x5bcc2(%rip)        # a4920 <_DYNAMIC+0x400>
   48c5e:	jmp    48d43 <construction_bench::main+0x15e3>
   48c63:	lea    0x58906(%rip),%r9        # a1570 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x168>
   48c6a:	xor    %edi,%edi
   48c6c:	mov    0xc0(%rsp),%rsi
   48c74:	mov    %r12,%rdx
   48c77:	xor    %ecx,%ecx
   48c79:	call   *0x5be09(%rip)        # a4a88 <_DYNAMIC+0x568>
   48c7f:	jmp    48d43 <construction_bench::main+0x15e3>
   48c84:	lea    0x588fd(%rip),%r9        # a1588 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x180>
   48c8b:	lea    0x60(%rsp),%rsi
   48c90:	lea    0x110(%rsp),%rdx
   48c98:	xor    %edi,%edi
   48c9a:	xor    %ecx,%ecx
   48c9c:	call   44fcb <core::panicking::assert_failed::<ironweaver_core::graph::EdgeId, ironweaver_core::graph::EdgeId>>
   48ca1:	jmp    48d43 <construction_bench::main+0x15e3>
   48ca6:	lea    0x58923(%rip),%rcx        # a15d0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1c8>
   48cad:	mov    %rdx,%rdi
   48cb0:	mov    %rsi,%rdx
   48cb3:	call   *0x5bcc7(%rip)        # a4980 <_DYNAMIC+0x460>
   48cb9:	jmp    48d43 <construction_bench::main+0x15e3>
   48cbe:	lea    0x58833(%rip),%rdi        # a14f8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xf0>
   48cc5:	jmp    48c58 <construction_bench::main+0x14f8>
   48cc7:	mov    %r12,0xc0(%rsp)
   48ccf:	lea    -0x3e83e(%rip),%r12        # a498 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763+0xc0>
   48cd6:	lea    0x588db(%rip),%r9        # a15b8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1b0>
   48cdd:	jmp    48c6a <construction_bench::main+0x150a>
   48cdf:	lea    -0x3e3ea(%rip),%rdi        # a8fc <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x1c>
   48ce6:	lea    0x58913(%rip),%rdx        # a1600 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1f8>
   48ced:	mov    $0x3c,%esi
   48cf2:	call   *0x5bc00(%rip)        # a48f8 <_DYNAMIC+0x3d8>
   48cf8:	jmp    48d43 <construction_bench::main+0x15e3>
   48cfa:	mov    $0x1,%al
   48cfc:	jmp    48afb <construction_bench::main+0x139b>
   48d01:	mov    $0x1,%al
   48d03:	jmp    48b80 <construction_bench::main+0x1420>
   48d08:	lea    0x58801(%rip),%rdx        # a1510 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x108>
   48d0f:	xor    %edi,%edi
   48d11:	xor    %esi,%esi
   48d13:	call   *0x5badf(%rip)        # a47f8 <_DYNAMIC+0x2d8>
   48d19:	jmp    48d43 <construction_bench::main+0x15e3>
   48d1b:	lea    0x58746(%rip),%rdx        # a1468 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x60>
   48d22:	mov    $0x1,%edi
   48d27:	jmp    48d35 <construction_bench::main+0x15d5>
   48d29:	lea    0x58750(%rip),%rdx        # a1480 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x78>
   48d30:	mov    $0x2,%edi
   48d35:	mov    0xa8(%rsp),%rsi
   48d3d:	call   *0x5bab5(%rip)        # a47f8 <_DYNAMIC+0x2d8>
   48d43:	ud2
   48d45:	xor    %eax,%eax
   48d47:	jmp    48afb <construction_bench::main+0x139b>
   48d4c:	xor    %eax,%eax
   48d4e:	jmp    48b80 <construction_bench::main+0x1420>
   48d53:	jmp    48eaa <construction_bench::main+0x174a>
   48d58:	mov    %rax,%r14
   48d5b:	lea    0x30(%rsp),%rdi
   48d60:	call   46df0 <core::ptr::drop_glue::<alloc::vec::Vec<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)>>>
   48d65:	jmp    48ee0 <construction_bench::main+0x1780>
   48d6a:	jmp    48e2a <construction_bench::main+0x16ca>
   48d6f:	mov    %rax,%r14
   48d72:	lea    0x300(%rsp),%rdi
   48d7a:	call   414e0 <core::ptr::drop_glue::<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>>>>
   48d7f:	jmp    48ee0 <construction_bench::main+0x1780>
   48d84:	call   *0x5ba76(%rip)        # a4800 <_DYNAMIC+0x2e0>
   48d8a:	jmp    48eaa <construction_bench::main+0x174a>
   48d8f:	mov    %rax,%r14
   48d92:	lea    0x300(%rsp),%rdi
   48d9a:	call   46eb0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48d9f:	jmp    48ee0 <construction_bench::main+0x1780>
   48da4:	call   *0x5ba56(%rip)        # a4800 <_DYNAMIC+0x2e0>
   48daa:	jmp    48eaa <construction_bench::main+0x174a>
   48daf:	mov    %rax,%r14
   48db2:	jmp    48ee0 <construction_bench::main+0x1780>
   48db7:	jmp    48eaa <construction_bench::main+0x174a>
   48dbc:	jmp    48eaa <construction_bench::main+0x174a>
   48dc1:	mov    %rax,%r14
   48dc4:	jmp    48eb0 <construction_bench::main+0x1750>
   48dc9:	mov    %rax,%r14
   48dcc:	test   %r15,%r15
   48dcf:	je     48df4 <construction_bench::main+0x1694>
   48dd1:	add    $0x1d8,%rbp
   48dd8:	neg    %r15
   48ddb:	nopl   0x0(%rax,%rax,1)
   48de0:	mov    %rbp,%rdi
   48de3:	call   40610 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48de8:	add    $0x1d8,%rbp
   48def:	dec    %r15
   48df2:	jne    48de0 <construction_bench::main+0x1680>
   48df4:	mov    0x110(%rsp),%rax
   48dfc:	test   %rax,%rax
   48dff:	je     48ee0 <construction_bench::main+0x1780>
   48e05:	mov    0x118(%rsp),%rdi
   48e0d:	imul   $0x1d8,%rax,%rsi
   48e14:	mov    $0x8,%edx
   48e19:	call   *0x5b941(%rip)        # a4760 <_DYNAMIC+0x240>
   48e1f:	jmp    48ee0 <construction_bench::main+0x1780>
   48e24:	call   *0x5b9d6(%rip)        # a4800 <_DYNAMIC+0x2e0>
   48e2a:	mov    %rax,%r14
   48e2d:	lea    0x4f0(%rsp),%rdi
   48e35:	call   46c60 <core::ptr::drop_glue::<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>>>>
   48e3a:	jmp    48ee0 <construction_bench::main+0x1780>
   48e3f:	jmp    48e55 <construction_bench::main+0x16f5>
   48e41:	mov    %rax,%r14
   48e44:	lea    0x300(%rsp),%rdi
   48e4c:	call   46eb0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48e51:	jmp    48ead <construction_bench::main+0x174d>
   48e53:	jmp    48e55 <construction_bench::main+0x16f5>
   48e55:	mov    %rax,%r14
   48e58:	mov    $0x1,%bpl
   48e5b:	mov    0x110(%rsp),%rax
   48e63:	cmp    $0xa,%rax
   48e67:	ja     48e74 <construction_bench::main+0x1714>
   48e69:	mov    $0x51c,%ecx
   48e6e:	bt     %rax,%rcx
   48e72:	jb     48eb0 <construction_bench::main+0x1750>
   48e74:	mov    0x118(%rsp),%rsi
   48e7c:	test   %rsi,%rsi
   48e7f:	je     48eb0 <construction_bench::main+0x1750>
   48e81:	mov    0x120(%rsp),%rdi
   48e89:	mov    $0x1,%edx
   48e8e:	call   *0x5b8cc(%rip)        # a4760 <_DYNAMIC+0x240>
   48e94:	jmp    48eb0 <construction_bench::main+0x1750>
   48e96:	jmp    48eaa <construction_bench::main+0x174a>
   48e98:	mov    %rax,%r14
   48e9b:	mov    0xd0(%rsp),%rax
   48ea3:	mov    %rax,0x28(%rsp)
   48ea8:	jmp    48ee0 <construction_bench::main+0x1780>
   48eaa:	mov    %rax,%r14
   48ead:	mov    $0x1,%bpl
   48eb0:	mov    0x30(%rsp),%rsi
   48eb5:	test   %rsi,%rsi
   48eb8:	je     48ece <construction_bench::main+0x176e>
   48eba:	mov    0x38(%rsp),%rdi
   48ebf:	shl    $0x3,%rsi
   48ec3:	mov    $0x4,%edx
   48ec8:	call   *0x5b892(%rip)        # a4760 <_DYNAMIC+0x240>
   48ece:	test   %bpl,%bpl
   48ed1:	je     48ee0 <construction_bench::main+0x1780>
   48ed3:	lea    0x4f0(%rsp),%rdi
   48edb:	call   46eb0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48ee0:	mov    0xd8(%rsp),%rbx
   48ee8:	test   %rbx,%rbx
   48eeb:	jne    48f1a <construction_bench::main+0x17ba>
   48eed:	mov    0xc8(%rsp),%rax
   48ef5:	test   %rax,%rax
   48ef8:	je     48f12 <construction_bench::main+0x17b2>
   48efa:	shl    $0x3,%rax
   48efe:	lea    (%rax,%rax,2),%rsi
   48f02:	mov    $0x8,%edx
   48f07:	mov    0x28(%rsp),%rdi
   48f0c:	call   *0x5b84e(%rip)        # a4760 <_DYNAMIC+0x240>
   48f12:	mov    %r14,%rdi
   48f15:	call   9fe50 <_Unwind_Resume@plt>
   48f1a:	mov    0x28(%rsp),%rax
   48f1f:	lea    0x8(%rax),%r15
   48f23:	mov    0x5b836(%rip),%r12        # a4760 <_DYNAMIC+0x240>
   48f2a:	jmp    48f39 <construction_bench::main+0x17d9>
   48f2c:	nopl   0x0(%rax)
   48f30:	add    $0x18,%r15
   48f34:	dec    %rbx
   48f37:	je     48eed <construction_bench::main+0x178d>
   48f39:	mov    -0x8(%r15),%rsi
   48f3d:	test   %rsi,%rsi
   48f40:	je     48f30 <construction_bench::main+0x17d0>
   48f42:	mov    (%r15),%rdi
   48f45:	mov    $0x1,%edx
   48f4a:	call   *%r12
   48f4d:	jmp    48f30 <construction_bench::main+0x17d0>
   48f4f:	call   *0x5b8ab(%rip)        # a4800 <_DYNAMIC+0x2e0>
   48f55:	int3
   48f56:	int3
   48f57:	int3
   48f58:	int3
   48f59:	int3
   48f5a:	int3
   48f5b:	int3
   48f5c:	int3
   48f5d:	int3
   48f5e:	int3
   48f5f:	int3
