#!/usr/bin/env bash
set -euo pipefail
source work/env.sh
export CARGO_TARGET_DIR=/workspace/Ironweaver/target
for structure in combined standalone; do cp "work/codegen/$structure.rs" "work/diagnosis/source/crates/ironweaver-core/examples/matrix_$structure.rs"; done
for revision in baseline candidate; do
 variant=baseline-new
 [[ "$revision" == baseline ]] || variant=candidate
 cp "work/diagnosis/$variant.rs" work/diagnosis/source/crates/ironweaver-core/src/graph.rs
 find work/diagnosis/source/crates/ironweaver-core/src -name '*.rs' -exec touch {} +
 cargo build --manifest-path work/diagnosis/source/Cargo.toml --release --locked -p ironweaver-core --example matrix_combined --example matrix_standalone
 mkdir -p "work/codegen/$revision"
 for structure in combined standalone; do cp "target/release/examples/matrix_$structure" "work/codegen/$revision/$structure"; done
done
