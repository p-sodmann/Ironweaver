   2e3b0:	push   %rbp
   2e3b1:	push   %r15
   2e3b3:	push   %r14
   2e3b5:	push   %r13
   2e3b7:	push   %r12
   2e3b9:	push   %rbx
   2e3ba:	push   %rax
   2e3bb:	test   %rdx,%rdx
   2e3be:	je     2e4be <matrix_standalone::walk+0x10e>
   2e3c4:	mov    0x8(%rdi),%rcx
   2e3c8:	mov    0x10(%rdi),%r8
   2e3cc:	mov    0x48(%rdi),%r9
   2e3d0:	mov    0x40(%rdi),%rdi
   2e3d4:	xor    %eax,%eax
   2e3d6:	xor    %r10d,%r10d
   2e3d9:	nopl   0x0(%rax)
   2e3e0:	mov    (%rsi,%r10,8),%r11d
   2e3e4:	cmp    %r11,%r8
   2e3e7:	jbe    2e460 <matrix_standalone::walk+0xb0>
   2e3e9:	mov    0x4(%rsi,%r10,8),%ebx
   2e3ee:	imul   $0x68,%r11,%r15
   2e3f2:	cmp    %ebx,0x60(%rcx,%r15,1)
   2e3f7:	jne    2e460 <matrix_standalone::walk+0xb0>
   2e3f9:	add    %rcx,%r15
   2e3fc:	cmpq   $0xffffffffffffffff,(%r15)
   2e400:	je     2e460 <matrix_standalone::walk+0xb0>
   2e402:	mov    0x40(%r15),%r11
   2e406:	mov    0x50(%r15),%r14
   2e40a:	mov    0x58(%r15),%rbx
   2e40e:	test   %r11,%r11
   2e411:	je     2e479 <matrix_standalone::walk+0xc9>
   2e413:	mov    0x38(%r15),%r15
   2e417:	xor    %r12d,%r12d
   2e41a:	nopw   0x0(%rax,%rax,1)
   2e420:	mov    (%r15,%r12,8),%r13d
   2e424:	cmp    %r13,%r9
   2e427:	jbe    2e4cf <matrix_standalone::walk+0x11f>
   2e42d:	lea    0x0(%r13,%r13,4),%r13
   2e432:	mov    0x20(%rdi,%r13,8),%ebp
   2e437:	cmp    0x4(%r15,%r12,8),%ebp
   2e43c:	jne    2e4cf <matrix_standalone::walk+0x11f>
   2e442:	lea    (%rdi,%r13,8),%r13
   2e446:	cmpl   $0x2,0x0(%r13)
   2e44b:	je     2e4cf <matrix_standalone::walk+0x11f>
   2e451:	inc    %r12
   2e454:	cmp    %r12,%r11
   2e457:	jne    2e420 <matrix_standalone::walk+0x70>
   2e459:	test   %rbx,%rbx
   2e45c:	jne    2e481 <matrix_standalone::walk+0xd1>
   2e45e:	jmp    2e463 <matrix_standalone::walk+0xb3>
   2e460:	xor    %r11d,%r11d
   2e463:	xor    %ebx,%ebx
   2e465:	add    %r11,%rax
   2e468:	add    %rbx,%rax
   2e46b:	inc    %r10
   2e46e:	cmp    %rdx,%r10
   2e471:	jne    2e3e0 <matrix_standalone::walk+0x30>
   2e477:	jmp    2e4c0 <matrix_standalone::walk+0x110>
   2e479:	xor    %r11d,%r11d
   2e47c:	test   %rbx,%rbx
   2e47f:	je     2e463 <matrix_standalone::walk+0xb3>
   2e481:	xor    %r15d,%r15d
   2e484:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e490:	mov    (%r14,%r15,8),%r12d
   2e494:	cmp    %r12,%r9
   2e497:	jbe    2e4cf <matrix_standalone::walk+0x11f>
   2e499:	lea    (%r12,%r12,4),%r12
   2e49d:	mov    0x20(%rdi,%r12,8),%ebp
   2e4a2:	cmp    0x4(%r14,%r15,8),%ebp
   2e4a7:	jne    2e4cf <matrix_standalone::walk+0x11f>
   2e4a9:	lea    (%rdi,%r12,8),%r12
   2e4ad:	cmpl   $0x2,(%r12)
   2e4b2:	je     2e4cf <matrix_standalone::walk+0x11f>
   2e4b4:	inc    %r15
   2e4b7:	cmp    %r15,%rbx
   2e4ba:	jne    2e490 <matrix_standalone::walk+0xe0>
   2e4bc:	jmp    2e465 <matrix_standalone::walk+0xb5>
   2e4be:	xor    %eax,%eax
   2e4c0:	add    $0x8,%rsp
   2e4c4:	pop    %rbx
   2e4c5:	pop    %r12
   2e4c7:	pop    %r13
   2e4c9:	pop    %r14
   2e4cb:	pop    %r15
   2e4cd:	pop    %rbp
   2e4ce:	ret
   2e4cf:	lea    -0xf949(%rip),%rdi        # 1eb8d <anon.b8945cdff02dd9d97bc89bc1609f7e79.20.llvm.14894010180500554284>
   2e4d6:	lea    0x485ab(%rip),%rdx        # 76a88 <anon.b8945cdff02dd9d97bc89bc1609f7e79.21.llvm.14894010180500554284>
   2e4dd:	mov    $0x24,%esi
   2e4e2:	call   *0x4ad68(%rip)        # 79250 <_DYNAMIC+0x2e0>
   2e4e8:	int3
   2e4e9:	int3
   2e4ea:	int3
   2e4eb:	int3
   2e4ec:	int3
   2e4ed:	int3
   2e4ee:	int3
   2e4ef:	int3
