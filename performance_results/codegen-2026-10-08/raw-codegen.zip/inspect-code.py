from pathlib import Path
import subprocess,re,hashlib,json,difflib
rows={}
for label,path,symbol in [('original-baseline','work/artifacts/baseline/construction_bench','construction_bench::main'),('original-candidate','work/artifacts/candidate/construction_bench','construction_bench::main'),('removal-reversion','work/diagnosis/remove-old/construction_bench','construction_bench::main'),('standalone-baseline','work/codegen/baseline/standalone','matrix_standalone::walk'),('standalone-candidate','work/codegen/candidate/standalone','matrix_standalone::walk')]:
 s=subprocess.check_output(['objdump','-d','-C','--no-show-raw-insn',path],text=True)
 m=re.search(r'([0-9a-f]+) <'+re.escape(symbol)+r'>:\n(.*?)(?=\n[0-9a-f]+ <)',s,re.S)
 body=m[2];Path('work/codegen/'+label+'.asm').write_text(body)
 lines=[]
 for line in body.splitlines():
  line=re.sub(r'^\s*[0-9a-f]+:\s*','',line)
  line=re.sub(r'\s+#.*','',line)
  line=re.sub(r'[0-9a-f]+ <','<',line)
  line=re.sub(r'-?0x[0-9a-f]+\(%rip\)','RIP_RELOC',line)
  line=re.sub(r'\.llvm\.\d+','LLVM_ID',line)
  if line:lines.append(line)
 norm='\n'.join(lines)+'\n';Path('work/codegen/'+label+'-normalized.asm').write_text(norm)
 rows[label]=dict(address=m[1],alignment_mod64=int(m[1],16)%64,instructions=len(lines),normalized_sha256=hashlib.sha256(norm.encode()).hexdigest())
for a,b in [('original-baseline','original-candidate'),('original-candidate','removal-reversion'),('standalone-baseline','standalone-candidate')]:
 aa=Path('work/codegen/'+a+'-normalized.asm').read_text().splitlines();bb=Path('work/codegen/'+b+'-normalized.asm').read_text().splitlines()
 diff='\n'.join(difflib.unified_diff(aa,bb,fromfile=a,tofile=b))+'\n';Path(f'work/codegen/{a}-{b}.diff').write_text(diff)
 print(a,b,'identical normalized instructions:',aa==bb,'diff lines:',len(diff.splitlines()))
Path('work/codegen/assembly-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
