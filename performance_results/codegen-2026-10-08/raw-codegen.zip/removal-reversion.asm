   47750:	push   %rbp
   47751:	push   %r15
   47753:	push   %r14
   47755:	push   %r13
   47757:	push   %r12
   47759:	push   %rbx
   4775a:	sub    $0x6e8,%rsp
   47761:	lea    0x110(%rsp),%r12
   47769:	mov    %r12,%rdi
   4776c:	call   *0x5d2be(%rip)        # a4a30 <_DYNAMIC+0x530>
   47772:	lea    0xc8(%rsp),%rdi
   4777a:	mov    %r12,%rsi
   4777d:	call   40c80 <<alloc::vec::Vec<alloc::string::String> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<alloc::string::String, std::env::Args>>::from_iter>
   47782:	mov    0xd8(%rsp),%rcx
   4778a:	cmp    $0x2,%rcx
   4778e:	mov    %rcx,0xa8(%rsp)
   47796:	jb     48d0b <construction_bench::main+0x15bb>
   4779c:	mov    0xd0(%rsp),%rax
   477a4:	mov    %rax,0x28(%rsp)
   477a9:	add    $0x18,%rax
   477ad:	mov    %rax,0xf0(%rsp)
   477b5:	cmp    $0x2,%rcx
   477b9:	je     48d19 <construction_bench::main+0x15c9>
   477bf:	mov    0x28(%rsp),%rax
   477c4:	mov    0x38(%rax),%rcx
   477c8:	mov    0x40(%rax),%rsi
   477cc:	cmp    $0x1,%rsi
   477d0:	je     477e0 <construction_bench::main+0x90>
   477d2:	test   %rsi,%rsi
   477d5:	je     48d35 <construction_bench::main+0x15e5>
   477db:	movzbl (%rcx),%edx
   477de:	jmp    477f7 <construction_bench::main+0xa7>
   477e0:	movzbl (%rcx),%edx
   477e3:	mov    $0x1,%al
   477e5:	cmp    $0x2b,%edx
   477e8:	je     48aeb <construction_bench::main+0x139b>
   477ee:	cmp    $0x2d,%edx
   477f1:	je     48aeb <construction_bench::main+0x139b>
   477f7:	xor    %eax,%eax
   477f9:	cmp    $0x2b,%dl
   477fc:	sete   %al
   477ff:	mov    %rsi,%rdx
   47802:	sub    %rax,%rdx
   47805:	add    %rax,%rcx
   47808:	neg    %rax
   4780b:	cmp    $0x11,%rdx
   4780f:	jae    47847 <construction_bench::main+0xf7>
   47811:	test   %rdx,%rdx
   47814:	je     47892 <construction_bench::main+0x142>
   47816:	add    %rax,%rsi
   47819:	neg    %rsi
   4781c:	xor    %eax,%eax
   4781e:	xor    %edx,%edx
   47820:	movzbl (%rcx,%rdx,1),%edi
   47824:	add    $0xffffffd0,%edi
   47827:	cmp    $0x9,%edi
   4782a:	ja     48cea <construction_bench::main+0x159a>
   47830:	lea    (%rax,%rax,4),%rax
   47834:	mov    %edi,%edi
   47836:	lea    (%rdi,%rax,2),%rax
   4783a:	inc    %rdx
   4783d:	mov    %rsi,%rdi
   47840:	add    %rdx,%rdi
   47843:	jne    47820 <construction_bench::main+0xd0>
   47845:	jmp    47894 <construction_bench::main+0x144>
   47847:	add    %rax,%rsi
   4784a:	neg    %rsi
   4784d:	xor    %eax,%eax
   4784f:	mov    $0xa,%edi
   47854:	xor    %r8d,%r8d
   47857:	nopw   0x0(%rax,%rax,1)
   47860:	mul    %rdi
   47863:	movzbl (%rcx,%r8,1),%edx
   47868:	jo     48add <construction_bench::main+0x138d>
   4786e:	add    $0xffffffd0,%edx
   47871:	cmp    $0xa,%edx
   47874:	jae    48cea <construction_bench::main+0x159a>
   4787a:	mov    %edx,%edx
   4787c:	add    %rdx,%rax
   4787f:	jb     48ae9 <construction_bench::main+0x1399>
   47885:	inc    %r8
   47888:	mov    %rsi,%rdx
   4788b:	add    %r8,%rdx
   4788e:	jne    47860 <construction_bench::main+0x110>
   47890:	jmp    47894 <construction_bench::main+0x144>
   47892:	xor    %eax,%eax
   47894:	mov    %rax,0x58(%rsp)
   47899:	lea    (%rax,%rax,4),%rax
   4789d:	mov    %rax,0x50(%rsp)
   478a2:	mov    $0x7,%ebx
   478a7:	cmpq   $0x4,0xa8(%rsp)
   478b0:	jb     4799a <construction_bench::main+0x24a>
   478b6:	mov    0x28(%rsp),%rax
   478bb:	mov    0x50(%rax),%rcx
   478bf:	mov    0x58(%rax),%rsi
   478c3:	cmp    $0x1,%rsi
   478c7:	je     478d7 <construction_bench::main+0x187>
   478c9:	test   %rsi,%rsi
   478cc:	je     48d3c <construction_bench::main+0x15ec>
   478d2:	movzbl (%rcx),%edx
   478d5:	jmp    478ee <construction_bench::main+0x19e>
   478d7:	movzbl (%rcx),%edx
   478da:	mov    $0x1,%al
   478dc:	cmp    $0x2b,%edx
   478df:	je     48b70 <construction_bench::main+0x1420>
   478e5:	cmp    $0x2d,%edx
   478e8:	je     48b70 <construction_bench::main+0x1420>
   478ee:	xor    %eax,%eax
   478f0:	cmp    $0x2b,%dl
   478f3:	sete   %al
   478f6:	mov    %rsi,%rdx
   478f9:	sub    %rax,%rdx
   478fc:	add    %rax,%rcx
   478ff:	neg    %rax
   47902:	cmp    $0x11,%rdx
   47906:	jae    47947 <construction_bench::main+0x1f7>
   47908:	test   %rdx,%rdx
   4790b:	je     47998 <construction_bench::main+0x248>
   47911:	add    %rax,%rsi
   47914:	neg    %rsi
   47917:	xor    %ebx,%ebx
   47919:	xor    %eax,%eax
   4791b:	nopl   0x0(%rax,%rax,1)
   47920:	movzbl (%rcx,%rax,1),%edx
   47924:	add    $0xffffffd0,%edx
   47927:	cmp    $0x9,%edx
   4792a:	ja     48cf1 <construction_bench::main+0x15a1>
   47930:	lea    (%rbx,%rbx,4),%rdi
   47934:	mov    %edx,%edx
   47936:	lea    (%rdx,%rdi,2),%rbx
   4793a:	inc    %rax
   4793d:	mov    %rsi,%rdx
   47940:	add    %rax,%rdx
   47943:	jne    47920 <construction_bench::main+0x1d0>
   47945:	jmp    4799a <construction_bench::main+0x24a>
   47947:	add    %rax,%rsi
   4794a:	neg    %rsi
   4794d:	xor    %ebx,%ebx
   4794f:	mov    $0xa,%edi
   47954:	xor    %r8d,%r8d
   47957:	nopw   0x0(%rax,%rax,1)
   47960:	mov    %rbx,%rax
   47963:	mul    %rdi
   47966:	movzbl (%rcx,%r8,1),%edx
   4796b:	jo     48b62 <construction_bench::main+0x1412>
   47971:	add    $0xffffffd0,%edx
   47974:	cmp    $0xa,%edx
   47977:	jae    48cf1 <construction_bench::main+0x15a1>
   4797d:	mov    %rax,%rbx
   47980:	mov    %edx,%eax
   47982:	add    %rax,%rbx
   47985:	jb     48b6e <construction_bench::main+0x141e>
   4798b:	inc    %r8
   4798e:	mov    %rsi,%rax
   47991:	add    %r8,%rax
   47994:	jne    47960 <construction_bench::main+0x210>
   47996:	jmp    4799a <construction_bench::main+0x24a>
   47998:	xor    %ebx,%ebx
   4799a:	lea    -0x3d0bb(%rip),%rdi        # a8e6 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x6>
   479a1:	mov    $0x1f,%esi
   479a6:	call   *0x5d08c(%rip)        # a4a38 <_DYNAMIC+0x538>
   479ac:	add    $0x2,%rbx
   479b0:	je     489d7 <construction_bench::main+0x1287>
   479b6:	lea    0x118(%rsp),%rax
   479be:	mov    %rax,0xe8(%rsp)
   479c6:	lea    0x11c(%rsp),%rax
   479ce:	mov    %rax,0xe0(%rsp)
   479d6:	movq   $0x0,0xb0(%rsp)
   479e2:	lea    0x110(%rsp),%r12
   479ea:	mov    0x5ce0f(%rip),%r14        # a4800 <_DYNAMIC+0x300>
   479f1:	lea    0x60(%rsp),%rax
   479f6:	mov    %rax,0xc0(%rsp)
   479fe:	mov    %rbx,0x98(%rsp)
   47a06:	jmp    47a2c <construction_bench::main+0x2dc>
   47a08:	nopl   0x0(%rax,%rax,1)
   47a10:	mov    0xb0(%rsp),%rcx
   47a18:	inc    %rcx
   47a1b:	mov    %rcx,0xb0(%rsp)
   47a23:	cmp    %rbx,%rcx
   47a26:	je     489d7 <construction_bench::main+0x1287>
   47a2c:	mov    0x28(%rsp),%rax
   47a31:	cmpq   $0xa,0x28(%rax)
   47a36:	jne    47a64 <construction_bench::main+0x314>
   47a38:	mov    0x28(%rsp),%rax
   47a3d:	mov    0x20(%rax),%rax
   47a41:	mov    (%rax),%rcx
   47a44:	movabs $0x65727275636e6f63,%rdx
   47a4e:	xor    %rdx,%rcx
   47a51:	movzwl 0x8(%rax),%eax
   47a55:	xor    $0x746e,%rax
   47a5b:	or     %rcx,%rax
   47a5e:	je     47fa5 <construction_bench::main+0x855>
   47a64:	mov    0x58(%rsp),%rbp
   47a69:	mov    0x50(%rsp),%rdx
   47a6e:	lea    0x300(%rsp),%r15
   47a76:	mov    %r15,%rdi
   47a79:	mov    %rbp,%rsi
   47a7c:	call   3b550 <<ironweaver_core::graph::Graph<(), ()>>::with_capacity>
   47a81:	mov    0x28(%rsp),%r13
   47a86:	movq   $0x0,0x4f8(%rsp)
   47a92:	mov    %rbp,0x500(%rsp)
   47a9a:	mov    %r15,0x4f0(%rsp)
   47aa2:	lea    0x30(%rsp),%rdi
   47aa7:	lea    0x4f0(%rsp),%rbp
   47aaf:	mov    %rbp,%rsi
   47ab2:	call   40fe0 <<alloc::vec::Vec<ironweaver_core::graph::NodeIx> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<ironweaver_core::graph::NodeIx, core::iter::adapters::map::Map<core::ops::range::Range<usize>, construction_bench::fixture::{closure#0}>>>::from_iter>
   47ab7:	mov    $0x1d8,%edx
   47abc:	mov    %r12,%rdi
   47abf:	mov    %r15,%rsi
   47ac2:	mov    0x5ccbf(%rip),%r15        # a4788 <memcpy@GLIBC_2.14>
   47ac9:	call   *%r15
   47acc:	mov    %r15,%rcx
   47acf:	movups 0x30(%rsp),%xmm0
   47ad4:	lea    0x118(%rsp),%r15
   47adc:	movups %xmm0,0x1d0(%r15)
   47ae4:	mov    0x40(%rsp),%rax
   47ae9:	mov    %rax,0x1e0(%r15)
   47af0:	mov    $0x1d8,%edx
   47af5:	mov    %rbp,%rdi
   47af8:	mov    %r12,%rbp
   47afb:	mov    %r12,%rsi
   47afe:	call   *%rcx
   47b00:	mov    0x1e0(%r15),%rax
   47b07:	mov    %rax,0x40(%rsp)
   47b0c:	movupd 0x1d0(%r15),%xmm0
   47b15:	movapd %xmm0,0x30(%rsp)
   47b1b:	mov    0x20(%r13),%rcx
   47b1f:	mov    0x28(%r13),%rax
   47b23:	cmp    $0x9,%rax
   47b27:	jne    47b60 <construction_bench::main+0x410>
   47b29:	mov    (%rcx),%rdx
   47b2c:	movabs $0x726f62686769656e,%rsi
   47b36:	xor    %rsi,%rdx
   47b39:	movzbl 0x8(%rcx),%esi
   47b3d:	xor    $0x73,%rsi
   47b41:	or     %rdx,%rsi
   47b44:	mov    %rbp,%r12
   47b47:	lea    0x4d8(%rsp),%r13
   47b4f:	lea    0x4f0(%rsp),%rbp
   47b57:	jne    47b7d <construction_bench::main+0x42d>
   47b59:	jmp    47dd0 <construction_bench::main+0x680>
   47b5e:	xchg   %ax,%ax
   47b60:	cmp    $0x8,%rax
   47b64:	mov    %rbp,%r12
   47b67:	lea    0x4d8(%rsp),%r13
   47b6f:	lea    0x4f0(%rsp),%rbp
   47b77:	jb     47e12 <construction_bench::main+0x6c2>
   47b7d:	movabs $0x6870617267627573,%rdx
   47b87:	cmp    (%rcx),%rdx
   47b8a:	je     47dd0 <construction_bench::main+0x680>
   47b90:	cmp    $0xe,%rax
   47b94:	jne    47e12 <construction_bench::main+0x6c2>
   47b9a:	mov    0x28(%rsp),%rax
   47b9f:	mov    0x20(%rax),%rax
   47ba3:	mov    (%rax),%rcx
   47ba6:	movabs $0x6870617267627573,%rdx
   47bb0:	xor    %rdx,%rcx
   47bb3:	mov    0x6(%rax),%rax
   47bb7:	movabs $0x6c6c616d732d6870,%rdx
   47bc1:	xor    %rdx,%rax
   47bc4:	or     %rcx,%rax
   47bc7:	jne    47e39 <construction_bench::main+0x6e9>
   47bcd:	movl   $0x0,0x88(%rsp)
   47bd8:	lea    0x88(%rsp),%rax
   47be0:	mov    %rax,0x110(%rsp)
   47be8:	mov    0x5ce51(%rip),%rax        # a4a40 <_DYNAMIC+0x540>
   47bef:	mov    %rax,0x118(%rsp)
   47bf7:	lea    0xf8(%rsp),%rdi
   47bff:	lea    -0x3e791(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47c06:	mov    %r12,%rdx
   47c09:	call   *%r14
   47c0c:	lea    0x300(%rsp),%rdi
   47c14:	mov    %rbp,%rsi
   47c17:	lea    0xf8(%rsp),%rdx
   47c1f:	call   39430 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47c24:	cmpl   $0xffffffff,0x300(%rsp)
   47c2c:	jne    48b9f <construction_bench::main+0x144f>
   47c32:	movsd  0x308(%rsp),%xmm0
   47c3b:	movapd %xmm0,0x70(%rsp)
   47c41:	mov    0x40(%rsp),%r15
   47c46:	cmp    0x30(%rsp),%r15
   47c4b:	jne    47c58 <construction_bench::main+0x508>
   47c4d:	lea    0x30(%rsp),%rdi
   47c52:	call   *0x5cdf0(%rip)        # a4a48 <_DYNAMIC+0x548>
   47c58:	mov    0x38(%rsp),%rax
   47c5d:	movapd 0x70(%rsp),%xmm0
   47c63:	movlpd %xmm0,(%rax,%r15,8)
   47c69:	inc    %r15
   47c6c:	mov    %r15,0x40(%rsp)
   47c71:	movl   $0x1,0x88(%rsp)
   47c7c:	lea    0x88(%rsp),%rax
   47c84:	mov    %rax,0x110(%rsp)
   47c8c:	mov    0x5cdad(%rip),%rax        # a4a40 <_DYNAMIC+0x540>
   47c93:	mov    %rax,0x118(%rsp)
   47c9b:	lea    0xf8(%rsp),%rdi
   47ca3:	lea    -0x3e835(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47caa:	mov    %r12,%rdx
   47cad:	call   *%r14
   47cb0:	lea    0x300(%rsp),%rdi
   47cb8:	mov    %rbp,%rsi
   47cbb:	lea    0xf8(%rsp),%rdx
   47cc3:	call   39430 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47cc8:	cmpl   $0xffffffff,0x300(%rsp)
   47cd0:	jne    48b9f <construction_bench::main+0x144f>
   47cd6:	movsd  0x308(%rsp),%xmm0
   47cdf:	movapd %xmm0,0x70(%rsp)
   47ce5:	mov    0x40(%rsp),%r15
   47cea:	cmp    0x30(%rsp),%r15
   47cef:	jne    47cfc <construction_bench::main+0x5ac>
   47cf1:	lea    0x30(%rsp),%rdi
   47cf6:	call   *0x5cd4c(%rip)        # a4a48 <_DYNAMIC+0x548>
   47cfc:	mov    0x38(%rsp),%rax
   47d01:	movapd 0x70(%rsp),%xmm0
   47d07:	movlpd %xmm0,(%rax,%r15,8)
   47d0d:	inc    %r15
   47d10:	mov    %r15,0x40(%rsp)
   47d15:	movl   $0x2,0x88(%rsp)
   47d20:	lea    0x88(%rsp),%rax
   47d28:	mov    %rax,0x110(%rsp)
   47d30:	mov    0x5cd09(%rip),%rax        # a4a40 <_DYNAMIC+0x540>
   47d37:	mov    %rax,0x118(%rsp)
   47d3f:	lea    0xf8(%rsp),%rdi
   47d47:	lea    -0x3e8d9(%rip),%rsi        # 9475 <anon.7091b7ef657caedcc2fa209982c793b5.1.llvm.9337857877282664933+0x16f>
   47d4e:	mov    %r12,%rdx
   47d51:	call   *%r14
   47d54:	lea    0x300(%rsp),%rdi
   47d5c:	mov    %rbp,%rsi
   47d5f:	lea    0xf8(%rsp),%rdx
   47d67:	call   39430 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   47d6c:	cmpl   $0xffffffff,0x300(%rsp)
   47d74:	jne    48b9f <construction_bench::main+0x144f>
   47d7a:	movsd  0x308(%rsp),%xmm0
   47d83:	movapd %xmm0,0x70(%rsp)
   47d89:	mov    0x40(%rsp),%r15
   47d8e:	cmp    0x30(%rsp),%r15
   47d93:	jne    47da0 <construction_bench::main+0x650>
   47d95:	lea    0x30(%rsp),%rdi
   47d9a:	call   *0x5cca8(%rip)        # a4a48 <_DYNAMIC+0x548>
   47da0:	mov    0x38(%rsp),%rax
   47da5:	movapd 0x70(%rsp),%xmm0
   47dab:	movlpd %xmm0,(%rax,%r15,8)
   47db1:	inc    %r15
   47db4:	mov    %r15,0x40(%rsp)
   47db9:	mov    0x28(%rsp),%rax
   47dbe:	mov    0x28(%rax),%rax
   47dc2:	cmp    $0x5,%rax
   47dc6:	je     47e18 <construction_bench::main+0x6c8>
   47dc8:	jmp    47e39 <construction_bench::main+0x6e9>
   47dca:	nopw   0x0(%rax,%rax,1)
   47dd0:	mov    0x38(%rsp),%rsi
   47dd5:	mov    0x40(%rsp),%rdx
   47dda:	mov    %rbp,%rdi
   47ddd:	mov    $0x1,%bpl
   47de0:	mov    0x50(%rsp),%rcx
   47de5:	mov    $0x6,%r9d
   47deb:	lea    -0x3d512(%rip),%r8        # a8e0 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111>
   47df2:	call   48f50 <construction_bench::edges>
   47df7:	mov    0x28(%rsp),%rax
   47dfc:	mov    0x28(%rax),%rax
   47e00:	lea    0x4f0(%rsp),%rbp
   47e08:	cmp    $0xe,%rax
   47e0c:	je     47b9a <construction_bench::main+0x44a>
   47e12:	cmp    $0x5,%rax
   47e16:	jne    47e39 <construction_bench::main+0x6e9>
   47e18:	mov    0x28(%rsp),%rax
   47e1d:	mov    0x20(%rax),%rax
   47e21:	mov    (%rax),%ecx
   47e23:	mov    $0x6c617473,%edx
   47e28:	xor    %edx,%ecx
   47e2a:	movzbl 0x4(%rax),%eax
   47e2e:	xor    $0x65,%eax
   47e31:	or     %ecx,%eax
   47e33:	je     48770 <construction_bench::main+0x1020>
   47e39:	xor    %r15d,%r15d
   47e3c:	mov    $0x1,%bpl
   47e3f:	call   *0x5cc0b(%rip)        # a4a50 <_DYNAMIC+0x550>
   47e45:	mov    %rax,0x88(%rsp)
   47e4d:	mov    %edx,0x90(%rsp)
   47e54:	mov    0x28(%rsp),%rax
   47e59:	mov    0x20(%rax),%r8
   47e5d:	mov    0x28(%rax),%r9
   47e61:	lea    -0x5(%r9),%rax
   47e65:	cmp    $0x9,%rax
   47e69:	ja     48530 <construction_bench::main+0xde0>
   47e6f:	lea    -0x3d616(%rip),%rcx        # a860 <anon.5d09ad63f943746d04ae2dafc92c2e77.3.llvm.11945693191618023075+0x74>
   47e76:	movslq (%rcx,%rax,4),%rax
   47e7a:	add    %rcx,%rax
   47e7d:	jmp    *%rax
   47e7f:	mov    (%r8),%eax
   47e82:	mov    $0x65646f6e,%ecx
   47e87:	xor    %ecx,%eax
   47e89:	movzbl 0x4(%r8),%ecx
   47e8e:	xor    $0x73,%ecx
   47e91:	or     %eax,%ecx
   47e93:	je     487ff <construction_bench::main+0x10af>
   47e99:	mov    (%r8),%eax
   47e9c:	mov    $0x6c617473,%ecx
   47ea1:	xor    %ecx,%eax
   47ea3:	movzbl 0x4(%r8),%ecx
   47ea8:	xor    $0x65,%ecx
   47eab:	or     %eax,%ecx
   47ead:	jne    48530 <construction_bench::main+0xde0>
   47eb3:	cmpq   $0x0,0x50(%rsp)
   47eb9:	je     4854c <construction_bench::main+0xdfc>
   47ebf:	test   %r15b,%r15b
   47ec2:	je     48cae <construction_bench::main+0x155e>
   47ec8:	xor    %r15d,%r15d
   47ecb:	jmp    47ede <construction_bench::main+0x78e>
   47ecd:	nopl   (%rax)
   47ed0:	inc    %r15
   47ed3:	cmp    0x50(%rsp),%r15
   47ed8:	jae    4854c <construction_bench::main+0xdfc>
   47ede:	cmpq   $0x0,0x40(%rsp)
   47ee4:	je     48cf8 <construction_bench::main+0x15a8>
   47eea:	mov    0x38(%rsp),%rax
   47eef:	mov    (%rax),%r8d
   47ef2:	mov    0x4(%rax),%r9d
   47ef6:	movq   $0x0,0x10(%rsp)
   47eff:	movq   $0x0,(%rsp)
   47f07:	mov    %r12,%rdi
   47f0a:	lea    0x4f0(%rsp),%rsi
   47f12:	mov    0xbc(%rsp),%edx
   47f19:	mov    0xb8(%rsp),%ecx
   47f20:	call   39de0 <<ironweaver_core::graph::Graph<(), ()>>::insert_edge>
   47f25:	cmpl   $0xffffffff,0x110(%rsp)
   47f2d:	je     48afe <construction_bench::main+0x13ae>
   47f33:	movupd 0x110(%rsp),%xmm0
   47f3c:	movupd 0x120(%rsp),%xmm1
   47f45:	movapd %xmm1,0x310(%rsp)
   47f4e:	movapd %xmm0,0x300(%rsp)
   47f57:	lea    0x300(%rsp),%rax
   47f5f:	mov    0x300(%rsp),%rax
   47f67:	cmp    $0xa,%rax
   47f6b:	ja     47f7c <construction_bench::main+0x82c>
   47f6d:	mov    $0x51c,%ecx
   47f72:	bt     %rax,%rcx
   47f76:	jb     47ed0 <construction_bench::main+0x780>
   47f7c:	mov    0x308(%rsp),%rsi
   47f84:	test   %rsi,%rsi
   47f87:	je     47ed0 <construction_bench::main+0x780>
   47f8d:	mov    0x310(%rsp),%rdi
   47f95:	mov    $0x1,%edx
   47f9a:	call   *0x5c7a0(%rip)        # a4740 <_DYNAMIC+0x240>
   47fa0:	jmp    47ed0 <construction_bench::main+0x780>
   47fa5:	movabs $0x400000000,%rax
   47faf:	mov    %rax,0x120(%rsp)
   47fb7:	lea    0x58(%rsp),%rax
   47fbc:	mov    %rax,0x110(%rsp)
   47fc4:	lea    0x50(%rsp),%rax
   47fc9:	mov    %rax,0x118(%rsp)
   47fd1:	lea    0x30(%rsp),%rdi
   47fd6:	mov    %r12,%rsi
   47fd9:	call   410f0 <<alloc::vec::Vec<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)> as alloc::vec::spec_from_iter_nested::SpecFromIterNested<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>), core::iter::adapters::map::Map<core::ops::range::Range<i32>, construction_bench::main::{closure#1}>>>::from_iter>
   47fde:	call   *0x5ca6c(%rip)        # a4a50 <_DYNAMIC+0x550>
   47fe4:	mov    %rax,0x88(%rsp)
   47fec:	mov    %edx,0x90(%rsp)
   47ff3:	mov    0x40(%rsp),%rax
   47ff8:	mov    %rax,0x120(%rsp)
   48000:	movups 0x30(%rsp),%xmm0
   48005:	movaps %xmm0,0x110(%rsp)
   4800d:	movq   $0x0,0x300(%rsp)
   48019:	movq   $0x8,0x308(%rsp)
   48025:	movq   $0x0,0x310(%rsp)
   48031:	lea    0x50(%rsp),%rax
   48036:	mov    %rax,0x128(%rsp)
   4803e:	lea    0x300(%rsp),%rdi
   48046:	mov    %r12,%rsi
   48049:	call   40c50 <<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>> as rayon::iter::ParallelExtend<ironweaver_core::graph::Graph<(), ()>>>::par_extend::<rayon::iter::map::Map<rayon::vec::IntoIter<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)>, construction_bench::main::{closure#2}>>>
   4804e:	movupd 0x300(%rsp),%xmm0
   48057:	movapd %xmm0,0x4f0(%rsp)
   48060:	mov    0x310(%rsp),%rax
   48068:	mov    %rax,0x500(%rsp)
   48070:	lea    0x88(%rsp),%rdi
   48078:	call   *0x5c9da(%rip)        # a4a58 <_DYNAMIC+0x558>
   4807e:	movq   %rax,%xmm0
   48083:	punpckldq -0x403cb(%rip),%xmm0        # 7cc0 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.6382042878189896662+0x70>
   4808b:	xorps  %xmm1,%xmm1
   4808e:	cvtsi2sd %edx,%xmm1
   48092:	subpd  -0x4043a(%rip),%xmm0        # 7c60 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.6382042878189896662+0x10>
   4809a:	movapd %xmm0,0x70(%rsp)
   480a0:	divsd  -0x3dc48(%rip),%xmm1        # a460 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763+0x88>
   480a8:	movsd  %xmm1,0x68(%rsp)
   480ae:	mov    0x500(%rsp),%rcx
   480b6:	test   %rcx,%rcx
   480b9:	je     480f7 <construction_bench::main+0x9a7>
   480bb:	mov    0x4f8(%rsp),%rax
   480c3:	imul   $0x1d8,%rcx,%rcx
   480ca:	mov    0x50(%rsp),%rdx
   480cf:	xor    %esi,%esi
   480d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   480e0:	cmp    %rdx,0x68(%rax,%rsi,1)
   480e5:	jne    48ccf <construction_bench::main+0x157f>
   480eb:	add    $0x1d8,%rsi
   480f2:	cmp    %rsi,%rcx
   480f5:	jne    480e0 <construction_bench::main+0x990>
   480f7:	mov    0x500(%rsp),%rax
   480ff:	mov    %rax,0x120(%rsp)
   48107:	movapd 0x4f0(%rsp),%xmm0
   48110:	movapd %xmm0,0x110(%rsp)
   48119:	mov    0x120(%rsp),%rax
   48121:	test   %rax,%rax
   48124:	je     48158 <construction_bench::main+0xa08>
   48126:	mov    0x118(%rsp),%rbp
   4812e:	mov    $0x1,%r15d
   48134:	sub    %rax,%r15
   48137:	nopw   0x0(%rax,%rax,1)
   48140:	mov    %rbp,%rdi
   48143:	call   40600 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48148:	add    $0x1d8,%rbp
   4814f:	inc    %r15
   48152:	cmp    $0x1,%r15
   48156:	jne    48140 <construction_bench::main+0x9f0>
   48158:	mov    0x110(%rsp),%rax
   48160:	test   %rax,%rax
   48163:	je     4817f <construction_bench::main+0xa2f>
   48165:	mov    0x118(%rsp),%rdi
   4816d:	imul   $0x1d8,%rax,%rsi
   48174:	mov    $0x8,%edx
   48179:	call   *0x5c5c1(%rip)        # a4740 <_DYNAMIC+0x240>
   4817f:	movapd 0x70(%rsp),%xmm1
   48185:	movapd %xmm1,%xmm0
   48189:	unpckhpd %xmm1,%xmm0
   4818d:	addsd  %xmm1,%xmm0
   48191:	movsd  0x68(%rsp),%xmm1
   48197:	addsd  %xmm0,%xmm1
   4819b:	movsd  %xmm1,0x300(%rsp)
   481a4:	jmp    486f2 <construction_bench::main+0xfa2>
   481a9:	mov    (%r8),%rax
   481ac:	movabs $0x726f62686769656e,%rcx
   481b6:	xor    %rcx,%rax
   481b9:	movzbl 0x8(%r8),%ecx
   481be:	xor    $0x73,%rcx
   481c2:	or     %rax,%rcx
   481c5:	jne    48530 <construction_bench::main+0xde0>
   481cb:	mov    0x40(%rsp),%r11
   481d0:	test   %r11,%r11
   481d3:	je     48992 <construction_bench::main+0x1242>
   481d9:	mov    0x38(%rsp),%rcx
   481de:	mov    0x4f8(%rsp),%r15
   481e6:	mov    0x500(%rsp),%r13
   481ee:	mov    0x538(%rsp),%rdi
   481f6:	mov    0x530(%rsp),%r9
   481fe:	xor    %r10d,%r10d
   48201:	xor    %r8d,%r8d
   48204:	mov    %r13,0x70(%rsp)
   48209:	mov    %r11,0x68(%rsp)
   4820e:	mov    %r15,0xa0(%rsp)
   48216:	jmp    48236 <construction_bench::main+0xae6>
   48218:	nopl   0x0(%rax,%rax,1)
   48220:	xor    %esi,%esi
   48222:	xor    %eax,%eax
   48224:	add    %rsi,%r8
   48227:	add    %rax,%r8
   4822a:	inc    %r10
   4822d:	cmp    %r11,%r10
   48230:	je     48995 <construction_bench::main+0x1245>
   48236:	mov    (%rcx,%r10,8),%eax
   4823a:	cmp    %rax,%r13
   4823d:	jbe    48220 <construction_bench::main+0xad0>
   4823f:	mov    0x4(%rcx,%r10,8),%edx
   48244:	imul   $0x68,%rax,%rax
   48248:	cmp    %edx,0x60(%r15,%rax,1)
   4824d:	jne    48220 <construction_bench::main+0xad0>
   4824f:	add    %r15,%rax
   48252:	cmpq   $0xffffffffffffffff,(%rax)
   48256:	je     48220 <construction_bench::main+0xad0>
   48258:	mov    0x40(%rax),%r15
   4825c:	mov    0x50(%rax),%rdx
   48260:	mov    0x58(%rax),%r11
   48264:	test   %r15,%r15
   48267:	je     483a7 <construction_bench::main+0xc57>
   4826d:	mov    0x38(%rax),%rax
   48271:	mov    (%rax),%esi
   48273:	cmp    %rsi,%rdi
   48276:	jbe    48a56 <construction_bench::main+0x1306>
   4827c:	lea    (%rsi,%rsi,4),%rsi
   48280:	mov    0x20(%r9,%rsi,8),%r13d
   48285:	cmp    0x4(%rax),%r13d
   48289:	jne    48a56 <construction_bench::main+0x1306>
   4828f:	lea    (%r9,%rsi,8),%rsi
   48293:	cmpl   $0x2,(%rsi)
   48296:	je     48a56 <construction_bench::main+0x1306>
   4829c:	mov    $0x1,%esi
   482a1:	cmp    $0x1,%r15
   482a5:	mov    0x98(%rsp),%rbx
   482ad:	mov    0x70(%rsp),%r13
   482b2:	je     48306 <construction_bench::main+0xbb6>
   482b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   482c0:	mov    (%rax,%rsi,8),%r13d
   482c4:	cmp    %r13,%rdi
   482c7:	jbe    48a56 <construction_bench::main+0x1306>
   482cd:	lea    0x0(%r13,%r13,4),%r13
   482d2:	mov    0x20(%r9,%r13,8),%ebx
   482d7:	cmp    0x4(%rax,%rsi,8),%ebx
   482db:	jne    48a56 <construction_bench::main+0x1306>
   482e1:	lea    (%r9,%r13,8),%rbx
   482e5:	cmpl   $0x2,(%rbx)
   482e8:	je     48a56 <construction_bench::main+0x1306>
   482ee:	inc    %rsi
   482f1:	cmp    %rsi,%r15
   482f4:	jne    482c0 <construction_bench::main+0xb70>
   482f6:	mov    %r15,%rsi
   482f9:	mov    0x98(%rsp),%rbx
   48301:	mov    0x70(%rsp),%r13
   48306:	test   %r11,%r11
   48309:	je     483b2 <construction_bench::main+0xc62>
   4830f:	mov    (%rdx),%eax
   48311:	cmp    %rax,%rdi
   48314:	jbe    48a56 <construction_bench::main+0x1306>
   4831a:	lea    (%rax,%rax,4),%rax
   4831e:	mov    0x20(%r9,%rax,8),%ebx
   48323:	cmp    0x4(%rdx),%ebx
   48326:	jne    48a56 <construction_bench::main+0x1306>
   4832c:	lea    (%r9,%rax,8),%rax
   48330:	cmpl   $0x2,(%rax)
   48333:	je     48a56 <construction_bench::main+0x1306>
   48339:	mov    $0x1,%eax
   4833e:	cmp    $0x1,%r11
   48342:	je     48388 <construction_bench::main+0xc38>
   48344:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   48350:	mov    (%rdx,%rax,8),%r15d
   48354:	cmp    %r15,%rdi
   48357:	jbe    48a56 <construction_bench::main+0x1306>
   4835d:	lea    (%r15,%r15,4),%r15
   48361:	mov    0x20(%r9,%r15,8),%ebx
   48366:	cmp    0x4(%rdx,%rax,8),%ebx
   4836a:	jne    48a56 <construction_bench::main+0x1306>
   48370:	lea    (%r9,%r15,8),%rbx
   48374:	cmpl   $0x2,(%rbx)
   48377:	je     48a56 <construction_bench::main+0x1306>
   4837d:	inc    %rax
   48380:	cmp    %rax,%r11
   48383:	jne    48350 <construction_bench::main+0xc00>
   48385:	mov    %r11,%rax
   48388:	mov    0x98(%rsp),%rbx
   48390:	mov    0x68(%rsp),%r11
   48395:	mov    0xa0(%rsp),%r15
   4839d:	mov    0x70(%rsp),%r13
   483a2:	jmp    48224 <construction_bench::main+0xad4>
   483a7:	xor    %esi,%esi
   483a9:	test   %r11,%r11
   483ac:	jne    4830f <construction_bench::main+0xbbf>
   483b2:	xor    %eax,%eax
   483b4:	mov    0x68(%rsp),%r11
   483b9:	mov    0xa0(%rsp),%r15
   483c1:	jmp    48224 <construction_bench::main+0xad4>
   483c6:	movabs $0x6870617267627573,%rax
   483d0:	cmp    %rax,(%r8)
   483d3:	jne    48530 <construction_bench::main+0xde0>
   483d9:	mov    0x38(%rsp),%rdx
   483de:	mov    0x40(%rsp),%r15
   483e3:	jmp    488ad <construction_bench::main+0x115d>
   483e8:	mov    (%r8),%rax
   483eb:	movabs $0x746163696c707564,%rcx
   483f5:	xor    %rcx,%rax
   483f8:	movzwl 0x8(%r8),%ecx
   483fd:	xor    $0x7365,%rcx
   48404:	or     %rax,%rcx
   48407:	jne    48530 <construction_bench::main+0xde0>
   4840d:	cmpq   $0x0,0x58(%rsp)
   48413:	je     4854c <construction_bench::main+0xdfc>
   48419:	xor    %r15d,%r15d
   4841c:	jmp    4842e <construction_bench::main+0xcde>
   4841e:	xchg   %ax,%ax
   48420:	inc    %r15
   48423:	cmp    0x58(%rsp),%r15
   48428:	jae    4854c <construction_bench::main+0xdfc>
   4842e:	mov    %r15,0x60(%rsp)
   48433:	lea    0x60(%rsp),%rax
   48438:	mov    %rax,0x300(%rsp)
   48440:	mov    0x5c451(%rip),%rax        # a4898 <_DYNAMIC+0x398>
   48447:	mov    %rax,0x308(%rsp)
   4844f:	mov    %r13,%rdi
   48452:	lea    -0x3ee78(%rip),%rsi        # 95e1 <anon.7091b7ef657caedcc2fa209982c793b5.0.llvm.9337857877282664933>
   48459:	lea    0x300(%rsp),%rdx
   48461:	call   *%r14
   48464:	mov    %r12,%rdi
   48467:	lea    0x4f0(%rsp),%rsi
   4846f:	mov    %r13,%rdx
   48472:	call   39430 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   48477:	cmpl   $0xffffffff,0x110(%rsp)
   4847f:	je     48ac5 <construction_bench::main+0x1375>
   48485:	movupd 0x110(%rsp),%xmm0
   4848e:	movupd 0x120(%rsp),%xmm1
   48497:	movapd %xmm1,0x310(%rsp)
   484a0:	movapd %xmm0,0x300(%rsp)
   484a9:	lea    0x300(%rsp),%rax
   484b1:	mov    0x300(%rsp),%rax
   484b9:	cmp    $0xa,%rax
   484bd:	ja     484ce <construction_bench::main+0xd7e>
   484bf:	mov    $0x51c,%ecx
   484c4:	bt     %rax,%rcx
   484c8:	jb     48420 <construction_bench::main+0xcd0>
   484ce:	mov    0x308(%rsp),%rsi
   484d6:	test   %rsi,%rsi
   484d9:	je     48420 <construction_bench::main+0xcd0>
   484df:	mov    0x310(%rsp),%rdi
   484e7:	mov    $0x1,%edx
   484ec:	call   *0x5c24e(%rip)        # a4740 <_DYNAMIC+0x240>
   484f2:	jmp    48420 <construction_bench::main+0xcd0>
   484f7:	mov    (%r8),%rax
   484fa:	movabs $0x6870617267627573,%rcx
   48504:	xor    %rcx,%rax
   48507:	mov    0x6(%r8),%rcx
   4850b:	movabs $0x6c6c616d732d6870,%rdx
   48515:	xor    %rdx,%rcx
   48518:	or     %rax,%rcx
   4851b:	je     4888e <construction_bench::main+0x113e>
   48521:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   48530:	mov    0x38(%rsp),%rsi
   48535:	mov    0x40(%rsp),%rdx
   4853a:	mov    0x50(%rsp),%rcx
   4853f:	lea    0x4f0(%rsp),%rdi
   48547:	call   48f50 <construction_bench::edges>
   4854c:	lea    0x88(%rsp),%rdi
   48554:	call   *0x5c4fe(%rip)        # a4a58 <_DYNAMIC+0x558>
   4855a:	movq   %rax,%xmm0
   4855f:	punpckldq -0x408a7(%rip),%xmm0        # 7cc0 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.6382042878189896662+0x70>
   48567:	subpd  -0x4090f(%rip),%xmm0        # 7c60 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.6382042878189896662+0x10>
   4856f:	xorps  %xmm1,%xmm1
   48572:	cvtsi2sd %edx,%xmm1
   48576:	divsd  -0x3e11e(%rip),%xmm1        # a460 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763+0x88>
   4857e:	mov    0x28(%rsp),%rax
   48583:	mov    0x28(%rax),%rcx
   48587:	add    $0xfffffffffffffffb,%rcx
   4858b:	cmp    $0x9,%rcx
   4858f:	lea    0x4f0(%rsp),%rsi
   48597:	ja     48670 <construction_bench::main+0xf20>
   4859d:	mov    0x28(%rsp),%rax
   485a2:	mov    0x20(%rax),%rax
   485a6:	lea    -0x3dd25(%rip),%rdx        # a888 <anon.5d09ad63f943746d04ae2dafc92c2e77.3.llvm.11945693191618023075+0x9c>
   485ad:	movslq (%rdx,%rcx,4),%rcx
   485b1:	add    %rdx,%rcx
   485b4:	jmp    *%rcx
   485b6:	mov    (%rax),%ecx
   485b8:	mov    $0x65646f6e,%edx
   485bd:	xor    %edx,%ecx
   485bf:	movzbl 0x4(%rax),%edx
   485c3:	xor    $0x73,%edx
   485c6:	or     %ecx,%edx
   485c8:	je     4868b <construction_bench::main+0xf3b>
   485ce:	mov    (%rax),%ecx
   485d0:	mov    $0x6c617473,%edx
   485d5:	xor    %edx,%ecx
   485d7:	movzbl 0x4(%rax),%eax
   485db:	xor    $0x65,%eax
   485de:	or     %ecx,%eax
   485e0:	jne    48670 <construction_bench::main+0xf20>
   485e6:	jmp    4868b <construction_bench::main+0xf3b>
   485eb:	mov    (%rax),%rcx
   485ee:	movabs $0x726f62686769656e,%rdx
   485f8:	xor    %rdx,%rcx
   485fb:	movzbl 0x8(%rax),%eax
   485ff:	xor    $0x73,%rax
   48603:	or     %rcx,%rax
   48606:	jne    48670 <construction_bench::main+0xf20>
   48608:	jmp    4868b <construction_bench::main+0xf3b>
   4860d:	movabs $0x6870617267627573,%rcx
   48617:	cmp    %rcx,(%rax)
   4861a:	jne    48670 <construction_bench::main+0xf20>
   4861c:	jmp    4868b <construction_bench::main+0xf3b>
   4861e:	mov    (%rax),%rcx
   48621:	movabs $0x746163696c707564,%rdx
   4862b:	xor    %rdx,%rcx
   4862e:	movzwl 0x8(%rax),%eax
   48632:	xor    $0x7365,%rax
   48638:	or     %rcx,%rax
   4863b:	jne    48670 <construction_bench::main+0xf20>
   4863d:	jmp    4868b <construction_bench::main+0xf3b>
   4863f:	mov    (%rax),%rcx
   48642:	movabs $0x6870617267627573,%rdx
   4864c:	xor    %rdx,%rcx
   4864f:	mov    0x6(%rax),%rax
   48653:	movabs $0x6c6c616d732d6870,%rdx
   4865d:	xor    %rdx,%rax
   48660:	or     %rcx,%rax
   48663:	je     4868b <construction_bench::main+0xf3b>
   48665:	data16 cs nopw 0x0(%rax,%rax,1)
   48670:	mov    0x558(%rsp),%rax
   48678:	mov    %rax,0x110(%rsp)
   48680:	cmp    0x50(%rsp),%rax
   48685:	jne    48b41 <construction_bench::main+0x13f1>
   4868b:	movsd  %xmm1,0x68(%rsp)
   48691:	movapd %xmm0,0x70(%rsp)
   48697:	mov    $0x1d8,%edx
   4869c:	mov    %r12,%rdi
   4869f:	call   *0x5c0e3(%rip)        # a4788 <memcpy@GLIBC_2.14>
   486a5:	xor    %ebp,%ebp
   486a7:	mov    %r12,%rdi
   486aa:	call   46ea0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   486af:	movapd 0x70(%rsp),%xmm1
   486b5:	movapd %xmm1,%xmm0
   486b9:	unpckhpd %xmm1,%xmm0
   486bd:	addsd  %xmm1,%xmm0
   486c1:	movsd  0x68(%rsp),%xmm1
   486c7:	addsd  %xmm0,%xmm1
   486cb:	movsd  %xmm1,0x300(%rsp)
   486d4:	mov    0x30(%rsp),%rsi
   486d9:	test   %rsi,%rsi
   486dc:	je     486f2 <construction_bench::main+0xfa2>
   486de:	mov    0x38(%rsp),%rdi
   486e3:	shl    $0x3,%rsi
   486e7:	mov    $0x4,%edx
   486ec:	call   *0x5c04e(%rip)        # a4740 <_DYNAMIC+0x240>
   486f2:	cmpq   $0x1,0xb0(%rsp)
   486fb:	jbe    47a10 <construction_bench::main+0x2c0>
   48701:	lea    0xf0(%rsp),%rax
   48709:	mov    %rax,0x110(%rsp)
   48711:	lea    -0x1e98(%rip),%rax        # 46880 <<&alloc::string::String as core::fmt::Display>::fmt>
   48718:	mov    %rax,0x118(%rsp)
   48720:	lea    0x58(%rsp),%rax
   48725:	mov    %rax,0x120(%rsp)
   4872d:	mov    0x5c164(%rip),%rax        # a4898 <_DYNAMIC+0x398>
   48734:	mov    %rax,0x128(%rsp)
   4873c:	lea    0x300(%rsp),%rax
   48744:	mov    %rax,0x130(%rsp)
   4874c:	mov    0x5c30d(%rip),%rax        # a4a60 <_DYNAMIC+0x560>
   48753:	mov    %rax,0x138(%rsp)
   4875b:	lea    -0x408d2(%rip),%rdi        # 7e90 <anon.e2903b0ff1cd2a585841d55af0dbc273.0.llvm.6382042878189896662+0x240>
   48762:	mov    %r12,%rsi
   48765:	call   *0x5c2cd(%rip)        # a4a38 <_DYNAMIC+0x538>
   4876b:	jmp    47a10 <construction_bench::main+0x2c0>
   48770:	mov    %rbp,%rsi
   48773:	mov    $0x1,%bpl
   48776:	mov    $0x7,%ecx
   4877b:	lea    0x300(%rsp),%rdi
   48783:	lea    -0x3de95(%rip),%rdx        # a8f5 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x15>
   4878a:	call   394e0 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<&str>>
   4878f:	cmpl   $0xffffffff,0x300(%rsp)
   48797:	jne    48bf0 <construction_bench::main+0x14a0>
   4879d:	mov    0x308(%rsp),%edx
   487a4:	mov    0x30c(%rsp),%ecx
   487ab:	mov    %r12,%rdi
   487ae:	lea    0x4f0(%rsp),%rsi
   487b6:	mov    %edx,0xbc(%rsp)
   487bd:	mov    %ecx,0xb8(%rsp)
   487c4:	call   3a580 <<ironweaver_core::graph::Graph<(), ()>>::remove_node>
   487c9:	mov    0x110(%rsp),%rsi
   487d1:	cmp    $0xffffffffffffffff,%rsi
   487d5:	je     48c41 <construction_bench::main+0x14f1>
   487db:	mov    $0x1,%r15b
   487de:	test   %rsi,%rsi
   487e1:	je     47e3c <construction_bench::main+0x6ec>
   487e7:	mov    0x118(%rsp),%rdi
   487ef:	mov    $0x1,%edx
   487f4:	call   *0x5bf46(%rip)        # a4740 <_DYNAMIC+0x240>
   487fa:	jmp    47e3c <construction_bench::main+0x6ec>
   487ff:	cmpq   $0x0,0x58(%rsp)
   48805:	je     4854c <construction_bench::main+0xdfc>
   4880b:	xor    %r15d,%r15d
   4880e:	xchg   %ax,%ax
   48810:	mov    %r15,0x60(%rsp)
   48815:	lea    0x60(%rsp),%rax
   4881a:	mov    %rax,0x110(%rsp)
   48822:	mov    0x5c06f(%rip),%rax        # a4898 <_DYNAMIC+0x398>
   48829:	mov    %rax,0x118(%rsp)
   48831:	lea    0x6d0(%rsp),%r13
   48839:	mov    %r13,%rdi
   4883c:	lea    -0x3fb39(%rip),%rsi        # 8d0a <anon.6ce2bd37e1c81bd133be53b065f15922.5.llvm.5838934960365399480+0x55f>
   48843:	mov    %r12,%rdx
   48846:	call   *%r14
   48849:	lea    0x300(%rsp),%rdi
   48851:	lea    0x4f0(%rsp),%rsi
   48859:	mov    %r13,%rdx
   4885c:	call   39430 <<ironweaver_core::graph::Graph<(), ()>>::add_node::<alloc::string::String>>
   48861:	cmpl   $0xffffffff,0x300(%rsp)
   48869:	jne    48a74 <construction_bench::main+0x1324>
   4886f:	inc    %r15
   48872:	mov    0x308(%rsp),%rax
   4887a:	mov    %rax,0x110(%rsp)
   48882:	cmp    0x58(%rsp),%r15
   48887:	jb     48810 <construction_bench::main+0x10c0>
   48889:	jmp    4854c <construction_bench::main+0xdfc>
   4888e:	mov    0x40(%rsp),%rsi
   48893:	mov    0x58(%rsp),%rdx
   48898:	mov    %rsi,%r15
   4889b:	sub    %rdx,%r15
   4889e:	jb     48c96 <construction_bench::main+0x1546>
   488a4:	shl    $0x3,%rdx
   488a8:	add    0x38(%rsp),%rdx
   488ad:	lea    (%rdx,%r15,8),%rcx
   488b1:	mov    %r12,%rdi
   488b4:	lea    0x4f0(%rsp),%rsi
   488bc:	call   377e0 <<ironweaver_core::graph::Graph<(), ()>>::induced_subgraph::<(), (), core::convert::Infallible, core::iter::adapters::copied::Copied<core::slice::iter::Iter<ironweaver_core::graph::NodeIx>>, construction_bench::main::{closure#3}, construction_bench::main::{closure#4}>>
   488c1:	mov    $0x1d8,%edx
   488c6:	lea    0x300(%rsp),%rdi
   488ce:	mov    %r12,%rsi
   488d1:	call   *0x5beb1(%rip)        # a4788 <memcpy@GLIBC_2.14>
   488d7:	mov    0x330(%rsp),%rax
   488df:	mov    %rax,0x60(%rsp)
   488e4:	mov    %r15,0x110(%rsp)
   488ec:	cmp    %r15,%rax
   488ef:	jne    48c53 <construction_bench::main+0x1503>
   488f5:	mov    0x4c0(%rsp),%rax
   488fd:	mov    %rax,0x60(%rsp)
   48902:	mov    0x6b0(%rsp),%rcx
   4890a:	mov    %rcx,0x110(%rsp)
   48912:	cmp    %rcx,%rax
   48915:	jne    48c74 <construction_bench::main+0x1524>
   4891b:	mov    0x28(%rsp),%rax
   48920:	cmpq   $0xe,0x28(%rax)
   48925:	jne    4896f <construction_bench::main+0x121f>
   48927:	mov    0x28(%rsp),%rax
   4892c:	mov    0x20(%rax),%rax
   48930:	mov    (%rax),%rcx
   48933:	movabs $0x6870617267627573,%rdx
   4893d:	xor    %rdx,%rcx
   48940:	mov    0x6(%rax),%rax
   48944:	movabs $0x6c6c616d732d6870,%rdx
   4894e:	xor    %rdx,%rax
   48951:	or     %rcx,%rax
   48954:	jne    4896f <construction_bench::main+0x121f>
   48956:	mov    0x368(%rsp),%rax
   4895e:	mov    %rax,0x110(%rsp)
   48966:	test   %rax,%rax
   48969:	jne    48cb7 <construction_bench::main+0x1567>
   4896f:	mov    $0x1d8,%edx
   48974:	mov    %r12,%rdi
   48977:	lea    0x300(%rsp),%rsi
   4897f:	call   *0x5be03(%rip)        # a4788 <memcpy@GLIBC_2.14>
   48985:	mov    %r12,%rdi
   48988:	call   46ea0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   4898d:	jmp    4854c <construction_bench::main+0xdfc>
   48992:	xor    %r8d,%r8d
   48995:	mov    %r8,0x300(%rsp)
   4899d:	lea    0x300(%rsp),%rax
   489a5:	mov    0x50(%rsp),%rax
   489aa:	add    %rax,%rax
   489ad:	mov    %rax,0x110(%rsp)
   489b5:	cmp    %rax,0x300(%rsp)
   489bd:	je     4854c <construction_bench::main+0xdfc>
   489c3:	lea    0x300(%rsp),%rsi
   489cb:	lea    0x58aee(%rip),%r9        # a14c0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xd8>
   489d2:	jmp    48b50 <construction_bench::main+0x1400>
   489d7:	mov    0x28(%rsp),%rax
   489dc:	lea    0x8(%rax),%rbx
   489e0:	mov    0x5bd59(%rip),%r15        # a4740 <_DYNAMIC+0x240>
   489e7:	mov    0xa8(%rsp),%r14
   489ef:	jmp    48a09 <construction_bench::main+0x12b9>
   489f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   48a00:	add    $0x18,%rbx
   48a04:	dec    %r14
   48a07:	je     48a1f <construction_bench::main+0x12cf>
   48a09:	mov    -0x8(%rbx),%rsi
   48a0d:	test   %rsi,%rsi
   48a10:	je     48a00 <construction_bench::main+0x12b0>
   48a12:	mov    (%rbx),%rdi
   48a15:	mov    $0x1,%edx
   48a1a:	call   *%r15
   48a1d:	jmp    48a00 <construction_bench::main+0x12b0>
   48a1f:	mov    0xc8(%rsp),%rax
   48a27:	test   %rax,%rax
   48a2a:	je     48a44 <construction_bench::main+0x12f4>
   48a2c:	shl    $0x3,%rax
   48a30:	lea    (%rax,%rax,2),%rsi
   48a34:	mov    $0x8,%edx
   48a39:	mov    0x28(%rsp),%rdi
   48a3e:	call   *0x5bcfc(%rip)        # a4740 <_DYNAMIC+0x240>
   48a44:	add    $0x6e8,%rsp
   48a4b:	pop    %rbx
   48a4c:	pop    %r12
   48a4e:	pop    %r13
   48a50:	pop    %r14
   48a52:	pop    %r15
   48a54:	pop    %rbp
   48a55:	ret
   48a56:	lea    -0x3e685(%rip),%rdi        # a3d8 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763>
   48a5d:	lea    0x585e4(%rip),%rdx        # a1048 <anon.2511809ce763e2139425809bcda7322c.35.llvm.4475126642733658763>
   48a64:	mov    $0x24,%esi
   48a69:	call   *0x5bd59(%rip)        # a47c8 <_DYNAMIC+0x2c8>
   48a6f:	jmp    48d33 <construction_bench::main+0x15e3>
   48a74:	movupd 0x300(%rsp),%xmm0
   48a7d:	movupd 0x310(%rsp),%xmm1
   48a86:	movapd %xmm1,0x120(%rsp)
   48a8f:	movapd %xmm0,0x110(%rsp)
   48a98:	lea    -0x3e167(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48a9f:	lea    0x58c02(%rip),%rcx        # a16a8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48aa6:	lea    0x58a8b(%rip),%r8        # a1538 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x150>
   48aad:	lea    0x110(%rsp),%rdx
   48ab5:	mov    $0x2b,%esi
   48aba:	call   *0x5bd10(%rip)        # a47d0 <_DYNAMIC+0x2d0>
   48ac0:	jmp    48d33 <construction_bench::main+0x15e3>
   48ac5:	lea    0x58a54(%rip),%r8        # a1520 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x138>
   48acc:	lea    0x58bf5(%rip),%rcx        # a16c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2e0>
   48ad3:	lea    0x300(%rsp),%rdx
   48adb:	jmp    48b11 <construction_bench::main+0x13c1>
   48add:	add    $0xd0,%dl
   48ae0:	xor    %eax,%eax
   48ae2:	cmp    $0xa,%dl
   48ae5:	adc    $0x1,%al
   48ae7:	jmp    48aeb <construction_bench::main+0x139b>
   48ae9:	mov    $0x2,%al
   48aeb:	mov    %al,0x110(%rsp)
   48af2:	lea    0x5897f(%rip),%r8        # a1478 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x90>
   48af9:	jmp    48b7e <construction_bench::main+0x142e>
   48afe:	lea    0x58a03(%rip),%r8        # a1508 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x120>
   48b05:	lea    0x58b7c(%rip),%rcx        # a1688 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2a0>
   48b0c:	lea    0x60(%rsp),%rdx
   48b11:	mov    0xe8(%rsp),%rax
   48b19:	mov    (%rax),%eax
   48b1b:	mov    0xe0(%rsp),%rsi
   48b23:	mov    (%rsi),%esi
   48b25:	mov    %eax,(%rdx)
   48b27:	mov    %esi,0x4(%rdx)
   48b2a:	lea    -0x3e1ce(%rip),%rdi        # a963 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x83>
   48b31:	mov    $0x2e,%esi
   48b36:	call   *0x5bc94(%rip)        # a47d0 <_DYNAMIC+0x2d0>
   48b3c:	jmp    48d33 <construction_bench::main+0x15e3>
   48b41:	mov    %r12,%rsi
   48b44:	lea    0x50(%rsp),%r12
   48b49:	lea    0x58a30(%rip),%r9        # a1580 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x198>
   48b50:	xor    %edi,%edi
   48b52:	mov    %r12,%rdx
   48b55:	xor    %ecx,%ecx
   48b57:	call   *0x5bf0b(%rip)        # a4a68 <_DYNAMIC+0x568>
   48b5d:	jmp    48d33 <construction_bench::main+0x15e3>
   48b62:	add    $0xd0,%dl
   48b65:	xor    %eax,%eax
   48b67:	cmp    $0xa,%dl
   48b6a:	adc    $0x1,%al
   48b6c:	jmp    48b70 <construction_bench::main+0x1420>
   48b6e:	mov    $0x2,%al
   48b70:	mov    %al,0x110(%rsp)
   48b77:	lea    0x588b2(%rip),%r8        # a1430 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x48>
   48b7e:	lea    -0x3e24d(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48b85:	lea    0x58b5c(%rip),%rcx        # a16e8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x300>
   48b8c:	mov    $0x2b,%esi
   48b91:	mov    %r12,%rdx
   48b94:	call   *0x5bc36(%rip)        # a47d0 <_DYNAMIC+0x2d0>
   48b9a:	jmp    48d33 <construction_bench::main+0x15e3>
   48b9f:	movupd 0x300(%rsp),%xmm0
   48ba8:	movupd 0x310(%rsp),%xmm1
   48bb1:	movapd %xmm1,0x120(%rsp)
   48bba:	movapd %xmm0,0x110(%rsp)
   48bc3:	lea    -0x3e292(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48bca:	lea    0x58ad7(%rip),%rcx        # a16a8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48bd1:	lea    0x589f0(%rip),%r8        # a15c8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1e0>
   48bd8:	lea    0x110(%rsp),%rdx
   48be0:	mov    $0x2b,%esi
   48be5:	call   *0x5bbe5(%rip)        # a47d0 <_DYNAMIC+0x2d0>
   48beb:	jmp    48d33 <construction_bench::main+0x15e3>
   48bf0:	movupd 0x300(%rsp),%xmm0
   48bf9:	movupd 0x310(%rsp),%xmm1
   48c02:	movapd %xmm1,0x120(%rsp)
   48c0b:	movapd %xmm0,0x110(%rsp)
   48c14:	lea    -0x3e2e3(%rip),%rdi        # a938 <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x58>
   48c1b:	lea    0x58a86(%rip),%rcx        # a16a8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x2c0>
   48c22:	lea    0x58867(%rip),%r8        # a1490 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xa8>
   48c29:	lea    0x110(%rsp),%rdx
   48c31:	mov    $0x2b,%esi
   48c36:	call   *0x5bb94(%rip)        # a47d0 <_DYNAMIC+0x2d0>
   48c3c:	jmp    48d33 <construction_bench::main+0x15e3>
   48c41:	lea    0x58860(%rip),%rdi        # a14a8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xc0>
   48c48:	call   *0x5bcb2(%rip)        # a4900 <_DYNAMIC+0x400>
   48c4e:	jmp    48d33 <construction_bench::main+0x15e3>
   48c53:	lea    0x588f6(%rip),%r9        # a1550 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x168>
   48c5a:	xor    %edi,%edi
   48c5c:	mov    0xc0(%rsp),%rsi
   48c64:	mov    %r12,%rdx
   48c67:	xor    %ecx,%ecx
   48c69:	call   *0x5bdf9(%rip)        # a4a68 <_DYNAMIC+0x568>
   48c6f:	jmp    48d33 <construction_bench::main+0x15e3>
   48c74:	lea    0x588ed(%rip),%r9        # a1568 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x180>
   48c7b:	lea    0x60(%rsp),%rsi
   48c80:	lea    0x110(%rsp),%rdx
   48c88:	xor    %edi,%edi
   48c8a:	xor    %ecx,%ecx
   48c8c:	call   44fbb <core::panicking::assert_failed::<ironweaver_core::graph::EdgeId, ironweaver_core::graph::EdgeId>>
   48c91:	jmp    48d33 <construction_bench::main+0x15e3>
   48c96:	lea    0x58913(%rip),%rcx        # a15b0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1c8>
   48c9d:	mov    %rdx,%rdi
   48ca0:	mov    %rsi,%rdx
   48ca3:	call   *0x5bcb7(%rip)        # a4960 <_DYNAMIC+0x460>
   48ca9:	jmp    48d33 <construction_bench::main+0x15e3>
   48cae:	lea    0x58823(%rip),%rdi        # a14d8 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0xf0>
   48cb5:	jmp    48c48 <construction_bench::main+0x14f8>
   48cb7:	mov    %r12,0xc0(%rsp)
   48cbf:	lea    -0x3e82e(%rip),%r12        # a498 <anon.2511809ce763e2139425809bcda7322c.34.llvm.4475126642733658763+0xc0>
   48cc6:	lea    0x588cb(%rip),%r9        # a1598 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1b0>
   48ccd:	jmp    48c5a <construction_bench::main+0x150a>
   48ccf:	lea    -0x3e3da(%rip),%rdi        # a8fc <anon.7665ee26ec2783d4bc19c81198c8490a.2.llvm.10560409517888769111+0x1c>
   48cd6:	lea    0x58903(%rip),%rdx        # a15e0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x1f8>
   48cdd:	mov    $0x3c,%esi
   48ce2:	call   *0x5bbf0(%rip)        # a48d8 <_DYNAMIC+0x3d8>
   48ce8:	jmp    48d33 <construction_bench::main+0x15e3>
   48cea:	mov    $0x1,%al
   48cec:	jmp    48aeb <construction_bench::main+0x139b>
   48cf1:	mov    $0x1,%al
   48cf3:	jmp    48b70 <construction_bench::main+0x1420>
   48cf8:	lea    0x587f1(%rip),%rdx        # a14f0 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x108>
   48cff:	xor    %edi,%edi
   48d01:	xor    %esi,%esi
   48d03:	call   *0x5bacf(%rip)        # a47d8 <_DYNAMIC+0x2d8>
   48d09:	jmp    48d33 <construction_bench::main+0x15e3>
   48d0b:	lea    0x58736(%rip),%rdx        # a1448 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x60>
   48d12:	mov    $0x1,%edi
   48d17:	jmp    48d25 <construction_bench::main+0x15d5>
   48d19:	lea    0x58740(%rip),%rdx        # a1460 <anon.5d09ad63f943746d04ae2dafc92c2e77.5.llvm.11945693191618023075+0x78>
   48d20:	mov    $0x2,%edi
   48d25:	mov    0xa8(%rsp),%rsi
   48d2d:	call   *0x5baa5(%rip)        # a47d8 <_DYNAMIC+0x2d8>
   48d33:	ud2
   48d35:	xor    %eax,%eax
   48d37:	jmp    48aeb <construction_bench::main+0x139b>
   48d3c:	xor    %eax,%eax
   48d3e:	jmp    48b70 <construction_bench::main+0x1420>
   48d43:	jmp    48e9a <construction_bench::main+0x174a>
   48d48:	mov    %rax,%r14
   48d4b:	lea    0x30(%rsp),%rdi
   48d50:	call   46de0 <core::ptr::drop_glue::<alloc::vec::Vec<(ironweaver_core::graph::Graph<(), ()>, alloc::vec::Vec<ironweaver_core::graph::NodeIx>)>>>
   48d55:	jmp    48ed0 <construction_bench::main+0x1780>
   48d5a:	jmp    48e1a <construction_bench::main+0x16ca>
   48d5f:	mov    %rax,%r14
   48d62:	lea    0x300(%rsp),%rdi
   48d6a:	call   414d0 <core::ptr::drop_glue::<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>>>>
   48d6f:	jmp    48ed0 <construction_bench::main+0x1780>
   48d74:	call   *0x5ba66(%rip)        # a47e0 <_DYNAMIC+0x2e0>
   48d7a:	jmp    48e9a <construction_bench::main+0x174a>
   48d7f:	mov    %rax,%r14
   48d82:	lea    0x300(%rsp),%rdi
   48d8a:	call   46ea0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48d8f:	jmp    48ed0 <construction_bench::main+0x1780>
   48d94:	call   *0x5ba46(%rip)        # a47e0 <_DYNAMIC+0x2e0>
   48d9a:	jmp    48e9a <construction_bench::main+0x174a>
   48d9f:	mov    %rax,%r14
   48da2:	jmp    48ed0 <construction_bench::main+0x1780>
   48da7:	jmp    48e9a <construction_bench::main+0x174a>
   48dac:	jmp    48e9a <construction_bench::main+0x174a>
   48db1:	mov    %rax,%r14
   48db4:	jmp    48ea0 <construction_bench::main+0x1750>
   48db9:	mov    %rax,%r14
   48dbc:	test   %r15,%r15
   48dbf:	je     48de4 <construction_bench::main+0x1694>
   48dc1:	add    $0x1d8,%rbp
   48dc8:	neg    %r15
   48dcb:	nopl   0x0(%rax,%rax,1)
   48dd0:	mov    %rbp,%rdi
   48dd3:	call   40600 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48dd8:	add    $0x1d8,%rbp
   48ddf:	dec    %r15
   48de2:	jne    48dd0 <construction_bench::main+0x1680>
   48de4:	mov    0x110(%rsp),%rax
   48dec:	test   %rax,%rax
   48def:	je     48ed0 <construction_bench::main+0x1780>
   48df5:	mov    0x118(%rsp),%rdi
   48dfd:	imul   $0x1d8,%rax,%rsi
   48e04:	mov    $0x8,%edx
   48e09:	call   *0x5b931(%rip)        # a4740 <_DYNAMIC+0x240>
   48e0f:	jmp    48ed0 <construction_bench::main+0x1780>
   48e14:	call   *0x5b9c6(%rip)        # a47e0 <_DYNAMIC+0x2e0>
   48e1a:	mov    %rax,%r14
   48e1d:	lea    0x4f0(%rsp),%rdi
   48e25:	call   46c50 <core::ptr::drop_glue::<alloc::vec::Vec<ironweaver_core::graph::Graph<(), ()>>>>
   48e2a:	jmp    48ed0 <construction_bench::main+0x1780>
   48e2f:	jmp    48e45 <construction_bench::main+0x16f5>
   48e31:	mov    %rax,%r14
   48e34:	lea    0x300(%rsp),%rdi
   48e3c:	call   46ea0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48e41:	jmp    48e9d <construction_bench::main+0x174d>
   48e43:	jmp    48e45 <construction_bench::main+0x16f5>
   48e45:	mov    %rax,%r14
   48e48:	mov    $0x1,%bpl
   48e4b:	mov    0x110(%rsp),%rax
   48e53:	cmp    $0xa,%rax
   48e57:	ja     48e64 <construction_bench::main+0x1714>
   48e59:	mov    $0x51c,%ecx
   48e5e:	bt     %rax,%rcx
   48e62:	jb     48ea0 <construction_bench::main+0x1750>
   48e64:	mov    0x118(%rsp),%rsi
   48e6c:	test   %rsi,%rsi
   48e6f:	je     48ea0 <construction_bench::main+0x1750>
   48e71:	mov    0x120(%rsp),%rdi
   48e79:	mov    $0x1,%edx
   48e7e:	call   *0x5b8bc(%rip)        # a4740 <_DYNAMIC+0x240>
   48e84:	jmp    48ea0 <construction_bench::main+0x1750>
   48e86:	jmp    48e9a <construction_bench::main+0x174a>
   48e88:	mov    %rax,%r14
   48e8b:	mov    0xd0(%rsp),%rax
   48e93:	mov    %rax,0x28(%rsp)
   48e98:	jmp    48ed0 <construction_bench::main+0x1780>
   48e9a:	mov    %rax,%r14
   48e9d:	mov    $0x1,%bpl
   48ea0:	mov    0x30(%rsp),%rsi
   48ea5:	test   %rsi,%rsi
   48ea8:	je     48ebe <construction_bench::main+0x176e>
   48eaa:	mov    0x38(%rsp),%rdi
   48eaf:	shl    $0x3,%rsi
   48eb3:	mov    $0x4,%edx
   48eb8:	call   *0x5b882(%rip)        # a4740 <_DYNAMIC+0x240>
   48ebe:	test   %bpl,%bpl
   48ec1:	je     48ed0 <construction_bench::main+0x1780>
   48ec3:	lea    0x4f0(%rsp),%rdi
   48ecb:	call   46ea0 <core::ptr::drop_glue::<ironweaver_core::graph::Graph<(), ()>>>
   48ed0:	mov    0xd8(%rsp),%rbx
   48ed8:	test   %rbx,%rbx
   48edb:	jne    48f0a <construction_bench::main+0x17ba>
   48edd:	mov    0xc8(%rsp),%rax
   48ee5:	test   %rax,%rax
   48ee8:	je     48f02 <construction_bench::main+0x17b2>
   48eea:	shl    $0x3,%rax
   48eee:	lea    (%rax,%rax,2),%rsi
   48ef2:	mov    $0x8,%edx
   48ef7:	mov    0x28(%rsp),%rdi
   48efc:	call   *0x5b83e(%rip)        # a4740 <_DYNAMIC+0x240>
   48f02:	mov    %r14,%rdi
   48f05:	call   9fe30 <_Unwind_Resume@plt>
   48f0a:	mov    0x28(%rsp),%rax
   48f0f:	lea    0x8(%rax),%r15
   48f13:	mov    0x5b826(%rip),%r12        # a4740 <_DYNAMIC+0x240>
   48f1a:	jmp    48f29 <construction_bench::main+0x17d9>
   48f1c:	nopl   0x0(%rax)
   48f20:	add    $0x18,%r15
   48f24:	dec    %rbx
   48f27:	je     48edd <construction_bench::main+0x178d>
   48f29:	mov    -0x8(%r15),%rsi
   48f2d:	test   %rsi,%rsi
   48f30:	je     48f20 <construction_bench::main+0x17d0>
   48f32:	mov    (%r15),%rdi
   48f35:	mov    $0x1,%edx
   48f3a:	call   *%r12
   48f3d:	jmp    48f20 <construction_bench::main+0x17d0>
   48f3f:	call   *0x5b89b(%rip)        # a47e0 <_DYNAMIC+0x2e0>
   48f45:	int3
   48f46:	int3
   48f47:	int3
   48f48:	int3
   48f49:	int3
   48f4a:	int3
   48f4b:	int3
   48f4c:	int3
   48f4d:	int3
   48f4e:	int3
   48f4f:	int3
