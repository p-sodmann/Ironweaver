import sys,json,statistics,subprocess,re,hashlib,zipfile
from pathlib import Path
sys.path.insert(0,'benchmarks')
from compare_construction import summarize
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('performance_results/codegen-2026-10-08');out.mkdir(exist_ok=True)
flags=json.loads(Path('work/codegen/flags.json').read_text()); results={}
for rev in ('baseline','candidate'):
 for flag in ('align64','cgu1'):
  before=flags['results']['frozen/batch=1']['raw'];after=flags['results'][flag+'/batch=1']['raw']
  results[f'{rev}/{flag}-vs-frozen']=summarize([dict(baseline=b[rev],candidate=a[rev]) for b,a in zip(before,after)])
asm={}
for rev in ('baseline','candidate'):
 for flag in ('align64','cgu1'):
  path=f'work/codegen/flags/{rev}/{flag}'
  s=subprocess.check_output(['objdump','-d','-C','--no-show-raw-insn',path],text=True)
  m=re.search(r'([0-9a-f]+) <construction_bench::main>:\n(.*?)(?=\n[0-9a-f]+ <)',s,re.S)
  lines=[]
  for line in m[2].splitlines():
   line=re.sub(r'^\s*[0-9a-f]+:\s*','',line);line=re.sub(r'\s+#.*','',line);line=re.sub(r'[0-9a-f]+ <','<',line);line=re.sub(r'-?0x[0-9a-f]+\(%rip\)','RIP_RELOC',line);line=re.sub(r'\.llvm\.\d+','LLVM_ID',line)
   if line:lines.append(line)
  norm='\n'.join(lines)+'\n';Path(f'work/codegen/{rev}-{flag}-normalized.asm').write_text(norm)
  asm[f'{rev}/{flag}']=dict(address=m[1],mod64=int(m[1],16)%64,instructions=len(lines),normalized_sha256=hashlib.sha256(norm.encode()).hexdigest())
(out/'absolute-flags.json').write_text(json.dumps(results,indent=2)+'\n');(out/'flag-assembly.json').write_text(json.dumps(asm,indent=2)+'\n')
print(json.dumps(results,indent=2));print(json.dumps(asm,indent=2))
confirm=json.loads(Path('work/codegen/flags-confirmation.json').read_text())
rows=[]
for name,d in [('Primary: 40 pairs',flags),('Independent repeat: 24 pairs',confirm)]:
 for flag in ('frozen','align64','cgu1'):rows.append((f'{name} / {flag}',d['results'][flag+'/batch=1']['summary']))
fig,ax=plt.subplots(figsize=(10,5))
for i,(label,r) in enumerate(rows):
 lo,hi=r['ci95'];certain=lo>0 or hi<0;c='#b33b32' if lo>0 else '#25844a' if hi<0 else '#777777'
 ax.errorbar(r['change'],i,xerr=[[r['change']-lo],[hi-r['change']]],fmt='o',color=c,mfc=c if certain else 'white',capsize=4)
 ax.text(17,i,f"{r['change']:+.2f}% [{lo:+.2f}, {hi:+.2f}]"+(' inconclusive' if not certain else ''),va='center',fontsize=9)
ax.set_yticks(range(len(rows)),[r[0] for r in rows]);ax.invert_yaxis();ax.axvline(0,color='black',lw=.8);ax.set_xlim(-10,43);ax.set_xlabel('Candidate / baseline elapsed time change (%) — pointwise 95% CI');ax.set_title('Rust neighbor traversal: matched compiler flag experiments\n1,000 nodes / 5,000 edges · CPU 0 · one thread · seven samples per process');fig.tight_layout();fig.savefig(out/'codegen-comparison.png',dpi=180);plt.close(fig)
with zipfile.ZipFile(out/'raw-codegen.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(Path('work/codegen').rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to('work/codegen')))
