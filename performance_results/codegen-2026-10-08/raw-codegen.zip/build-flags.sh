#!/usr/bin/env bash
set -euo pipefail
source work/env.sh
export CARGO_TARGET_DIR=/workspace/Ironweaver/target
for revision in baseline candidate; do
 variant=baseline-new
 [[ "$revision" == baseline ]] || variant=candidate
 cp "work/diagnosis/$variant.rs" work/diagnosis/source/crates/ironweaver-core/src/graph.rs
 find work/diagnosis/source/crates/ironweaver-core/src -name '*.rs' -exec touch {} +
 mkdir -p "work/codegen/flags/$revision"
 cp "work/artifacts/$revision/construction_bench" "work/codegen/flags/$revision/frozen"
 cargo rustc --manifest-path work/diagnosis/source/Cargo.toml --release --locked -p ironweaver-core --example construction_bench -- -C llvm-args=-align-all-functions=6
 cp target/release/examples/construction_bench "work/codegen/flags/$revision/align64"
 cargo rustc --manifest-path work/diagnosis/source/Cargo.toml --release --locked -p ironweaver-core --example construction_bench -- -C codegen-units=1
 cp target/release/examples/construction_bench "work/codegen/flags/$revision/cgu1"
done
