| Hub degree / other degree / position / metric | Before (ms) | After (ms) | Change [95% CI] |
|---|---:|---:|---:|
| 128/1/suffix/common_neighbors | 0.141 | 0.034 | -75.9% [-77.2, -74.6] |
| 128/1/suffix/jaccard | 0.150 | 0.034 | -77.2% [-80.1, -73.9] |
| 128/1/suffix/adamic_adar | 0.153 | 0.039 | -74.1% [-77.5, -70.2] |
| 4096/8/spread/common_neighbors | 3.892 | 0.434 | -88.8% [-89.4, -88.2] |
| 4096/8/spread/jaccard | 4.067 | 0.432 | -89.4% [-90.1, -88.6] |
| 4096/8/spread/adamic_adar | 3.804 | 0.442 | -88.4% [-89.2, -87.5] |
| 32768/8/spread/common_neighbors | 30.163 | 1.966 | -93.5% [-93.9, -93.1] |
| 32768/8/spread/jaccard | 31.996 | 1.896 | -94.1% [-94.5, -93.7] |
| 32768/8/spread/adamic_adar | 28.857 | 1.903 | -93.4% [-93.7, -93.1] |
| 4096/8/prefix/common_neighbors | 0.222 | 0.249 | +12.5% [+9.3, +15.8] |
| 4096/8/prefix/jaccard | 0.220 | 0.246 | +11.8% [+9.6, +14.0] |
| 4096/8/prefix/adamic_adar | 0.288 | 0.283 | -1.6% [-15.2, +14.2] |
| 4096/8/disjoint/common_neighbors | 3.817 | 0.429 | -88.8% [-89.7, -87.8] |
| 4096/8/disjoint/jaccard | 3.716 | 0.422 | -88.6% [-89.2, -88.1] |
| 4096/8/disjoint/adamic_adar | 3.668 | 0.425 | -88.4% [-88.9, -87.9] |
| 4096/128/spread/common_neighbors | 3.939 | 2.580 | -34.5% [-38.3, -30.5] |
| 4096/128/spread/jaccard | 4.037 | 2.657 | -34.2% [-42.2, -25.1] |
| 4096/128/spread/adamic_adar | 4.935 | 2.629 | -46.8% [-50.6, -42.7] |
| 128/128/spread/common_neighbors | 0.165 | 0.161 | -2.6% [-10.8, +6.4] |
| 128/128/spread/jaccard | 0.164 | 0.168 | +2.1% [-6.4, +11.4] |
| 128/128/spread/adamic_adar | 0.926 | 0.902 | -2.5% [-10.5, +6.2] |
| 4096/4096/spread/common_neighbors | 4.918 | 4.735 | -3.9% [-15.4, +9.3] |
| 4096/4096/spread/jaccard | 4.941 | 4.798 | -2.6% [-11.1, +6.7] |
| 4096/4096/spread/adamic_adar | 28.766 | 29.288 | +1.6% [-7.4, +11.5] |
