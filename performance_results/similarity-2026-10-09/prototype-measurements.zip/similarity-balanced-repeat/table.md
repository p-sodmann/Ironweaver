| Hub degree / other degree / position / metric | Before (ms) | After (ms) | Change [95% CI] |
|---|---:|---:|---:|
| 4096/4096/spread/common_neighbors | 4.793 | 5.475 | +14.3% [+5.4, +24.0] |
| 4096/4096/spread/jaccard | 4.620 | 5.552 | +20.2% [+11.9, +29.2] |
| 4096/4096/spread/adamic_adar | 27.739 | 28.801 | +3.8% [+0.9, +6.7] |
