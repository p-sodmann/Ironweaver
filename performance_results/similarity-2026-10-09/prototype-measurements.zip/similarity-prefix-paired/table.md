| Hub degree / other degree / position / metric | Before (ms) | After (ms) | Change [95% CI] |
|---|---:|---:|---:|
| 128/1/suffix/common_neighbors | 0.136 | 0.033 | -75.9% [-78.1, -73.6] |
| 128/1/suffix/jaccard | 0.135 | 0.035 | -74.1% [-77.0, -70.7] |
| 128/1/suffix/adamic_adar | 0.146 | 0.038 | -74.0% [-78.2, -69.0] |
| 4096/8/spread/common_neighbors | 3.679 | 0.422 | -88.5% [-89.3, -87.7] |
| 4096/8/spread/jaccard | 3.955 | 0.432 | -89.1% [-90.5, -87.5] |
| 4096/8/spread/adamic_adar | 3.696 | 0.444 | -88.0% [-89.3, -86.5] |
| 32768/8/spread/common_neighbors | 28.442 | 2.015 | -92.9% [-93.8, -91.9] |
| 32768/8/spread/jaccard | 31.290 | 1.881 | -94.0% [-94.8, -93.0] |
| 32768/8/spread/adamic_adar | 29.177 | 1.846 | -93.7% [-94.3, -93.0] |
| 4096/8/prefix/common_neighbors | 0.216 | 0.216 | -0.2% [-2.8, +2.6] |
| 4096/8/prefix/jaccard | 0.222 | 0.216 | -3.0% [-6.9, +1.1] |
| 4096/8/prefix/adamic_adar | 0.271 | 0.258 | -4.3% [-12.4, +4.6] |
| 4096/8/disjoint/common_neighbors | 3.727 | 0.425 | -88.6% [-89.9, -87.0] |
| 4096/8/disjoint/jaccard | 3.732 | 0.411 | -88.9% [-90.1, -87.6] |
| 4096/8/disjoint/adamic_adar | 3.616 | 0.416 | -88.5% [-88.7, -88.2] |
| 4096/128/spread/common_neighbors | 3.894 | 3.880 | -0.3% [-5.6, +5.3] |
| 4096/128/spread/jaccard | 3.776 | 3.922 | +3.8% [-1.8, +9.8] |
| 4096/128/spread/adamic_adar | 4.917 | 4.648 | -5.2% [-12.7, +3.0] |
| 128/128/spread/common_neighbors | 0.169 | 0.185 | +10.1% [-2.1, +23.9] |
| 128/128/spread/jaccard | 0.172 | 0.186 | +8.9% [-5.4, +25.2] |
| 128/128/spread/adamic_adar | 0.916 | 0.884 | -3.3% [-12.3, +6.7] |
| 4096/4096/spread/common_neighbors | 4.694 | 5.295 | +12.9% [+6.6, +19.5] |
| 4096/4096/spread/jaccard | 4.737 | 5.763 | +20.4% [+2.0, +42.0] |
| 4096/4096/spread/adamic_adar | 27.662 | 27.433 | -0.8% [-8.2, +7.2] |
