export CARGO_HOME=/workspace/.ironweaver-tools/cargo
export RUSTUP_HOME=/workspace/.ironweaver-tools/rustup
export PATH=/workspace/.ironweaver-tools/cargo/bin:/workspace/.ironweaver-venv/bin:$PATH
export CARGO_BUILD_JOBS=2
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONHASHSEED=42
export UV_CACHE_DIR=/workspace/.ironweaver-tools/uv-cache
