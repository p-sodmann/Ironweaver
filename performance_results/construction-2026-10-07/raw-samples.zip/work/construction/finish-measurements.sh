#!/usr/bin/env bash
set -euo pipefail
cd /workspace/Ironweaver
source work/env.sh
export MPLCONFIGDIR=/workspace/Ironweaver/work/matplotlib
ANALYSIS_PYTHON=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python
python -c 'import json; assert json.load(open("work/raw/broad-status.json"))["phase"] == "complete"'
echo focused-bindings
python benchmarks/compare_edgeless_bindings.py work/artifacts/baseline work/artifacts/candidate --pairs 10 --output work/raw/binding-focus.json
"$ANALYSIS_PYTHON" benchmarks/analyze_construction_performance.py --raw work/raw --out work/report --no-plots
echo independent-regression-confirmation
python benchmarks/repeat_construction_regressions.py --summary work/report/summary.json --pairs 12
"$ANALYSIS_PYTHON" benchmarks/analyze_construction_performance.py --raw work/raw --out work/report
"$ANALYSIS_PYTHON" work/construction/write-report.py
echo complete
