from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path.cwd();report=root/'work/report'
paths=[]
for name in ('work/raw','work/data','work/artifacts/baseline','work/artifacts/candidate'):
 paths.extend(p for p in (root/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='.lock')
for pattern in ('*.log','*.json','*.sh','*.txt','*.csv','*.py','*.patch'):
 paths.extend((root/'work/construction').glob(pattern))
paths.extend(p for p in (root/'work/construction/rejected-dense-final').rglob('*') if p.is_file())
for revision in ('baseline','candidate'):
 source=root/'work/artifacts'/('source-'+revision)
 for name in ('Cargo.lock','Cargo.toml','pyproject.toml'):
  paths.append(source/name)
 for folder in ('src','python','crates/ironweaver-core'):
  paths.extend(p for p in (source/folder).rglob('*') if p.is_file())
paths.extend(p for p in (root/'benchmarks').glob('*') if p.is_file())
paths.append(root/'work/env.sh')
paths=sorted(set(p for p in paths if p.is_file()))
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(report/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(report/'raw-samples.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in paths:z.write(p,p.relative_to(root))
 z.write(report/'archive-manifest.json','archive-manifest.json')
repo=root/'performance_results/construction-2026-10-07';repo.mkdir(parents=True,exist_ok=True)
out=Path('/codex/browser/projectless/0003-continue-performance-optimization-in-p-sodmann-i/output');out.mkdir(parents=True,exist_ok=True)
for name in ('README.md','focused-comparison.png','suite-regression-overview.png','summary.csv','summary.json','raw-samples.zip','archive-manifest.json'):
 for dest in (repo,out):shutil.copy2(report/name,dest/name)
print('packaged',len(paths),'files;',round((report/'raw-samples.zip').stat().st_size/2**20,2),'MiB')
