import sys,pickle,json,hashlib
from pathlib import Path
sys.path.insert(0,'benchmarks')
import compare_libraries as b
root=Path('work/data'); root.mkdir(exist_ok=True)
manifest={}
for key, make in b.DATASETS.items():
 path=root/(key+'.pickle')
 if not path.exists():
  ds=make()
  with path.open('wb') as f: pickle.dump(ds,f,protocol=pickle.HIGHEST_PROTOCOL)
 else:
  with path.open('rb') as f: ds=pickle.load(f)
 manifest[key]=dict(nodes=ds.n,edges=len(ds.edges),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),edges_sha256=hashlib.sha256(repr(ds.edges).encode()).hexdigest())
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(manifest)
