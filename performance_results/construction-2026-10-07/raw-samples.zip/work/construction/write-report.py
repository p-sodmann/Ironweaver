from pathlib import Path
import json,statistics

root=Path('work/report')
rows=json.loads((root/'summary.json').read_text())
lookup={(r['suite'],r['name']):r for r in rows}
manifest=json.loads(Path('work/construction/manifest.json').read_text())
threads=json.loads(Path('work/raw/threads.json').read_text())
def ci(r): return f"{r['change']:+.1f}% [{r['ci_low']:+.1f}, {r['ci_high']:+.1f}]"
def selected(r): return r.get('repeat',r)
def time(v):
 if v<.001: return f'{v*1e6:.4g} µs'
 return f'{v*1000:.4g} ms'
counts=', '.join(f'{suite}={sum(r["suite"]==suite for r in rows)}' for suite in dict.fromkeys(r['suite'] for r in rows))
text=['# Edgeless subgraph creation: measured performance report','',
'An induced subgraph with no edges now retains the source edge-ID counter without allocating its dense edge-ID table. This avoids allocation and zeroing proportional to the source ID range. The supporting lookup/removal fix keeps sparse IDs accessible when the dense prefix grows over them. Bindings, dependencies and advanced algorithm implementations are unchanged.','',
'**Draft; not ready to merge.** Independent confirmation establishes neighbor iteration and deletion regressions. The edgeless-copy gain is narrow, and ordinary creation/traversal controls remain largely inconclusive.','',
f"Baseline `{manifest['baseline_ref']}`; frozen candidate `{manifest['candidate_ref']}`. All final measurements use these frozen artifacts on this machine. Earlier trials are exploratory evidence, never substituted for final results.",'',
'## Focused before / after','',
'Times are medians of independent process summaries (inner medians, or the existing traversal batch average). Percent changes and 95% CIs use paired log ratios; negative means faster. These different summaries need not produce identical arithmetic ratios. Core subgraph timings include destruction of the copied result; source setup and destruction are excluded. Focused Python timings batch 128 unchanged-binding calls and include output destruction/loop overhead, with source setup excluded.','',
'| Workload | Before → after | Paired change [95% CI] | Result |','|---|---:|---:|---|']
keys=[('construction',f'subgraph-small/{n}/threads=1') for n in (1000,20000,100000)]
keys += [('python-focus',f'filter-3-isolated/{n}') for n in (1000,20000,100000)]
keys += [('construction','subgraph/20000/threads=1'),('construction','random/20000/threads=1'),('networkx','networkx/20000/100000/Build graph'),('networkx','networkx/20000/100000/BFS (full)'),('networkx','networkx/20000/100000/DFS traversal')]
for k in keys:
 r=lookup[k];s=selected(r)
 text.append(f"| {r['name']} | {time(s['before'])} → {time(s['after'])} | {ci(s)} | {s['status']} (n={s['pairs']}) |")
text += ['', 'The established gains apply to the measured edgeless-copy fixtures. Full copies, direct node/edge insertion and Python traversals have their own controls and intervals; these narrow core gains do not establish a universal or end-to-end speedup.','',
'## Concurrency','',
'One/two-thread runs alternate within 12 independent process pairs using the frozen candidate. Four independent Rust graphs are prepared outside timing; timed work is edge insertion and Rayon scheduling/result collection. Node setup and graph destruction are excluded. This measures independent-graph edge construction, not shared mutable graphs or Python thread scaling.','',
'| Nodes per graph | One → two threads | Paired change [95% CI] | Result |','|---|---:|---:|---|']
for r in threads['raw']:
 s=r['summary'];lo,hi=s['ci95'];state='improved' if hi<0 else 'regression' if lo>0 else 'inconclusive'
 text.append(f"| {r['n']:,} | {time(s['before'])} → {time(s['after'])} | {s['change']:+.1f}% [{lo:+.1f}, {hi:+.1f}] | {state} |")
text += ['', 'The unchanged CPython 3.12 bindings acquire the GIL for construction and mutate a graph through exclusive access. No automatic parallel mutation was introduced. Independent pure-Rust graphs can use separate workers; the figures above describe only this measured control.','',
'## Complete suite and independent regression checks','',
f"All {len(rows)} applicable revision workloads were measured: {counts}. Thread scaling adds three controls. All retained raw samples, including unfavorable and inconclusive runs, remain available.",
'Primary sampling: ten construction pairs (seven inner samples, two warmups); six core traversal pairs (one warmup, existing ≥100 ms/minimum-three-call batches); six deletion pairs (three samples, three warmups, existing batch sizes); ten focused Python binding pairs (seven batches of 128 calls, two warmups); six broad-suite pairs (three samples plus one warmup). Facebook exact betweenness retains one timed call/process and no added warmup. Existing directed-only restrictions and the nodes×edges budget are retained, with exclusions recorded in the suite JSON.','',
'Every primary interval wholly above zero is an independent-repeat signal, regardless of its size. Signals receive 12 new process pairs with matching artifacts, affinity, threads, inputs, timed operations, warmups and inner sample counts. Targeted general-operation repeats execute untimed references and other required operations once; selected operations retain the original timing protocol. Library repeats retain fresh/reused result checks and selected operations; memory repeats retain fresh-process workers and peak resets. Nonselected setup/context differs from the complete screen and is explicitly separate. The core traversal confirmation repeats the entire fixture process to retain its setup context. No primary/repeat observations are pooled.','']
suspects=[r for r in rows if r['status']=='regression']
if suspects:
 text += ['The PR remains a draft. Primary signals are retained explicitly; a repeat interval crossing zero does not establish equivalence or prove the earlier observation resolved.','',
'| Workload | Primary change [95% CI] | Independent repeat [95% CI] | Outcome |','|---|---:|---:|---|']
 for r in suspects:
  rep=r.get('repeat');outcome='confirmed regression' if rep and rep['status']=='regression' else 'unconfirmed / unresolved signal'
  text.append(f"| {r['name']} | {ci(r)} | {ci(rep) if rep else 'MISSING'} | {outcome} |")
extra=[r for r in rows if r['status']!='regression' and r.get('repeat',{}).get('status')=='regression']
if extra:
 text += ['', 'Additional slowdown intervals appeared in the independently repeated full traversal context. They remain unresolved and are not dismissed because they were absent from the first screen:', '', '| Workload | Primary change [95% CI] | Independent repeat [95% CI] |', '|---|---:|---:|']
 for r in extra: text.append(f"| {r['name']} | {ci(r)} | {ci(r['repeat'])} |")
if not suspects:
 text += ['No primary pointwise interval established a slowdown. Inconclusive intervals still allow losses; this is not proof of equivalence or a universal absence of regressions. The PR is a draft for review.']
text += ['', '## Side effects and correctness','',
'- An edgeless result avoids approximately `4 × source.next_edge_id` retained bytes when the prior dense reservation applied: 20,000 / 400,000 / 2,000,000 bytes in the three focused source sizes. No extra remapping array or worker pool is added to production code.','- Nonempty subgraphs still use the existing source-sized reservation; optimizing those is outside this frozen implementation. Empty dense cells now consult the sparse edge-ID index, which can add lookup work; all insertion/deletion controls are included above and in the complete CSV.','- The correctness test covers retained labels/counter, subsequent generated and explicit IDs, duplicate detection, a sparse ID covered by dense growth, removal, heap counters and an unchanged source graph.','- Final correctness: 834 Python tests, 160 Rust tests and 6 doctests passed. Formatting, Clippy for the workspace/all targets with warnings denied, and the no-PyO3 core dependency check passed. Original NetworkX benchmark assertions and applicable fresh/reused-library checks completed.','- Confidence intervals are nominal, pointwise 95% Student-t intervals on independent paired log ratios; inner repetitions are not independent observations. The memory plot uses paired absolute-difference intervals. Screening many workloads requires confirmation and does not provide simultaneous confidence guarantees. Shared-VM variation and artifact/code-layout effects remain possible; unrelated algorithm fluctuations are not claimed as implementation gains.','',
'## Protocol and provenance','',
f"- Rust 1.99.0; Python {manifest['python']}; Intel Xeon Platinum 8573C; Linux x86-64. CPU quota `{manifest['quota']}` (two CPU equivalents). Sequential controls use CPU 0 / one thread; broad and two-thread controls use CPUs 0–1 / two threads. Each revision has matching affinity and thread counts within each comparison.",
'- Standard release builds, copied Cargo.lock, same Python interpreter/dependencies and empty RUSTFLAGS. BLAS/OpenMP one thread; Python hash seed 42. Workers, builds and tests run serially under an exclusive benchmark lock. Linux memory workers reset only their own peak-RSS counters through `/proc/self/clear_refs` with the required execution access.',
f"- Lockfile SHA-256: `{manifest['baseline']['cargo_lock_sha256']}`.",
f"- Unchanged binding-source SHA-256: `{manifest['baseline']['bindings_sha256']}`.",
f"- Candidate graph.rs SHA-256: `{manifest['candidate']['graph_sha256']}`.",
'- Final extensions and core binaries were frozen and hashed before measurements. A shared-target stale extension was detected before timing and rebuilt; archive source timestamps are now refreshed by the builder. Final manifests and each broad worker record extension hashes and runtime identity.',
'- Existing environment/toolchain/dependency caches and benchmark harnesses were reused. Ignored prior frozen binaries/data were absent in this environment, so artifacts were built and datasets frozen once. Previous reports informed rejection of the node-ID entry experiment; historical timings are not final baselines.',
'- Endpoint-lookup and dense-remap candidates were rejected. Completed exploratory/dense trial samples are preserved separately. The interrupted final-size thread control of the rejected dense candidate lacked a complete checkpoint and is excluded; no incomplete trial is used for a final estimate. An initial broad-suite launcher ended before saving a complete paired estimate; its log is retained and excluded. The persistent controller saves each completed worker and pair. Final estimates use only completed independent pairs.',
'', '## Deliverables','',
'[Focused PNG](focused-comparison.png) · [Full-suite PNG](suite-regression-overview.png) · [All primary/repeat CIs](summary.csv) · [Raw samples, frozen artifacts/data and logs](raw-samples.zip)','',
'![Focused before/after comparison](focused-comparison.png)','',
'![Complete regression overview](suite-regression-overview.png)','',
'Gray/hollow marks inconclusive or exactly unchanged results. A dagger shows an independent repeat; both observations remain in the CSV. Primary signals prompted the complete traversal-context confirmation.']
(root/'README.md').write_text('\n'.join(text)+'\n')
