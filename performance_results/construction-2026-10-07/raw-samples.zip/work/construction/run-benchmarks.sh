set -euo pipefail
source work/env.sh
export RAYON_NUM_THREADS=2
mkdir -p work/raw
python benchmarks/compare_construction.py work/artifacts/baseline/construction_bench work/artifacts/candidate/construction_bench --pairs 10 --samples 7 --output work/raw/construction.json > work/raw/construction.log 2>&1
python benchmarks/compare_construction.py work/artifacts/baseline/construction_bench work/artifacts/candidate/construction_bench --pairs 10 --samples 7 --sizes 100000 --cases subgraph,subgraph-small --output work/raw/construction-large.json > work/raw/construction-large.log 2>&1
python benchmarks/compare_construction_threads.py work/artifacts/candidate/construction_bench --pairs 12 --output work/raw/threads.json > work/raw/threads.log 2>&1
python benchmarks/compare_traversal_revisions.py work/artifacts/baseline/traversal_bench work/artifacts/candidate/traversal_bench --pairs 6 --output work/raw/traversal.json > work/raw/traversal.log 2>&1
python benchmarks/compare_remove_node.py work/artifacts/baseline/bench_remove_node work/artifacts/candidate/bench_remove_node --pairs 6 --samples 3 --output work/raw/deletion.json > work/raw/deletion.log 2>&1
taskset -c 0,1 python benchmarks/compare_revisions.py work/artifacts/baseline work/artifacts/candidate --serial --data work/data --pairs 6 --repeats 3 --reference-cache work/reference-cache --output work/raw/suite.json > work/raw/suite.log 2>&1
python benchmarks/compare_edgeless_bindings.py work/artifacts/baseline work/artifacts/candidate --pairs 10 --output work/raw/binding-focus.json > work/raw/binding-focus.log 2>&1
