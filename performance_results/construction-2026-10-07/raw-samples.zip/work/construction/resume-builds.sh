set -euo pipefail
source work/env.sh
export CARGO_TARGET_DIR=/workspace/Ironweaver/target
artifact_root=/workspace/Ironweaver/work/artifacts
uv pip install --python "$(command -v python)" --no-deps --target "$artifact_root/baseline" "$artifact_root/wheels-baseline/"*.whl
for example in bench_remove_node traversal_bench construction_bench; do
 cp "$CARGO_TARGET_DIR/release/examples/$example" "$artifact_root/baseline/$example"
done
mkdir "$artifact_root/source-candidate" "$artifact_root/candidate" "$artifact_root/wheels-candidate"
git archive 61ded55 | tar -x -C "$artifact_root/source-candidate"
cp Cargo.lock "$artifact_root/source-candidate/Cargo.lock"
(
 cd "$artifact_root/source-candidate"
 maturin build --release --locked --interpreter "$(command -v python)" --out "$artifact_root/wheels-candidate"
 cargo build --release --locked -p ironweaver-core --examples
)
uv pip install --python "$(command -v python)" --no-deps --target "$artifact_root/candidate" "$artifact_root/wheels-candidate/"*.whl
for example in bench_remove_node traversal_bench construction_bench; do
 cp "$CARGO_TARGET_DIR/release/examples/$example" "$artifact_root/candidate/$example"
done
python - "$artifact_root" <<'PY'
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1])
for revision in ('baseline','candidate'):
 source=root/f'source-{revision}'
 metadata=dict(rustc=subprocess.check_output(['rustc','-Vv'],text=True),cargo_lock_sha256=hashlib.sha256((source/'Cargo.lock').read_bytes()).hexdigest(),flags=['maturin build --release --locked','cargo build --release --locked'],rustflags=os.environ.get('RUSTFLAGS',''),bindings_sha256=hashlib.sha256(b''.join(p.read_bytes() for directory in ('src','python') for p in sorted((source/directory).rglob('*')) if p.is_file())).hexdigest(),core_sha256=hashlib.sha256(b''.join(p.read_bytes() for p in sorted((source/'crates/ironweaver-core/src').rglob('*.rs')))).hexdigest(),graph_sha256=hashlib.sha256((source/'crates/ironweaver-core/src/graph.rs').read_bytes()).hexdigest())
 (root/revision/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
PY
