set -euo pipefail
source work/env.sh
export CARGO_TARGET_DIR=/workspace/Ironweaver/target
for revision in baseline candidate; do
 python - "$revision" <<'PY'
from pathlib import Path
import sys
for p in (Path('work/artifacts')/('source-'+sys.argv[1])).rglob('*.rs'): p.touch()
PY
 if [[ "$revision" == baseline ]]; then
  (cd work/artifacts/source-baseline; cargo build --release --locked -p ironweaver-core --example construction_bench)
  cp target/release/examples/construction_bench work/artifacts/baseline/construction_bench
 else
  (cd work/artifacts/source-candidate; maturin build --release --locked --interpreter /workspace/.ironweaver-venv/bin/python --out ../wheels-candidate; cargo build --release --locked -p ironweaver-core --examples)
  uv pip install --python /workspace/.ironweaver-venv/bin/python --no-deps --target work/artifacts/candidate work/artifacts/wheels-candidate/*.whl
  for example in construction_bench traversal_bench bench_remove_node; do cp "target/release/examples/$example" "work/artifacts/candidate/$example"; done
 fi
done
python - <<'PY'
from pathlib import Path
import json,hashlib
root=Path('work/artifacts')
metadata=json.loads((root/'baseline/build.json').read_text())
source=root/'source-candidate'
metadata['core_sha256']=hashlib.sha256(b''.join(p.read_bytes() for p in sorted((source/'crates/ironweaver-core/src').rglob('*.rs')))).hexdigest()
metadata['graph_sha256']=hashlib.sha256((source/'crates/ironweaver-core/src/graph.rs').read_bytes()).hexdigest()
(root/'candidate/build.json').write_text(json.dumps(metadata,indent=2)+'\n')
PY
python benchmarks/compare_construction.py work/artifacts/baseline/construction_bench work/artifacts/candidate/construction_bench --pairs 6 --sizes 1000,20000 --cases subgraph,subgraph-small --output work/construction/screen-empty.json
