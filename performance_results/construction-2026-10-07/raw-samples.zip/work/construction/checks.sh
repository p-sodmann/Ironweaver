set -euo pipefail
source work/env.sh
cargo fmt --all --check > work/construction/fmt.log 2>&1
cargo clippy --locked --workspace --all-targets -- -D warnings > work/construction/clippy.log 2>&1
cargo tree --locked -p ironweaver-core -e normal > work/construction/core-dependencies.txt
if rg -q pyo3 work/construction/core-dependencies.txt; then exit 1; fi
PYTHONPATH=/workspace/Ironweaver/work/artifacts/candidate python -c 'import ironweaver; print(ironweaver.__file__); assert "/artifacts/candidate/" in ironweaver.__file__' > work/construction/python-package.log
PYTHONPATH=/workspace/Ironweaver/work/artifacts/candidate python -m pytest > work/construction/python-tests.log 2>&1
python work/construction/prepare-data.py > work/construction/data.log
python - <<'PY'
from pathlib import Path
import json,hashlib,os,platform,subprocess,importlib.metadata
root=Path('work/artifacts')
metadata={revision:json.loads((root/revision/'build.json').read_text()) for revision in ('baseline','candidate')}
for key in ('rustc','cargo_lock_sha256','flags','rustflags','bindings_sha256'):
 assert metadata['baseline'][key]==metadata['candidate'][key],key
assert metadata['baseline']['graph_sha256']!=metadata['candidate']['graph_sha256']
for revision in ('baseline','candidate'):
 metadata[revision]['binaries']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/revision).glob('*') if p.is_file() and p.name!='build.json'}
 metadata[revision]['extension_sha256']=hashlib.sha256(next((root/revision/'ironweaver').glob('*.so')).read_bytes()).hexdigest()
assert metadata['baseline']['extension_sha256']!=metadata['candidate']['extension_sha256']
assert metadata['candidate']['graph_sha256']==hashlib.sha256(Path('crates/ironweaver-core/src/graph.rs').read_bytes()).hexdigest()
metadata.update(baseline_ref='c69ef5146c5865f2fd160a2df0a13b968d0255a3',candidate_ref=Path('work/construction/final-candidate-ref.txt').read_text().strip(),platform=platform.platform(),python=platform.python_version(),boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),cpuinfo=Path('/proc/cpuinfo').read_text(),quota=Path('/sys/fs/cgroup/cpu.max').read_text().strip(),dependencies={p:importlib.metadata.version(p) for p in ('networkx','numpy','scipy','psutil','maturin')})
Path('work/construction/manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Build provenance matched; peak-RSS reset was independently verified with the required execution access.')
PY
