"""Benchmark ironweaver against networkx and write a Markdown comparison report.

Both libraries get the same random directed graph (same node ids, edges and
edge attributes) and run equivalent operations. Every operation is timed as
the best of several repeats, and the results of both libraries are checked
against each other so the timings compare like with like.

Usage::

    python benchmarks/compare_networkx.py
    python benchmarks/compare_networkx.py --sizes 1000:5000,50000:250000 --repeats 5
    python benchmarks/compare_networkx.py --output performance_results/networkx_comparison.md

Requires ``networkx`` in addition to the built ``ironweaver`` module.
"""

from __future__ import annotations

import argparse
import datetime
import gc
import json
import os
import platform
import random
from itertools import islice
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import networkx as nx

from ironweaver import Vertex

DEFAULT_OUTPUT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "performance_results",
    "networkx_comparison.md",
)
EDGE_TYPES = ("knows", "likes", "follows")

# Name of the edge list in node-link JSON: `edges=` since networkx 3.4,
# `link=` before (3.2 is the last release for Python 3.9)
try:
    nx.node_link_data(nx.Graph(), edges="edges")
    NODE_LINK = {"edges": "edges"}
except TypeError:
    NODE_LINK = {"link": "edges"}


@dataclass
class Result:
    name: str
    description: str
    ironweaver_s: float | None
    networkx_s: float | None
    note: str = ""


@dataclass
class SizeReport:
    nodes: int
    edges: int
    results: list[Result] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def best_of(fn: Callable[[], Any], repeats: int, setup: Callable[[], Any] | None = None) -> tuple[float, Any]:
    """Return (best wall time in seconds, result of the last run).

    If *setup* is given, it runs untimed before every repeat and its return
    value is passed to *fn*.
    """
    best = float("inf")
    result = None
    for _ in range(repeats):
        arg = setup() if setup is not None else None
        gc.collect()
        start = time.perf_counter()
        result = fn(arg) if setup is not None else fn()
        best = min(best, time.perf_counter() - start)
    return best, result


def make_edges(n_nodes: int, n_edges: int, seed: int) -> list[tuple[str, str, dict]]:
    rng = random.Random(seed)
    edges = []
    for _ in range(n_edges):
        u = f"n{rng.randrange(n_nodes)}"
        v = f"n{rng.randrange(n_nodes)}"
        edges.append((u, v, {"type": rng.choice(EDGE_TYPES), "weight": round(rng.uniform(0.1, 10.0), 3)}))
    # A backbone chain keeps the graph (mostly) reachable from n0 so the
    # traversal and path benchmarks do real work.
    for i in range(n_nodes - 1):
        edges.append((f"n{i}", f"n{i + 1}", {"type": "next", "weight": 5.0}))
    return edges


def build_ironweaver(n_nodes: int, edges) -> Vertex:
    g = Vertex()
    for i in range(n_nodes):
        g.add_node(f"n{i}", {"index": i, "group": i % 10})
    for u, v, attr in edges:
        g.add_edge(u, v, dict(attr))
    return g


def build_networkx(n_nodes: int, edges) -> nx.MultiDiGraph:
    # MultiDiGraph: ironweaver keeps parallel edges, so networkx must too.
    g = nx.MultiDiGraph()
    for i in range(n_nodes):
        g.add_node(f"n{i}", index=i, group=i % 10)
    for u, v, attr in edges:
        g.add_edge(u, v, **attr)
    return g


def build_grid(side: int, seed: int):
    """side x side grid with edges both ways between neighbours, `x`/`y` node
    attributes and weights of 1-1.1x the Euclidean distance, like roads that
    are a bit longer than the straight line (so the Euclidean heuristic is
    admissible). Returns (ironweaver, networkx)."""
    rng = random.Random(seed)
    iw, g = Vertex(), nx.MultiDiGraph()
    for x in range(side):
        for y in range(side):
            iw.add_node(f"{x},{y}", {"x": x, "y": y})
            g.add_node(f"{x},{y}", x=x, y=y)
    for x in range(side):
        for y in range(side):
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                if 0 <= x + dx < side and 0 <= y + dy < side:
                    w = round(rng.uniform(1.0, 1.1), 3)
                    iw.add_edge(f"{x},{y}", f"{x + dx},{y + dy}", {"weight": w})
                    g.add_edge(f"{x},{y}", f"{x + dx},{y + dy}", weight=w)
    return iw, g


def nx_multi_source_within(g: nx.MultiDiGraph, seeds: list[str], depth: int) -> set[str]:
    """Nodes within *depth* hops of any seed (multi-source BFS)."""
    seen = set(seeds)
    frontier = list(seeds)
    for _ in range(depth):
        nxt = []
        for u in frontier:
            for v in g.successors(u):
                if v not in seen:
                    seen.add(v)
                    nxt.append(v)
        frontier = nxt
    return seen


def nx_random_walks(g: nx.MultiDiGraph, start: str, length: int, attempts: int, seed: int) -> list[list[str]]:
    """Pure-Python random walks over networkx adjacency (networkx has no built-in)."""
    rng = random.Random(seed)
    adj = {n: [v for _, v in g.out_edges(n)] for n in g}
    walks, seen = [], set()
    for _ in range(attempts):
        walk = [start]
        cur = start
        for _ in range(length - 1):
            nbrs = adj[cur]
            if not nbrs:
                break
            cur = rng.choice(nbrs)
            walk.append(cur)
        key = tuple(walk)
        if key not in seen:
            seen.add(key)
            walks.append(walk)
    return walks


def path_cost(g: nx.MultiDiGraph, path: list[str]) -> float:
    return sum(min(d["weight"] for d in g.get_edge_data(u, v).values()) for u, v in zip(path, path[1:]))


# ---------------------------------------------------------------------------
# Benchmarks
# ---------------------------------------------------------------------------

def run_size(n_nodes: int, n_edges: int, repeats: int, seed: int) -> SizeReport:
    report = SizeReport(n_nodes, n_edges + n_nodes - 1)
    edges = make_edges(n_nodes, n_edges, seed)
    add = report.results.append
    rng = random.Random(seed + 1)
    src, dst = "n0", f"n{n_nodes - 1}"
    subset = [f"n{i}" for i in rng.sample(range(n_nodes), max(1, n_nodes // 5))]
    seeds = [f"n{i}" for i in rng.sample(range(n_nodes), max(1, min(100, n_nodes // 10)))]

    # Construction ---------------------------------------------------------
    t_iw, iw = best_of(lambda: build_ironweaver(n_nodes, edges), repeats)
    t_nx, g = best_of(lambda: build_networkx(n_nodes, edges), repeats)
    assert iw.node_count() == g.number_of_nodes()
    add(Result("Build graph", "add all nodes and edges one by one", t_iw, t_nx))

    # Traversal ------------------------------------------------------------
    start = iw.get_node(src)
    t_iw, r_iw = best_of(lambda: start.bfs(), repeats)
    t_nx, r_nx = best_of(lambda: [src] + [v for _, v in nx.bfs_edges(g, src)], repeats)
    assert set(r_iw.keys()) == set(r_nx)
    add(Result("BFS (full)", f"all nodes reachable from `{src}`", t_iw, t_nx, f"{len(r_nx):,} nodes reached"))

    t_iw, r_iw = best_of(lambda: start.bfs(depth=3), repeats)
    t_nx, r_nx = best_of(lambda: [src] + [v for _, v in nx.bfs_edges(g, src, depth_limit=3)], repeats)
    assert set(r_iw.keys()) == set(r_nx)
    add(Result("BFS (depth 3)", "depth-limited BFS", t_iw, t_nx, f"{len(r_nx):,} nodes reached"))

    t_iw, r_iw = best_of(lambda: start.bfs(filter={"type": "knows"}), repeats)
    knows = nx.subgraph_view(g, filter_edge=lambda u, v, k: g.edges[u, v, k]["type"] == "knows")
    t_nx, r_nx = best_of(lambda: [src] + [v for _, v in nx.bfs_edges(knows, src)], repeats)
    assert set(r_iw.keys()) == set(r_nx)
    add(Result("BFS (edge filter)", "only follow `type == \"knows\"` edges", t_iw, t_nx, f"{len(r_nx):,} nodes reached"))

    t_iw, r_iw = best_of(lambda: start.traverse(), repeats)
    t_nx, r_nx = best_of(lambda: list(nx.dfs_preorder_nodes(g, src)), repeats)
    assert set(r_iw.keys()) == set(r_nx)
    add(Result("DFS traversal", "pre-order DFS from source", t_iw, t_nx))

    t_iw, r_iw = best_of(lambda: start.bfs_search(dst), repeats)
    t_nx, r_nx = best_of(lambda: nx.has_path(g, src, dst), repeats)
    assert (r_iw is not None) == r_nx
    add(Result("BFS search", f"find `{dst}` from `{src}`", t_iw, t_nx,
               "both use bidirectional BFS"))

    # Paths ----------------------------------------------------------------
    t_iw, r_iw = best_of(lambda: iw.shortest_path(src, dst, method="bfs"), repeats)
    t_nx, r_nx = best_of(lambda: nx.shortest_path(g, src, dst), repeats)
    assert len(r_iw.meta["nodelist"]) == len(r_nx)
    add(Result("Shortest path (unweighted)", "BFS shortest path", t_iw, t_nx,
               f"{len(r_nx) - 1} hops; both use bidirectional BFS"))

    t_iw, r_iw = best_of(lambda: iw.shortest_path(src, dst, method="dijkstra", weight="weight"), repeats)
    t_nx, r_nx = best_of(lambda: nx.dijkstra_path(g, src, dst, weight="weight"), repeats)
    assert abs(r_iw.meta["cost"] - path_cost(g, r_nx)) < 1e-6
    add(Result("Shortest path (Dijkstra)", "weighted by `weight` attribute", t_iw, t_nx,
               f"cost {r_iw.meta['cost']:.2f}"))

    # Batches: one call, queries run in parallel with the GIL released
    prng = random.Random(seed + 1)
    pairs = [(f"n{prng.randrange(n_nodes)}", f"n{prng.randrange(n_nodes)}") for _ in range(64)]
    t_iw, r_iw = best_of(lambda: iw.shortest_paths(pairs, weight="weight"), repeats)
    t_nx, r_nx = best_of(lambda: [nx.dijkstra_path_length(g, s, t, weight="weight")
                                  if nx.has_path(g, s, t) else None for s, t in pairs], repeats)
    assert all((a is None and b is None) or abs(a["cost"] - b) < 1e-6 for a, b in zip(r_iw, r_nx))
    t_loop, _ = best_of(lambda: [iw.shortest_path(s, t, method="dijkstra", weight="weight") if r else None
                                 for (s, t), r in zip(pairs, r_iw)], repeats)
    add(Result("Batch shortest paths", f"{len(pairs)} Dijkstra pairs in one `shortest_paths` call", t_iw, t_nx,
               f"one `shortest_path` call per pair: {fmt_time(t_loop)}"))

    sources = [f"n{i}" for i in prng.sample(range(n_nodes), 16)]
    t_iw, r_iw = best_of(lambda: iw.distances(sources, weight="weight"), repeats)
    t_nx, r_nx = best_of(lambda: [nx.single_source_dijkstra_path_length(g, s, weight="weight") for s in sources], repeats)
    assert all(len(r_iw[s]) == len(d) for s, d in zip(sources, r_nx))
    add(Result("Distances from sources", f"Dijkstra from {len(sources)} sources to every reachable node", t_iw, t_nx,
               f"{sum(len(d) for d in r_nx):,} distances"))

    # Analytics on a projection ---------------------------------------------
    # ironweaver times include building the projection each time.
    t_iw, proj = best_of(lambda: iw.project(weight="weight"), repeats)
    add(Result("Project graph", "`project(weight=...)`: compact read-only copy for analytics", t_iw, None,
               f"{proj.memory_usage() / 1e6:.1f} MB"))

    def simple(graph):
        s = nx.Graph(graph.to_undirected(as_view=True))
        s.remove_edges_from(list(nx.selfloop_edges(s)))
        return s

    t_iw, r_iw = best_of(lambda: iw.project().weakly_connected_components(), repeats)
    t_nx, r_nx = best_of(lambda: list(nx.weakly_connected_components(g)), repeats)
    assert len(r_iw) == len(r_nx)
    add(Result("Weakly connected components", "`project().weakly_connected_components()`", t_iw, t_nx,
               f"{len(r_iw):,} components"))

    t_iw, r_iw = best_of(lambda: iw.project().strongly_connected_components(), repeats)
    t_nx, r_nx = best_of(lambda: list(nx.strongly_connected_components(g)), repeats)
    assert len(r_iw) == len(r_nx)
    add(Result("Strongly connected components", "`project().strongly_connected_components()`", t_iw, t_nx,
               f"{len(r_iw):,} components"))

    t_iw, r_iw = best_of(lambda: iw.project(weight="weight").pagerank(), repeats)
    try:
        t_nx, r_nx = best_of(lambda: nx.pagerank(g, weight="weight"), repeats)
        assert max(abs(r_iw[k] - r_nx[k]) for k in r_nx) < 1e-5
        note = ""
    except ImportError:  # networkx.pagerank needs scipy
        t_nx, note = None, "networkx needs scipy (not installed)"
    add(Result("PageRank", "weighted, `project(weight=...).pagerank()`", t_iw, t_nx, note))

    t_iw, r_iw = best_of(lambda: iw.project().triangles(), repeats)
    t_nx, r_nx = best_of(lambda: nx.triangles(simple(g)), repeats)
    assert r_iw == r_nx
    add(Result("Triangles", "per node, edges as undirected (networkx: incl. `nx.Graph` conversion)", t_iw, t_nx,
               f"{sum(r_iw.values()) // 3:,} triangles"))

    t_iw, r_iw = best_of(lambda: iw.project().core_number(), repeats)
    t_nx, r_nx = best_of(lambda: nx.core_number(simple(g)), repeats)
    assert r_iw == r_nx
    add(Result("Core number", "k-core decomposition (networkx: incl. `nx.Graph` conversion)", t_iw, t_nx,
               f"max core {max(r_iw.values(), default=0)}"))

    t_iw, r_iw = best_of(lambda: iw.project().label_propagation(), repeats)
    t_nx, r_nx = best_of(lambda: list(nx.community.label_propagation_communities(simple(g))), repeats)
    add(Result("Label propagation", "communities; networkx uses its semi-synchronous variant", t_iw, t_nx,
               f"{len(r_iw):,} vs {len(r_nx):,} communities"))

    t_iw, r_iw = best_of(lambda: iw.project().bfs_levels(["n0"]), repeats)
    t_nx, r_nx = best_of(lambda: nx.single_source_shortest_path_length(g, "n0"), repeats)
    assert r_iw == r_nx
    add(Result("BFS levels", "hop distance from one node to all (parallel, direction-optimizing)", t_iw, t_nx,
               f"{len(r_iw):,} reached"))

    k = min(64, n_nodes)
    t_iw, r_iw = best_of(lambda: iw.project().betweenness_centrality(k=k, seed=seed), repeats)
    t_nx, r_nx = best_of(lambda: nx.betweenness_centrality(g, k=k, seed=seed), repeats)
    add(Result("Betweenness (sampled)", f"estimated from {k} sources (different samples)", t_iw, t_nx,
               f"max {max(r_iw.values(), default=0):.4f} vs {max(r_nx.values(), default=0):.4f}"))

    spairs = [(f"n{prng.randrange(n_nodes)}", f"n{prng.randrange(n_nodes)}") for _ in range(10_000)]
    spairs = [(a, b) for a, b in spairs if a != b]
    t_iw, r_iw = best_of(lambda: iw.project().similarity(spairs, "adamic_adar"), repeats)
    t_nx, r_nx = best_of(lambda: [x for _, _, x in nx.adamic_adar_index(simple(g), spairs)], repeats)
    assert all(abs(a - b) < 1e-9 for a, b in zip(r_iw, r_nx))
    add(Result("Similarity", f"Adamic-Adar for {len(spairs):,} pairs (networkx: incl. `nx.Graph` conversion)",
               t_iw, t_nx, ""))

    t_iw, r_iw = best_of(lambda: iw.project().most_similar(k=10), repeats)
    add(Result("Most similar nodes", "top 10 by Jaccard for every node", t_iw, None, ""))

    # The same undirected multigraph on both sides (parallel edges add up)
    multi = nx.MultiGraph()
    multi.add_nodes_from(g)
    multi.add_edges_from(g.edges())
    both = iw.project(direction="both")
    t_iw, r_iw = best_of(lambda: iw.project(direction="both").leiden(seed=seed), repeats)
    t_nx, r_nx = best_of(lambda: nx.community.louvain_communities(multi, seed=seed), repeats)
    assert abs(both.modularity(r_nx) - nx.community.modularity(multi, r_nx)) < 1e-9
    add(Result("Leiden vs Louvain", "communities (networkx has no Leiden without a backend)", t_iw, t_nx,
               f"modularity {both.modularity(r_iw):.3f} vs {both.modularity(r_nx):.3f}"))

    t_iw, r_iw = best_of(lambda: iw.project(weight="weight").minimum_spanning_tree(), repeats)
    t_nx, r_nx = best_of(lambda: list(nx.minimum_spanning_edges(g.to_undirected(), weight="weight")), repeats)
    assert len(r_iw) == len(r_nx)
    add(Result("Minimum spanning tree", "weighted, edges as undirected (a forest)", t_iw, t_nx,
               f"{len(r_iw):,} edges"))

    simple_di = nx.DiGraph()
    for a, b, d in g.edges(data=True):
        if a != b and (not simple_di.has_edge(a, b) or d["weight"] < simple_di[a][b]["weight"]):
            simple_di.add_edge(a, b, weight=d["weight"])
    s0, t0 = next((a, b) for a, b in pairs if nx.has_path(simple_di, a, b) and a != b)
    t_iw, r_iw = best_of(lambda: iw.project(weight="weight").k_shortest_paths(s0, t0, 10), repeats)
    t_nx, r_nx = best_of(lambda: list(islice(nx.shortest_simple_paths(simple_di, s0, t0, weight="weight"), 10)),
                         repeats)
    assert len(r_iw) == len(r_nx)
    add(Result("k shortest paths", "10 loopless weighted paths (Yen)", t_iw, t_nx, ""))

    t_iw, r_iw = best_of(lambda: iw.project(direction="both").fastrp(128, seed=seed), repeats)
    add(Result("FastRP embeddings", "128 dimensions, 3 iterations", t_iw, None, ""))

    t_iw, r_iw = best_of(lambda: iw.project().node2vec_walks(20, 2, p=0.5, q=2.0, seed=seed), repeats)
    add(Result("node2vec walks", "2 walks of 20 nodes per node, p=0.5, q=2", t_iw, None,
               f"{len(r_iw):,} walks"))

    # Weighted grid: A* vs Dijkstra ------------------------------------------
    side = max(2, int(n_nodes ** 0.5))
    giw, gnx = build_grid(side, seed)
    mid = side // 2
    gs, gt = f"0,{mid}", f"{side - 1},{mid}"
    tx, ty = side - 1, mid

    def nx_euclid(u, v):
        a, b = gnx.nodes[u], gnx.nodes[v]
        return ((a["x"] - b["x"]) ** 2 + (a["y"] - b["y"]) ** 2) ** 0.5

    table = {n: ((d["x"] - tx) ** 2 + (d["y"] - ty) ** 2) ** 0.5 for n, d in gnx.nodes(data=True)}
    giw.meta["to_target"] = table

    t_iw, r_dj = best_of(lambda: giw.shortest_path(gs, gt, method="dijkstra"), repeats)
    t_nx, r_nx = best_of(lambda: nx.dijkstra_path(gnx, gs, gt, weight="weight"), repeats)
    cost = r_dj.meta["cost"]
    assert abs(cost - path_cost(gnx, r_nx)) < 1e-6
    add(Result("Grid: Dijkstra", f"{side}×{side} grid, left edge to right edge", t_iw, t_nx,
               f"{r_dj.meta['expanded']:,} nodes expanded"))

    t_iw, r_iw = best_of(lambda: giw.shortest_path(gs, gt, method="astar", heuristic="euclidean"), repeats)
    t_nx, r_nx = best_of(lambda: nx.astar_path(gnx, gs, gt, heuristic=nx_euclid, weight="weight"), repeats)
    assert abs(r_iw.meta["cost"] - cost) < 1e-6 and abs(path_cost(gnx, r_nx) - cost) < 1e-6
    add(Result("Grid: A* (coordinates)", "Euclidean heuristic from `x`/`y` node attributes", t_iw, t_nx,
               f"{r_iw.meta['expanded']:,} nodes expanded; networkx calls a Python heuristic"))

    t_iw, r_iw = best_of(lambda: giw.shortest_path(gs, gt, distances="to_target"), repeats)
    t_nx, r_nx = best_of(lambda: nx.astar_path(gnx, gs, gt, heuristic=lambda u, v: table[u], weight="weight"), repeats)
    assert abs(r_iw.meta["cost"] - cost) < 1e-6 and abs(path_cost(gnx, r_nx) - cost) < 1e-6
    add(Result("Grid: A* (precomputed)", "estimates from `vertex.meta` vs a dict lookup", t_iw, t_nx,
               f"{r_iw.meta['expanded']:,} nodes expanded"))

    # Subgraphs ------------------------------------------------------------
    t_iw, r_iw = best_of(lambda: iw.filter(ids=subset), repeats)
    t_nx, r_nx = best_of(lambda: g.subgraph(subset).copy(), repeats)
    assert r_iw.node_count() == r_nx.number_of_nodes()
    add(Result("Subgraph by ids", f"{len(subset):,} nodes + edges between them, as a new graph", t_iw, t_nx))

    t_iw, r_iw = best_of(lambda: iw.filter(group=3), repeats)
    t_nx, r_nx = best_of(lambda: g.subgraph([n for n, d in g.nodes(data=True) if d["group"] == 3]).copy(), repeats)
    assert r_iw.node_count() == r_nx.number_of_nodes()
    add(Result("Subgraph by attribute", "nodes with `group == 3`", t_iw, t_nx))

    seed_graph = iw.filter(ids=seeds)
    t_iw, r_iw = best_of(lambda: seed_graph.expand(iw, depth=2), repeats)
    t_nx, r_nx = best_of(lambda: g.subgraph(nx_multi_source_within(g, seeds, 2)).copy(), repeats)
    assert r_iw.node_count() == r_nx.number_of_nodes()
    add(Result("Expand (depth 2)", f"{len(seeds)} seeds + neighbourhood, as a new graph", t_iw, t_nx,
               f"{r_nx.number_of_nodes():,} nodes"))

    # Mutation -------------------------------------------------------------
    victims = [f"n{i}" for i in rng.sample(range(n_nodes), max(1, n_nodes // 20))]

    def iw_remove(graph):
        for v in victims:
            graph.remove_node(v)
        return graph

    def nx_remove(graph):
        graph.remove_nodes_from(victims)
        return graph

    t_iw, r_iw = best_of(iw_remove, repeats, setup=lambda: build_ironweaver(n_nodes, edges))
    t_nx, r_nx = best_of(nx_remove, repeats, setup=lambda: build_networkx(n_nodes, edges))
    assert r_iw.node_count() == r_nx.number_of_nodes()
    add(Result("Remove nodes", f"remove {len(victims):,} nodes and their edges", t_iw, t_nx))

    # Analysis -------------------------------------------------------------
    t_iw, r_iw = best_of(lambda: iw.get_metadata()["edge_count"], repeats)
    t_nx, r_nx = best_of(lambda: g.number_of_edges(), repeats)
    assert r_iw == r_nx
    add(Result("Count edges", "`get_metadata()` vs `number_of_edges()`", t_iw, t_nx))

    # Random walks ---------------------------------------------------------
    attempts, length = 5_000, 20
    t_iw, r_iw = best_of(lambda: iw.random_walks(src, length, attempts, allow_revisit=True, seed=seed), repeats)
    t_nx, r_nx = best_of(lambda: nx_random_walks(g, src, length, attempts, seed), repeats)
    add(Result("Random walks", f"{attempts:,} walks of length {length}, deduplicated", t_iw, t_nx,
               "networkx has no random walks; pure Python over its adjacency"))

    # Serialization --------------------------------------------------------
    t_iw, s_iw = best_of(lambda: iw.save_to_json(), repeats)
    t_nx, s_nx = best_of(lambda: json.dumps(nx.node_link_data(g, **NODE_LINK)), repeats)
    add(Result("Serialize to JSON string", "`save_to_json()` vs `node_link_data` + `json.dumps`", t_iw, t_nx))

    t_iw, r_iw = best_of(lambda: Vertex.load_from_json(s_iw), repeats)
    t_nx, r_nx = best_of(lambda: nx.node_link_graph(json.loads(s_nx), **NODE_LINK), repeats)
    assert r_iw.node_count() == r_nx.number_of_nodes()
    add(Result("Load from JSON string", "`load_from_json()` vs `json.loads` + `node_link_graph`", t_iw, t_nx))

    del iw, g
    gc.collect()
    return report


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def fmt_time(seconds: float | None) -> str:
    if seconds is None:
        return "–"
    if seconds < 1e-3:
        return f"{seconds * 1e6:,.1f} µs"
    if seconds < 1:
        return f"{seconds * 1e3:,.2f} ms"
    return f"{seconds:,.3f} s"


def fmt_speedup(iw: float | None, nx_: float | None) -> str:
    if not iw or not nx_:
        return "–"
    ratio = nx_ / iw
    if ratio >= 1:
        return f"**{ratio:,.1f}× faster**"
    return f"{1 / ratio:,.1f}× slower"


def render(reports: list[SizeReport], repeats: int, seed: int) -> str:
    lines = [
        "# ironweaver vs networkx",
        "",
        f"Generated {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} by `benchmarks/compare_networkx.py`.",
        "",
        "| | |",
        "|---|---|",
        f"| Python | {platform.python_version()} ({platform.python_implementation()}) |",
        f"| networkx | {nx.__version__} |",
        f"| Platform | {platform.platform()} |",
        f"| CPU cores | {os.cpu_count()} |",
        f"| Repeats | best of {repeats} |",
        f"| Seed | {seed} |",
        "",
        "Both libraries get the same random directed multigraph (random edges plus a",
        "`n0 → n1 → …` chain so everything is reachable from `n0`). Each cell is the",
        "best wall-clock time over the repeats, and every row checks that both",
        "libraries return the same result. \"Speedup\" is networkx time ÷ ironweaver time.",
        "",
    ]
    for rep in reports:
        lines += [
            f"## {rep.nodes:,} nodes, {rep.edges:,} edges",
            "",
            "| Operation | Description | ironweaver | networkx | Speedup | Notes |",
            "|---|---|---:|---:|---:|---|",
        ]
        for r in rep.results:
            lines.append(
                f"| {r.name} | {r.description} | {fmt_time(r.ironweaver_s)} | {fmt_time(r.networkx_s)} "
                f"| {fmt_speedup(r.ironweaver_s, r.networkx_s)} | {r.note} |"
            )
        lines.append("")
    return "\n".join(lines)


def parse_sizes(text: str) -> list[tuple[int, int]]:
    sizes = []
    for part in text.split(","):
        nodes, _, edges = part.partition(":")
        n = int(nodes)
        sizes.append((n, int(edges) if edges else n * 5))
    return sizes


def main(argv: list[str] | None = None) -> str:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sizes", default="1000:5000,20000:100000",
                        help="comma-separated NODES[:EDGES] graph sizes (default: %(default)s)")
    parser.add_argument("--repeats", type=int, default=3, help="repeats per operation (default: %(default)s)")
    parser.add_argument("--seed", type=int, default=42, help="random seed (default: %(default)s)")
    parser.add_argument("--output", default=DEFAULT_OUTPUT, help="Markdown file to write (default: %(default)s)")
    args = parser.parse_args(argv)

    reports = []
    for nodes, edges in parse_sizes(args.sizes):
        print(f"Benchmarking {nodes:,} nodes / {edges:,} random edges ...", file=sys.stderr)
        reports.append(run_size(nodes, edges, args.repeats, args.seed))

    markdown = render(reports, args.repeats, args.seed)
    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as fh:
        fh.write(markdown)
    print(markdown)
    print(f"\nWrote {args.output}", file=sys.stderr)
    return args.output


if __name__ == "__main__":
    main()
